# SISTEMA ERP MODULAR: ARQUITECTURA TRANSACCIONAL Y ANALÍTICA CON FLASK Y MYSQL
## Informe Técnico de Desarrollo y Pruebas (Fase 2 - Entrega Definitiva y Sustentación)
**Normas APA (7.ª edición)**

---

### Portada Institucional
- **Proyecto:** ERP API REST Modular - Fase 2
- **Asignatura:** Bases de Datos II
- **Institución:** Corporación de Estudios Tecnológicos del Norte del Valle (COTECNOVA)
- **Fecha:** Noviembre 25 de 2026

---

## 1. Descripción y Arquitectura del ERP

### 1.1. Resumen del Sistema y Cero Magia (No ORMs)
El sistema ERP centraliza la facturación comercial, control de existencias en bodega, clientes, proveedores, reportes gerenciales, cartera y autenticación.
En cumplimiento estricto con las **reglas innegociables** de la rúbrica:
- **Cero ORMs:** 100% SQL crudo ejecutado mediante `mysql-connector-python` con cursores de diccionario (`dictionary=True`).
- **Auditoría de Errores:** Captura explícita de `mysql.connector.Error` en todos los endpoints, gestionando los disparos de `SIGNAL SQLSTATE '45000'` con código HTTP 400 y `conn.rollback()`.
- **Cero Capturas Genéricas:** No se permiten capturas `except Exception as e:`.
- **Documentación de Triggers:** Cada endpoint que activa un trigger incluye el comentario de bloque obligatorio en Python.

### 1.2. Estructura de Blueprints
```text
backend/
├── routes/
│   ├── auth.py          # Autenticación y gestión de usuarios (/api/auth)
│   ├── cartera.py       # Cuentas por cobrar y abonos (/api/cartera)
│   ├── productos.py     # Catálogo, filtros dinámicos y soft delete (/api/productos)
│   ├── reportes.py      # Agrupaciones analíticas SQL avanzadas (/api/reportes)
│   ├── terceros.py      # Clientes y proveedores con soft delete (/api/terceros)
│   └── ventas.py        # Facturación, reversión por triggers y estado (/api/ventas)
├── static/
│   └── index.html       # Frontend reactivo e interactivo integrado
├── app.py               # Servidor Flask, CORS y montaje de Blueprints
├── config.py            # Conexión híbrida resiliente
└── errors.py            # Sanitizador de errores y privacidad de BD
```

---

## 2. Documentación Paso a Paso del Desarrollo

### 2.1. Reversión de Ventas y Triggers en MySQL (Punto 1)
- **Endpoint:** `PUT /api/ventas/<id_venta>/anular`
- **Trigger `ventas_BEFORE_UPDATE`:** Verifica que `OLD.estado_venta <> 'Anulado'` (inmutabilidad contable) y `OLD.estado_venta <> 'Enviado'`. Lanza `SIGNAL SQLSTATE '45000'` si se viola.
- **Trigger `ventas_AFTER_UPDATE`:** Reversa el inventario automáticamente mediante `UPDATE productos p INNER JOIN detalleventa dv ON p.id_producto = dv.id_producto SET p.cantidad_stock = p.cantidad_stock + dv.cantidad WHERE dv.id_venta = NEW.id_venta;`. Cero cálculos en Python.

### 2.2. Modificación de Estado y Adición de Artículos en Caliente
- **Endpoint:** `PUT /api/ventas/<id_venta>/estado` (actualiza a 'Pendiente', 'Pagado', 'Enviado', 'Por Pagar', 'Anulado').
- **Endpoint:** `POST /api/ventas/<id_venta>/productos` (añade productos a ventas en estado 'Pendiente'). Dispara `detalleventa_BEFORE_INSERT` (valida stock y estado en espera) y `detalleventa_AFTER_INSERT` (descuenta existencias y acumula `total_venta`).

### 2.3. Consultas Analíticas (Punto 2)
- **Top 5 Productos:** `GET /api/reportes/top-productos` (cruce de `detalleventa`, `productos` y `ventas` con `SUM(dv.cantidad)` y `GROUP BY`).
- **Inventario Crítico:** `GET /api/reportes/inventario-critico` (`cantidad_stock <= nivel_minimo`).
- **Ventas Mensuales:** `GET /api/reportes/ventas-mensuales` (`GROUP BY MONTH(fecha_venta)` con `MAX(CASE ...)` y `COALESCE(SUM(total_venta), 0.00)` para compatibilidad estricta con `ONLY_FULL_GROUP_BY`).

### 2.4. Búsqueda Dinámica con Cláusula LIKE y Paginación (Punto 3)
- **Endpoint:** `GET /api/productos/?nombre=teclado&page=1&limit=5`
- Parámetros seguros `%s` (`AND nombre LIKE %s`) y paginación con `LIMIT %s OFFSET %s`.

### 2.5. Módulos Adicionales
- **Autenticación:** `POST /api/auth/login` y `GET /api/auth/usuarios`.
- **Cartera y Abonos:** `GET /api/cartera/` y `POST /api/cartera/<id_venta>/abono`.
- **Soft Delete con Triggers:** Inactivación lógica en productos y terceros con validación de dependencias contables.

---

## 3. Evidencias de Pruebas en Bruno (Rotuladas en Normas APA)

### Figura 1. Facturación Maestro-Detalle Exitosa
```http
POST http://localhost:5001/api/ventas/
Status: 201 Created

{
  "id_tercero": 1,
  "id_usuario": 1,
  "detalles": [
    { "id_producto": 1, "cantidad": 2, "precioUnitario": 120000.00 },
    { "id_producto": 2, "cantidad": 1, "precioUnitario": 45000.00 }
  ]
}

Respuesta:
{
  "id_venta": 12,
  "mensaje": "Venta registrada con éxito."
}
```
*Nota: Disparo automático de triggers de inserción en detalleventa y descuento de stock.*

### Figura 2. Reversión Exitosa de Venta y Restauración de Stock
```http
PUT http://localhost:5001/api/ventas/12/anular
Status: 200 OK

Respuesta:
{
  "estado_anterior": "Pendiente",
  "mensaje": "Venta 12 anulada exitosamente.",
  "nuevo_estado": "Anulado"
}
```
*Nota: El trigger ventas_AFTER_UPDATE restableció las existencias en productos.*

### Figura 3. Error Controlado por Trigger (Re-Anulación Rechazada)
```http
PUT http://localhost:5001/api/ventas/12/anular
Status: 400 Bad Request

Respuesta:
{
  "codigo": 1644,
  "error": "Una venta anulada no puede volver a cambiarse de estado por seguridad contable.",
  "error_db": "Una venta anulada no puede volver a cambiarse de estado por seguridad contable."
}
```
*Nota: Captura de SIGNAL SQLSTATE 45000 emitida por ventas_BEFORE_UPDATE.*

### Figura 4. Reporte Analítico de Ventas Mensuales Consolidadas
```http
GET http://localhost:5001/api/reportes/ventas-mensuales
Status: 200 OK

Respuesta:
[
  {
    "mes_nombre": "Octubre",
    "mes_numero": 10,
    "total_ingresos": 14250000.00,
    "total_transacciones": 15
  },
  {
    "mes_nombre": "Noviembre",
    "mes_numero": 11,
    "total_ingresos": 8920000.00,
    "total_transacciones": 9
  }
]
```

### Figura 5. Búsqueda Dinámica Segura con Parámetros LIKE (%s)
```http
GET http://localhost:5001/api/productos/?nombre=teclado&page=1&limit=5
Status: 200 OK

Respuesta:
[
  {
    "id_producto": 1,
    "nombre": "Teclado Mecánico RGB Pro",
    "cantidad_stock": 18,
    "nivel_minimo": 5,
    "precioVenta": 120000.00
  }
]
```

### Figura 6. Autenticación de Operador en Módulo de Seguridad
```http
POST http://localhost:5001/api/auth/login
Status: 200 OK

{
  "correo": "admin@erp.com",
  "password": "admin123"
}

Respuesta:
{
  "mensaje": "Autenticación exitosa",
  "usuario": {
    "correo": "admin@erp.com",
    "id_usuario": 1,
    "nombre": "Administrador del Sistema",
    "roles_id_rol": 1
  }
}
```

---

## 4. Conclusiones Técnicas
1. **Integridad Transaccional Soberana en MySQL:** La delegación de reglas de negocio críticas a triggers garantiza consistencia de datos sin importar qué interfaz acceda al motor relacional.
2. **Eficiencia con SQL Crudo:** Se maximizó el rendimiento eliminando la sobrecarga de ORMs y permitiendo consultas analíticas nativas avanzadas.
3. **Privacidad de la Información:** Se protegió la arquitectura técnica de la base de datos contra filtraciones de esquemas o sentencias SQL hacia clientes externos.
4. **Resiliencia en Despliegue:** El sistema es 100% portátil en contenedores Docker y servidores locales bajo MySQL 8.0 o MySQL 5.7.
