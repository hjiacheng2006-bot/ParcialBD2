import os
from flask import Flask, jsonify, send_from_directory, request
from routes.productos import productos_bp
from routes.terceros import terceros_bp
from routes.ventas import ventas_bp
from routes.reportes import reportes_bp
from routes.auth import auth_bp
from routes.cartera import cartera_bp

app = Flask(__name__, static_folder='static')
app.url_map.strict_slashes = False

# Registrar Blueprints requeridos para la Fase 2 (Ventas, Reportes, Productos, Cartera, Autenticación)
app.register_blueprint(productos_bp, url_prefix='/api/productos')
app.register_blueprint(terceros_bp, url_prefix='/api/terceros')
app.register_blueprint(ventas_bp, url_prefix='/api/ventas')
app.register_blueprint(reportes_bp, url_prefix='/api/reportes')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(cartera_bp, url_prefix='/api/cartera')


# Manejo explícito de peticiones OPTIONS (CORS preflight) para navegadores
@app.before_request
def handle_preflight():
    if request.method == 'OPTIONS':
        response = app.make_default_options_response()
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
        return response


# Configuración de CORS universal para permitir peticiones desde cualquier origen/puerto
@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    return response


# Ruta raíz e index.html: sirve la interfaz Web interactiva del ERP
@app.route('/', methods=['GET'])
@app.route('/index.html', methods=['GET'])
def index():
    return send_from_directory('static', 'index.html')


@app.route('/<path:filename>', methods=['GET'])
def static_files(filename):
    return send_from_directory('static', filename)


@app.route('/uploads/<path:filename>', methods=['GET'])
def uploaded_files(filename):
    return send_from_directory(os.path.join('static', 'uploads'), filename)


# Endpoint de salud y metadatos de la API
@app.route('/api/health', methods=['GET'])
def api_health():
    return jsonify({
        "proyecto": "ERP API REST - Fase 2: Consolidación Definitiva",
        "estado": "Servidor Activo",
        "version": "2.0.0",
        "endpoints": {
            "productos": "/api/productos",
            "terceros": "/api/terceros",
            "ventas": "/api/ventas",
            "reportes": "/api/reportes",
            "auth": "/api/auth",
            "cartera": "/api/cartera"
        }
    }), 200


# Manejadores globales para máxima privacidad y protección de infraestructura
@app.errorhandler(400)
def bad_request(e):
    return jsonify({"error": "Petición inválida o formato JSON incorrecto."}), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Recurso no encontrado en el servidor."}), 404


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Método HTTP no permitido para este recurso."}), 405


@app.errorhandler(500)
def internal_server_error(e):
    return jsonify({"error": "Error interno del servidor. Por favor intente más tarde."}), 500


if __name__ == '__main__':
    # host='0.0.0.0' es obligatorio en Docker: con 127.0.0.1 Flask solo
    # escucharía dentro del contenedor y el puerto publicado no le llegaría
    app.run(host='0.0.0.0', port=5000, debug=True)
