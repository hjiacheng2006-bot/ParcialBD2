import os
import time
import mysql.connector
from dotenv import load_dotenv

# Carga de variables de entorno buscando en el directorio actual y en el directorio raíz
load_dotenv()
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))

def get_db_connection():
    """
    Retorna una nueva conexión a la base de datos ERP.
    Incluye reintentos y compatibilidad universal (Docker o Local Windows).
    """
    host = os.getenv("DB_HOST", "servidor_db_2")
    user = os.getenv("MYSQL_USER", "estudiante")
    password = os.getenv("MYSQL_PASSWORD", "cotecnova2026")
    database = os.getenv("MYSQL_DATABASE", "erp")
    port = int(os.getenv("DB_PORT", 3306))
    root_password = os.getenv("MYSQL_ROOT_PASSWORD", "super_root")

    base_config = {
        "database": database,
        "autocommit": False
    }

    # Intentos de credenciales: primero usuario estudiante, luego root y root sin contraseña (XAMPP/Workbench)
    credentials = [
        {"user": user, "password": password},
        {"user": "root", "password": root_password},
        {"user": "root", "password": ""}
    ]

    # Lista de combinaciones de host/puerto a probar
    # El usuario especificó prioritariamente el puerto 3307
    hosts_to_try = [
        ("127.0.0.1", 3307),
        ("localhost", 3307),
        ("host.docker.internal", 3307),
        (host, port),
        ("servidor_db_2", 3306),
        ("127.0.0.1", 3308),
        ("localhost", 3308),
        ("127.0.0.1", 3306),
        ("localhost", 3306)
    ]

    last_error = None

    for h, p in hosts_to_try:
        for cred in credentials:
            # Reintentar hasta 2 veces con breve pausa por si MySQL está terminando de arrancar
            for intento in range(2):
                try:
                    conn = mysql.connector.connect(
                        host=h,
                        port=p,
                        user=cred["user"],
                        password=cred["password"],
                        **base_config
                    )
                    return conn
                except mysql.connector.Error as e:
                    err = e
                    last_error = err
                    # Si es error de conexión en progreso, esperar brevemente
                    if err.errno in (2003, 2005):
                        time.sleep(0.3)
                    else:
                        break # Si es error de credenciales, pasar al siguiente conjunto

    # Si ninguno conectó, lanzar el último error para trazabilidad
    raise last_error
