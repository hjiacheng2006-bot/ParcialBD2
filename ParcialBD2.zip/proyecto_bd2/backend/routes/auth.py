import time
from functools import wraps
from flask import Blueprint, jsonify, request
import mysql.connector
from mysql.connector import Error
from config import get_db_connection
from errors import sanitizar_error_db

# Blueprint de Autenticación
auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')


def login_requerido(f):
    """
    PUNTO 4.1: Decorador para proteger rutas críticas del sistema ERP.
    Verifica que la petición contenga un token de sesión válido en la cabecera
    'Authorization: Bearer <token>' o 'X-Auth-Token'.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization') or request.headers.get('X-Auth-Token')
        if not auth_header:
            return jsonify({
                "error": "Acceso no autorizado: Se requiere inicio de sesión previo para ejecutar esta operación."
            }), 401
        
        token = auth_header.replace('Bearer ', '').strip()
        if not token or not token.startswith('erp_token_'):
            return jsonify({
                "error": "Token de autenticación inválido o expirado. Inicie sesión nuevamente."
            }), 401

        return f(*args, **kwargs)
    return decorated_function


@auth_bp.route('/login', methods=['POST'])
def login():
    """
    PUNTO 4.1: Endpoint para autenticación de usuarios.
    Valida credenciales contra la tabla `usuarios` usando 100% SQL crudo y %s.
    Genera y retorna un token de sesión para autorizar peticiones protegidas.
    """
    datos = request.json or {}
    correo = datos.get('correo')
    password = datos.get('password')

    if not correo or not password:
        return jsonify({"error": "Debe proporcionar correo y contraseña."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            SELECT id_usuario, nombre, correo, estado, roles_id_rol
            FROM usuarios
            WHERE correo = %s AND password = %s;
        """
        cursor.execute(sql, (correo.strip(), password))
        usuario = cursor.fetchone()

        if not usuario:
            return jsonify({"error": "Credenciales inválidas. Correo o contraseña incorrectos."}), 401

        if usuario.get('estado') != 1:
            return jsonify({"error": "Usuario inactivo. Contacte al administrador del sistema."}), 403

        # Generación del token de sesión seguro
        token = f"erp_token_{usuario['id_usuario']}_{int(time.time())}"

        return jsonify({
            "mensaje": "Autenticación exitosa",
            "token": token,
            "usuario": {
                "id_usuario": usuario['id_usuario'],
                "nombre": usuario['nombre'],
                "correo": usuario['correo'],
                "roles_id_rol": usuario['roles_id_rol']
            }
        }), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@auth_bp.route('/usuarios', methods=['GET'])
def listar_usuarios():
    """
    Endpoint para consultar el listado de usuarios activos del sistema ERP.
    Excluye deliberadamente el campo password por seguridad.
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            SELECT id_usuario, nombre, correo, estado, roles_id_rol
            FROM usuarios
            WHERE estado = 1
            ORDER BY id_usuario ASC;
        """
        cursor.execute(sql)
        usuarios = cursor.fetchall()

        return jsonify(usuarios), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
