from flask import Blueprint, jsonify, request
import mysql.connector
from mysql.connector import Error
from config import get_db_connection
from errors import sanitizar_error_db

# Blueprint de Cartera y Cuentas por Cobrar
cartera_bp = Blueprint('cartera', __name__, url_prefix='/api/cartera')


@cartera_bp.route('/', methods=['GET'])
def listar_cartera():
    """
    PUNTO 4.2: Consulta de cartera activa (ventas en crédito con saldo pendiente).
    Utiliza INNER JOIN con terceros y LEFT JOIN con la tabla auxiliar recibos_caja.
    Calcula el total abonado histórico y el saldo real adeudado.
    100% SQL crudo con dictionary=True.
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            SELECT v.id_venta,
                   v.fecha_venta,
                   v.total_venta,
                   v.estado_venta,
                   v.id_tercero,
                   t.nombre AS nombre_cliente,
                   t.contacto AS contacto_cliente,
                   t.correo AS correo_cliente,
                   IFNULL(rc.total_abonado, 0.00) AS total_abonado,
                   (v.total_venta - IFNULL(rc.total_abonado, 0.00)) AS saldo_pendiente
            FROM ventas v
            INNER JOIN terceros t ON v.id_tercero = t.id_tercero
            LEFT JOIN (
                SELECT id_venta, SUM(monto) AS total_abonado
                FROM recibos_caja
                GROUP BY id_venta
            ) rc ON v.id_venta = rc.id_venta
            WHERE v.estado_venta IN ('Por Pagar', 'Pendiente')
            ORDER BY v.fecha_venta ASC;
        """
        cursor.execute(sql)
        cartera = cursor.fetchall()

        total_por_cobrar = sum(float(item.get('saldo_pendiente', item.get('total_venta', 0.0)) or 0.0) for item in cartera)

        return jsonify({
            "cuentas_por_cobrar": cartera,
            "total_cartera_activa": total_por_cobrar,
            "cantidad_transacciones": len(cartera)
        }), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@cartera_bp.route('/<int:id_venta>/recibos', methods=['GET'])
def listar_recibos_venta(id_venta):
    """
    PUNTO 4.2: Consulta el historial de abonos y recibos de caja para una venta.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        sql = """
            SELECT id_recibo, id_venta, fecha_recibo, monto, observacion
            FROM recibos_caja
            WHERE id_venta = %s
            ORDER BY id_recibo DESC;
        """
        cursor.execute(sql, (id_venta,))
        recibos = cursor.fetchall()
        return jsonify(recibos), 200
    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@cartera_bp.route('/<int:id_venta>/abono', methods=['POST'])
def registrar_abono(id_venta):
    """
    PUNTO 4.2: Transacciones Financieras (Cartera y Abonos con recibos_caja).
    Inserta el pago parcial o total en la tabla auxiliar `recibos_caja`.

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué trigger se dispara en MySQL con esta acción?
      Trigger `recibos_caja_AFTER_INSERT` sobre la tabla auxiliar `recibos_caja`.
    - ¿Qué tarea realiza por debajo?
      1) Calcula en tiempo real la sumatoria de todos los recibos de caja de la venta:
         `SELECT IFNULL(SUM(monto), 0) INTO v_total_abonado FROM recibos_caja WHERE id_venta = NEW.id_venta;`
      2) Compara con el valor total facturado de la venta (`total_venta`).
      3) Si `v_total_abonado >= v_total_factura`, actualiza automáticamente en MySQL:
         `UPDATE ventas SET estado_venta = 'Pagado' WHERE id_venta = NEW.id_venta;`
      4) Si el saldo aún no se cubre por completo, asegura:
         `UPDATE ventas SET estado_venta = 'Por Pagar' WHERE id_venta = NEW.id_venta;`
      Lógica 100% delegada a la base de datos MySQL (cero cálculo de estado de cuenta en Python).
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      En caso de error de integridad referencial retorna código 1452 hacia Flask.
      Flask captura la excepción específica `mysql.connector.Error`, realiza rollback y
      responde de forma controlada y sanitizada.
    ========================================================================================
    """
    datos = request.json or {}
    monto = datos.get('monto')
    observacion = datos.get('observacion', 'Abono registrado en caja')

    if monto is None:
        return jsonify({"error": "Debe proporcionar el 'monto' del abono."}), 400

    try:
        monto = float(monto)
        if monto <= 0:
            return jsonify({"error": "El monto del abono debe ser mayor a cero."}), 400
    except (ValueError, TypeError):
        return jsonify({"error": "El monto debe ser un valor numérico válido."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Validar existencia y estado actual de la venta
        sql_check = "SELECT id_venta, total_venta, estado_venta FROM ventas WHERE id_venta = %s;"
        cursor.execute(sql_check, (id_venta,))
        venta = cursor.fetchone()

        if not venta:
            return jsonify({"error": f"Venta con ID {id_venta} no encontrada."}), 404

        if venta['estado_venta'] == 'Anulado':
            return jsonify({"error": "No se pueden registrar abonos a una venta anulada."}), 400

        if venta['estado_venta'] == 'Pagado':
            return jsonify({"error": f"La venta #{id_venta} ya se encuentra totalmente pagada."}), 400

        # 2. Insertar en la tabla auxiliar recibos_caja
        # Esta inserción DISPARA AUTOMÁTICAMENTE el trigger recibos_caja_AFTER_INSERT en MySQL
        sql_insert_recibo = """
            INSERT INTO recibos_caja (id_venta, monto, observacion)
            VALUES (%s, %s, %s);
        """
        cursor.execute(sql_insert_recibo, (id_venta, monto, observacion))
        conn.commit()

        # 3. Consultar el estado actualizado de la venta (modificado por el trigger)
        cursor.execute("SELECT id_venta, total_venta, estado_venta FROM ventas WHERE id_venta = %s;", (id_venta,))
        venta_actualizada = cursor.fetchone()

        cursor.execute("SELECT IFNULL(SUM(monto), 0) AS total_abonado FROM recibos_caja WHERE id_venta = %s;", (id_venta,))
        res_abonado = cursor.fetchone()
        total_abonado = float(res_abonado.get('total_abonado', monto) or 0.0) if res_abonado else float(monto)
        total_v = float(venta_actualizada.get('total_venta', 0.0)) if venta_actualizada else 0.0
        saldo_restante = max(0.0, total_v - total_abonado)
        nuevo_est = 'Pagado' if total_abonado >= total_v else venta_actualizada.get('estado_venta', 'Por Pagar')

        return jsonify({
            "mensaje": f"Recibo de caja por ${monto:,.2f} generado exitosamente para la venta #{id_venta}.",
            "id_venta": id_venta,
            "monto_abonado": monto,
            "total_abonado_acumulado": total_abonado,
            "saldo_restante": saldo_restante,
            "estado_anterior": venta['estado_venta'],
            "nuevo_estado": nuevo_est,
            "trigger_ejecutado": "recibos_caja_AFTER_INSERT"
        }), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
