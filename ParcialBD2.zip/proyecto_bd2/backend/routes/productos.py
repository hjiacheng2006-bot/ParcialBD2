import os
import time
from werkzeug.utils import secure_filename
from flask import Blueprint, jsonify, request
import mysql.connector
from mysql.connector import Error
from config import get_db_connection
from errors import sanitizar_error_db

# Blueprint de Productos
productos_bp = Blueprint('productos', __name__, url_prefix='/api/productos')

# Extensiones permitidas para la subida de fotografías
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@productos_bp.route('/', methods=['GET'])
def obtener_productos():
    """
    PUNTO 3: Endpoint optimizado con soporte para parámetros de búsqueda dinámica y paginación.
    Ejemplos de consumo:
      - GET /api/productos/
      - GET /api/productos/?nombre=teclado
      - GET /api/productos/?nombre=camisa&page=1&limit=10

    Condición Técnica:
      - Utiliza consultas estructuradas dinámicamente con cláusula LIKE.
      - Emplea parámetros seguros (%s) para prevención de Inyección SQL.
      - Cursor en modo diccionario (dictionary=True).
      - Captura estricta de mysql.connector.Error (Cero capturas genéricas Exception).
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Base de la consulta: productos activos (estado = 1)
        sql = """
            SELECT id_producto,
                   nombre,
                   cantidad_stock,
                   nivel_minimo,
                   precioCompra,
                   precioVenta,
                   tarifa_iva,
                   imagen,
                   estado
            FROM productos
            WHERE estado = 1
        """
        parametros = []

        # 1. Filtros dinámicos con prevención de inyección SQL (%s)
        nombre = request.args.get('nombre', type=str)
        if nombre and nombre.strip():
            sql += " AND nombre LIKE %s"
            parametros.append(f"%{nombre.strip()}%")

        precio_min = request.args.get('precio_min', type=float)
        if precio_min is not None:
            sql += " AND precioVenta >= %s"
            parametros.append(precio_min)

        precio_max = request.args.get('precio_max', type=float)
        if precio_max is not None:
            sql += " AND precioVenta <= %s"
            parametros.append(precio_max)

        stock_min = request.args.get('stock_min', type=int)
        if stock_min is not None:
            sql += " AND cantidad_stock >= %s"
            parametros.append(stock_min)

        # 2. Ordenamiento predeterminado
        sql += " ORDER BY id_producto ASC"

        # 3. Paginación opcional (page y limit)
        limit = request.args.get('limit', type=int)
        page = request.args.get('page', 1, type=int)
        if limit and limit > 0:
            offset = max(0, (page - 1) * limit)
            sql += " LIMIT %s OFFSET %s"
            parametros.extend([limit, offset])

        cursor.execute(sql, tuple(parametros))
        productos = cursor.fetchall()
        return jsonify(productos), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/', methods=['POST'])
def crear_producto():
    """
    Endpoint para registrar un nuevo producto en el inventario.
    Espera un JSON con: nombre, cantidad_stock, y opcionales: nivel_minimo, precioCompra, precioVenta, tarifa_iva.
    """
    datos = request.json

    if not datos or 'nombre' not in datos or 'cantidad_stock' not in datos:
        return jsonify({"error": "Los campos 'nombre' y 'cantidad_stock' son obligatorios."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            INSERT INTO productos
            (nombre, cantidad_stock, nivel_minimo, precioCompra, precioVenta, tarifa_iva)
            VALUES (%s, %s, %s, %s, %s, %s)
        """

        valores = (
            datos['nombre'],
            datos.get('cantidad_stock', 0),
            datos.get('nivel_minimo', 5),
            datos.get('precioCompra', 0.00),
            datos.get('precioVenta', 0.00),
            datos.get('tarifa_iva', 0.19)
        )

        cursor.execute(sql, valores)
        conn.commit()

        id_nuevo = cursor.lastrowid
        return jsonify({
            "mensaje": "Producto creado con éxito",
            "id_producto": id_nuevo
        }), 201

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/<int:id_producto>', methods=['DELETE'])
def eliminar_producto(id_producto):
    """
    Endpoint para realizar un borrado lógico (Soft Delete) de un producto (cambia estado a 0).
    Ejemplo: DELETE /api/productos/5

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué trigger se dispara en MySQL con esta acción?
      Se dispara el trigger `productos_BEFORE_UPDATE` sobre la tabla `productos`.
    - ¿Qué tarea realiza por debajo?
      Verifica si NEW.estado = 0 y OLD.estado = 1. Valida dos reglas de integridad:
      1) Si OLD.cantidad_stock > 0: Impide la inactivación porque aún existe inventario en bodega.
      2) Si el producto se encuentra referenciado en `detalle_pedido`: Impide la inactivación
         porque está comprometido en pedidos comerciales registrados.
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      Dispara `SIGNAL SQLSTATE '45000'` con:
      - 'Operación denegada: El producto no se puede inactivar porque aún tiene stock.'
      - 'Operación denegada: El producto está amarrado a un pedido existente.'
      Flask captura la excepción específica `mysql.connector.Error`, ejecuta rollback
      y retorna la descripción correspondiente con código HTTP 400 Bad Request.
    ========================================================================================
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = "UPDATE productos SET estado = 0 WHERE id_producto = %s"
        cursor.execute(sql, (id_producto,))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Producto no encontrado o ya estaba inactivo."}), 404

        return jsonify({"mensaje": f"Producto {id_producto} inactivado correctamente."}), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/<int:id_producto>', methods=['PUT'])
def actualizar_producto(id_producto):
    """
    Endpoint para actualizar los datos administrativos de un producto.
    Ejemplo: PUT /api/productos/5
    """
    datos = request.json

    if not datos:
        return jsonify({"error": "No se enviaron datos para actualizar."}), 400

    if 'nombre' not in datos:
        return jsonify({"error": "El campo 'nombre' es obligatorio para actualizar."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            UPDATE productos
            SET nombre = %s,
                cantidad_stock = %s,
                nivel_minimo = %s,
                precioCompra = %s,
                precioVenta = %s,
                tarifa_iva = %s
            WHERE id_producto = %s
        """

        valores = (
            datos['nombre'],
            datos.get('cantidad_stock', 5),
            datos.get('nivel_minimo', 5),
            datos.get('precioCompra', 0.0),
            datos.get('precioVenta', 0.0),
            datos.get('tarifa_iva', 0.19),
            id_producto
        )

        cursor.execute(sql, valores)
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"mensaje": "No se encontraron cambios a aplicar o el producto no existe."}), 404

        return jsonify({"mensaje": f"Producto {id_producto} actualizado correctamente."}), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/<int:id_producto>/imagen', methods=['POST'])
def subir_imagen_producto(id_producto):
    """
    PUNTO 4.4: Manejo de Archivos Estáticos (Subida de Imágenes).
    Utiliza request.files para recibir la fotografía del producto.
    Almacena físicamente el archivo en el directorio estático del servidor web (/static/uploads),
    mientras que en la base de datos MySQL guarda la cadena de texto con la ruta relativa (/uploads/archivo.ext).
    100% SQL crudo, parámetros seguros %s, captura estricta de Error as err.
    """
    if 'imagen' not in request.files and 'foto' not in request.files:
        return jsonify({"error": "Debe enviar un archivo en el campo 'imagen' o 'foto'."}), 400

    file = request.files.get('imagen') or request.files.get('foto')

    if not file or file.filename == '':
        return jsonify({"error": "No se ha seleccionado ningún archivo para subir."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": f"Formato no permitido. Extensiones válidas: {', '.join(ALLOWED_EXTENSIONS)}."}), 400

    # Construir directorio físico de destino (static/uploads)
    # Busca la carpeta static relativa al archivo actual
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    upload_dir = os.path.join(base_dir, 'static', 'uploads')
    os.makedirs(upload_dir, exist_ok=True)

    # Nombre seguro con prefijo timestamp para evitar colisiones
    ext = file.filename.rsplit('.', 1)[1].lower()
    raw_name = secure_filename(file.filename.rsplit('.', 1)[0])
    clean_name = f"prod_{id_producto}_{int(time.time())}_{raw_name}.{ext}"
    physical_path = os.path.join(upload_dir, clean_name)

    # Guardar físicamente en disco
    file.save(physical_path)

    # Ruta relativa guardada en base de datos
    relative_url = f"/uploads/{clean_name}"

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Validar existencia del producto
        cursor.execute("SELECT id_producto, nombre FROM productos WHERE id_producto = %s;", (id_producto,))
        prod = cursor.fetchone()
        if not prod:
            return jsonify({"error": f"Producto con ID {id_producto} no existe."}), 404

        # Actualizar en MySQL únicamente la ruta relativa
        sql_update = "UPDATE productos SET imagen = %s WHERE id_producto = %s;"
        cursor.execute(sql_update, (relative_url, id_producto))
        conn.commit()

        return jsonify({
            "mensaje": f"Fotografía para el producto '{prod['nombre']}' actualizada con éxito.",
            "id_producto": id_producto,
            "imagen_url": relative_url,
            "almacenamiento_fisico": "backend/static/uploads"
        }), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
