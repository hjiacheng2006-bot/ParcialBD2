from flask import Blueprint, jsonify
import mysql.connector
from mysql.connector import Error
from config import get_db_connection
from errors import sanitizar_error_db

# Blueprint de Reportes y Analítica Avanzada (Punto 2)
reportes_bp = Blueprint('reportes', __name__, url_prefix='/api/reportes')


@reportes_bp.route('/top-productos', methods=['GET'])
def top_productos():
    """
    PUNTO 2.1: Retorna los 5 productos más vendidos históricamente.
    Utiliza INNER JOIN (detalleventa, productos, ventas), GROUP BY y SUM().
    Excluye las ventas anuladas para preservar la integridad estadística.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            SELECT p.id_producto,
                   p.nombre,
                   CAST(SUM(dv.cantidad) AS SIGNED) AS total_unidades_vendidas,
                   SUM(dv.total_venta) AS total_recaudado
            FROM detalleventa dv
            INNER JOIN productos p ON dv.id_producto = p.id_producto
            INNER JOIN ventas v ON dv.id_venta = v.id_venta
            WHERE v.estado_venta <> 'Anulado'
            GROUP BY p.id_producto, p.nombre
            ORDER BY total_unidades_vendidas DESC
            LIMIT 5;
        """
        cursor.execute(sql)
        resultados = cursor.fetchall()
        return jsonify(resultados), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@reportes_bp.route('/inventario-critico', methods=['GET'])
def inventario_critico():
    """
    PUNTO 2.2: Retorna los productos cuya cantidad_stock actual sea menor o igual a su nivel_minimo.
    Permite alertar sobre reabastecimiento urgente de existencias en bodega.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            SELECT id_producto,
                   nombre,
                   cantidad_stock,
                   nivel_minimo,
                   (nivel_minimo - cantidad_stock) AS deficit_unidades,
                   precioCompra,
                   precioVenta,
                   tarifa_iva,
                   estado
            FROM productos
            WHERE estado = 1 AND cantidad_stock <= nivel_minimo
            ORDER BY cantidad_stock ASC;
        """
        cursor.execute(sql)
        resultados = cursor.fetchall()
        return jsonify(resultados), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@reportes_bp.route('/ventas-mensuales', methods=['GET'])
def ventas_mensuales():
    """
    PUNTO 2.3: Retorna el total de ingresos por ventas agrupado por mes durante el año en curso.
    Utiliza funciones de fecha YEAR() y MONTH(), agrupación GROUP BY y sumatoria SUM().
    Excluye las transacciones anuladas.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            SELECT MONTH(fecha_venta) AS mes_numero,
                    MAX(CASE MONTH(fecha_venta)
                        WHEN 1 THEN 'Enero'
                        WHEN 2 THEN 'Febrero'
                        WHEN 3 THEN 'Marzo'
                        WHEN 4 THEN 'Abril'
                        WHEN 5 THEN 'Mayo'
                        WHEN 6 THEN 'Junio'
                        WHEN 7 THEN 'Julio'
                        WHEN 8 THEN 'Agosto'
                        WHEN 9 THEN 'Septiembre'
                        WHEN 10 THEN 'Octubre'
                        WHEN 11 THEN 'Noviembre'
                        WHEN 12 THEN 'Diciembre'
                    END) AS mes_nombre,
                    COUNT(id_venta) AS total_transacciones,
                    COALESCE(SUM(total_venta), 0.00) AS total_ingresos
            FROM ventas
            WHERE estado_venta <> 'Anulado'
              AND YEAR(fecha_venta) = YEAR(CURDATE())
            GROUP BY MONTH(fecha_venta)
            ORDER BY mes_numero ASC;
        """
        cursor.execute(sql)
        resultados = cursor.fetchall()
        return jsonify(resultados), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
