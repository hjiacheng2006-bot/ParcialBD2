from flask import Blueprint, jsonify, request
import mysql.connector
from mysql.connector import Error
from config import get_db_connection
from errors import sanitizar_error_db

# Blueprint de Terceros
terceros_bp = Blueprint('terceros', __name__, url_prefix='/api/terceros')


@terceros_bp.route('/', methods=['GET'])
def obtener_terceros():
    """
    Endpoint para consultar el directorio de terceros.
    Por defecto retorna todos los terceros (activos e inactivos) ordenados por estado,
    permitiendo al frontend mostrar opciones de inactivar o volver a activar.
    Si se especifica ?activos=1, filtra exclusivamente los activos (estado = 1).
    Utiliza SQL crudo y cursor en modo diccionario (dictionary=True).
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        solo_activos = request.args.get('activos') in ('1', 'true', 'si')
        if solo_activos:
            sql = "SELECT id_tercero, nombre, correo, contacto, estado FROM terceros WHERE estado = 1 ORDER BY id_tercero ASC;"
        else:
            sql = "SELECT id_tercero, nombre, correo, contacto, estado FROM terceros ORDER BY estado DESC, id_tercero ASC;"

        cursor.execute(sql)
        terceros = cursor.fetchall()
        return jsonify(terceros), 200
    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/', methods=['POST'])
def crear_tercero():
    """
    Endpoint para registrar un nuevo tercero (cliente o proveedor).
    Espera un JSON con: nombre, correo, contacto.
    """
    datos = request.json

    if not datos or 'nombre' not in datos or 'correo' not in datos or 'contacto' not in datos:
        return jsonify({"error": "Todos los campos ('nombre', 'correo', 'contacto') son obligatorios."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            INSERT INTO terceros
            (nombre, correo, contacto)
            VALUES (%s, %s, %s)
        """

        valores = (
            datos['nombre'],
            datos['correo'],
            datos['contacto']
        )

        cursor.execute(sql, valores)
        conn.commit()

        id_nuevo = cursor.lastrowid
        return jsonify({
            "mensaje": "Tercero creado con éxito",
            "id_tercero": id_nuevo
        }), 201

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/<int:id_tercero>', methods=['DELETE'])
def eliminar_tercero(id_tercero):
    """
    Endpoint para realizar un borrado lógico (Soft Delete) de un tercero (cambia estado a 0).
    Ejemplo: DELETE /api/terceros/3

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué trigger se dispara en MySQL con esta acción?
      Se dispara el trigger `terceros_BEFORE_UPDATE` sobre la tabla `terceros`.
    - ¿Qué tarea realiza por debajo?
      Verifica si el tercero tiene transacciones comerciales asociadas consultando la tabla ventas:
      `SELECT COUNT(*) INTO cantidad_ventas FROM ventas WHERE id_tercero = OLD.id_tercero;`
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      Si cantidad_ventas > 0, dispara `SIGNAL SQLSTATE '45000'` con:
      'Acción denegada: No se puede eliminar el cliente porque tiene ventas registradas en el sistema.'
      Flask captura la excepción específica `mysql.connector.Error`, realiza rollback y
      responde con código HTTP 400 Bad Request.
    ========================================================================================
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = "UPDATE terceros SET estado = 0 WHERE id_tercero = %s"
        cursor.execute(sql, (id_tercero,))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "Tercero no encontrado o ya estaba inactivo."}), 404

        return jsonify({"mensaje": f"Tercero {id_tercero} inactivado correctamente."}), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/<int:id_tercero>/activar', methods=['PUT'])
@terceros_bp.route('/<int:id_tercero>/reactivar', methods=['PUT'])
def activar_tercero(id_tercero):
    """
    Endpoint para volver a activar un tercero previamente inactivado (Soft Delete -> estado = 1).
    Permite restablecer a clientes o proveedores para que vuelvan a estar disponibles
    en el proceso de facturación y pedidos sin ser bloqueados por el trigger de cascada.
    Utiliza 100% SQL crudo, cursores en modo diccionario (dictionary=True)
    y captura estricta de mysql.connector.Error.
    Ejemplo: PUT /api/terceros/3/activar
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Verificar si el tercero existe
        cursor.execute("SELECT id_tercero, nombre, estado FROM terceros WHERE id_tercero = %s;", (id_tercero,))
        tercero = cursor.fetchone()

        if not tercero:
            return jsonify({"error": f"Tercero con ID {id_tercero} no encontrado."}), 404

        if tercero['estado'] == 1:
            return jsonify({
                "mensaje": f"El tercero '{tercero['nombre']}' ya se encuentra activo en el sistema.",
                "id_tercero": id_tercero,
                "estado": 1
            }), 200

        # 2. Reactivar el tercero
        sql = "UPDATE terceros SET estado = 1 WHERE id_tercero = %s"
        cursor.execute(sql, (id_tercero,))
        conn.commit()

        return jsonify({
            "mensaje": f"Tercero '{tercero['nombre']}' reactivado exitosamente.",
            "id_tercero": id_tercero,
            "estado": 1
        }), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
