from flask import Blueprint, jsonify, request
import mysql.connector
from mysql.connector import Error
from config import get_db_connection
from errors import sanitizar_error_db
from routes.auth import login_requerido

# Blueprint de Ventas
ventas_bp = Blueprint('ventas', __name__, url_prefix='/api/ventas')


@ventas_bp.route('/', methods=['GET'])
def obtener_ventas():
    """
    Endpoint para consultar el listado general de ventas.
    100% SQL crudo, cursor con dictionary=True, captura específica de mysql.connector.Error.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        sql = """
            SELECT v.id_venta,
                   v.fecha_venta,
                   v.total_venta,
                   v.estado_venta,
                   v.id_usuario,
                   v.id_tercero,
                   IFNULL(t.nombre, CONCAT('Tercero #', v.id_tercero)) AS nombre_cliente,
                   IFNULL(u.nombre, CONCAT('Usuario #', v.id_usuario)) AS nombre_usuario
            FROM ventas v
            LEFT JOIN terceros t ON v.id_tercero = t.id_tercero
            LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario
            ORDER BY v.id_venta DESC;
        """
        cursor.execute(sql)
        ventas = cursor.fetchall()
        return jsonify(ventas), 200
    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/', methods=['POST'])
@login_requerido
def crear_venta():
    """
    Endpoint para registrar una venta completa (Maestro-Detalle).
    Espera un JSON con la cabecera de la venta y un arreglo de productos:
    {
        "id_tercero": 3,
        "id_usuario": 1,
        "detalles": [
            {"id_producto": 5, "cantidad": 2, "precioUnitario": 120000},
            {"id_producto": 8, "cantidad": 1, "precioUnitario": 45000}
        ]
    }

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué triggers se disparan en MySQL con esta acción?
      1) `ventas_BEFORE_INSERT` (PUNTO 4.3 - Integridad Relacional / Soft Delete en Cascada):
         Se dispara al insertar la cabecera en la tabla `ventas`.
      2) `detalleventa_BEFORE_INSERT` y `detalleventa_AFTER_INSERT`:
         Se disparan al insertar cada ítem en la tabla `detalleventa`.
    - ¿Qué tarea realizan por debajo?
      1) `ventas_BEFORE_INSERT`:
         - Consulta el campo `estado` del cliente en la tabla `terceros`.
         - Si `estado = 0` (cliente inactivo o archivado por Soft Delete), aborta la operación
           inmediatamente con `SIGNAL SQLSTATE '45000'`, impidiendo facturarle.
      2) `detalleventa_BEFORE_INSERT`:
         - Valida que la venta esté en estado 'Pendiente'.
         - Valida que el producto esté activo (estado = 1).
         - Valida que la cantidad sea estrictamente positiva (> 0).
         - Valida existencia suficiente en bodega (cantidad <= cantidad_stock).
      3) `detalleventa_AFTER_INSERT`:
         - Descuenta automáticamente el stock en `productos`: `cantidad_stock = cantidad_stock - NEW.cantidad`.
         - Acumula en tiempo real el valor total en la cabecera `ventas`:
           `total_venta = total_venta + ((cantidad * precioUnitario) * (1 + porcentaje_iva))`.
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      Dispara `SIGNAL SQLSTATE '45000'` con:
      - 'Operación denegada: El cliente seleccionado se encuentra inactivo (Soft Delete).' (Código 1644)
      - 'El producto se encuentra inactivo'
      - 'Cantidad menor a cero, por favor ingrese un valor positivo.'
      - 'Error: Existencias insuficientes. Stock disponible insuficiente para realizar la venta.'
      Flask captura la excepción específica `mysql.connector.Error`, ejecuta rollback
      para revertir cualquier cambio parcial y devuelve código HTTP 400 Bad Request.
    ========================================================================================
    """
    datos = request.json

    id_tercero = datos.get('id_tercero') if datos else None
    if id_tercero is None and datos:
        id_tercero = datos.get('tercero_id_tercero')

    id_usuario = datos.get('id_usuario') if datos else None
    if id_usuario is None and datos:
        id_usuario = datos.get('usuarios_id_usuario')

    if not datos or id_tercero is None or id_usuario is None or 'detalles' not in datos:
        return jsonify({"error": "Faltan datos en la cabecera de la venta (cliente, usuario o productos)."}), 400

    if not isinstance(datos['detalles'], list) or len(datos['detalles']) == 0:
        return jsonify({"error": "La venta debe contener al menos un producto en los detalles."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # PASO 1: INSERTAR LA CABECERA DE LA VENTA
        sql_venta = """
            INSERT INTO ventas (id_usuario, id_tercero)
            VALUES (%s, %s)
        """
        cursor.execute(sql_venta, (id_usuario, id_tercero))
        id_venta_generado = cursor.lastrowid

        # PASO 2: INSERTAR LOS DETALLES DE LA VENTA
        sql_detalle = """
            INSERT INTO detalleventa (id_venta, id_producto, cantidad, precioUnitario)
            VALUES (%s, %s, %s, %s)
        """

        for item in datos['detalles']:
            if 'id_producto' not in item or 'cantidad' not in item or 'precioUnitario' not in item:
                if conn:
                    conn.rollback()
                return jsonify({"error": "Estructura de producto inválida en los detalles."}), 400

            valores_detalle = (
                id_venta_generado,
                item['id_producto'],
                item['cantidad'],
                item['precioUnitario']
            )
            cursor.execute(sql_detalle, valores_detalle)

        # PASO 3: CONFIRMAR LA TRANSACCIÓN GLOBAL
        conn.commit()

        return jsonify({
            "mensaje": "Venta registrada con éxito.",
            "id_venta": id_venta_generado
        }), 201

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>', methods=['GET'])
def obtener_venta_completa(id_venta):
    """
    Endpoint para extraer una venta con todo su detalle (Maestro-Detalle anidado).
    Ejemplo: GET /api/ventas/1
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Extraer la cabecera (Maestro)
        sql_cabecera = """
            SELECT id_venta,
                   fecha_venta,
                   total_venta,
                   estado_venta,
                   id_usuario,
                   id_tercero
            FROM ventas
            WHERE id_venta = %s
        """
        cursor.execute(sql_cabecera, (id_venta,))
        venta = cursor.fetchone()

        if not venta:
            return jsonify({"error": f"Venta con ID {id_venta} no encontrada."}), 404

        # 2. Extraer los detalles con JOIN a productos
        sql_detalles = """
            SELECT dv.id_detalle_venta,
                   dv.id_producto,
                   p.nombre AS nombre_producto,
                   dv.cantidad,
                   dv.precioUnitario,
                   dv.subtotal,
                   dv.porcentaje_iva,
                   dv.total_venta AS total_linea
            FROM detalleventa dv
            INNER JOIN productos p ON dv.id_producto = p.id_producto
            WHERE dv.id_venta = %s
        """
        cursor.execute(sql_detalles, (id_venta,))
        detalles = cursor.fetchall()

        # 3. Anidamiento
        venta['detalles'] = detalles

        return jsonify(venta), 200

    except mysql.connector.Error as e:
        err = e
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>/anular', methods=['PUT'])
@login_requerido
def anular_venta(id_venta):
    """
    PUNTO 1: Anulación segura de ventas (Reversión de inventario vía Triggers).
    Ejemplo: PUT /api/ventas/1/anular

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué trigger se dispara en MySQL con esta acción?
      Se disparan los triggers `ventas_BEFORE_UPDATE` y `ventas_AFTER_UPDATE` sobre `ventas`.
    - ¿Qué tarea realiza por debajo?
      1) `ventas_BEFORE_UPDATE`:
         - Valida si OLD.estado_venta = 'Anulado': Bloquea cualquier intento de modificar una
           transacción ya anulada para garantizar trazabilidad e inmutabilidad contable.
         - Valida si OLD.estado_venta = 'Enviado': Impide anular una venta cuya mercancía ya fue
           despachada al cliente.
      2) `ventas_AFTER_UPDATE`:
         - Al actualizar `estado_venta = 'Anulado'`, MySQL automáticamente ejecuta:
           `UPDATE productos p
            INNER JOIN detalleventa dv ON p.id_producto = dv.id_producto
            SET p.cantidad_stock = p.cantidad_stock + dv.cantidad
            WHERE dv.id_venta = NEW.id_venta;`
           Restituyendo el stock de todos los artículos de la venta sin requerir cálculos en Python.
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      Dispara `SIGNAL SQLSTATE '45000'` con:
      - 'Error: Una venta anulada no puede volver a cambiarse de estado por seguridad contable.'
      - 'Error: No se puede anular una venta que ya ha sido enviada al cliente.'
      Flask captura la excepción específica `mysql.connector.Error`, realiza rollback y
      retorna la respuesta adecuada con código HTTP 400 Bad Request.
    ========================================================================================
    """
    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Verificar existencia de la venta
        sql_check = "SELECT id_venta, estado_venta FROM ventas WHERE id_venta = %s;"
        cursor.execute(sql_check, (id_venta,))
        venta = cursor.fetchone()

        if not venta:
            return jsonify({"error": f"Venta con ID {id_venta} no encontrada."}), 404

        # 2. Actualizar el estado de la venta a 'Anulado'
        # El backend ejecuta el UPDATE del estado; la base de datos se encarga de revertir el stock
        sql_anular = "UPDATE ventas SET estado_venta = 'Anulado' WHERE id_venta = %s;"
        cursor.execute(sql_anular, (id_venta,))
        conn.commit()

        return jsonify({
            "mensaje": f"Venta {id_venta} anulada exitosamente.",
            "estado_anterior": venta['estado_venta'],
            "nuevo_estado": "Anulado"
        }), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>/estado', methods=['PUT'])
def modificar_estado_venta(id_venta):
    """
    Endpoint para modificar el estado de una venta existente.
    Estados válidos: 'Pendiente', 'Pagado', 'Anulado', 'Enviado', 'Por Pagar'.

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué trigger se dispara en MySQL con esta acción?
      Se disparan los triggers `ventas_BEFORE_UPDATE` y `ventas_AFTER_UPDATE` sobre `ventas`.
    - ¿Qué tarea realiza por debajo?
      1) `ventas_BEFORE_UPDATE`:
         - Valida que la venta no esté anulada previamente (OLD.estado_venta = 'Anulado').
         - Si se cambia a 'Anulado' y la mercancía ya fue enviada ('Enviado'), bloquea la operación.
      2) `ventas_AFTER_UPDATE`:
         - Si el nuevo estado es 'Anulado', devuelve automáticamente el stock de todos los
           productos de la venta mediante un INNER JOIN entre `productos` y `detalleventa`.
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      Dispara `SIGNAL SQLSTATE '45000'` con:
      - 'Error: Una venta anulada no puede volver a cambiarse de estado por seguridad contable.'
      - 'Error: No se puede anular una venta que ya ha sido enviada al cliente.'
      Flask captura la excepción específica `mysql.connector.Error`, realiza rollback y
      devuelve código HTTP 400 Bad Request.
    ========================================================================================
    """
    datos = request.json or {}
    nuevo_estado = datos.get('estado_venta')

    estados_permitidos = ['Pendiente', 'Pagado', 'Anulado', 'Enviado', 'Por Pagar']
    if not nuevo_estado or nuevo_estado not in estados_permitidos:
        return jsonify({
            "error": f"Estado no válido. Debe ser uno de los siguientes: {', '.join(estados_permitidos)}"
        }), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Verificar si la venta existe
        sql_check = "SELECT id_venta, estado_venta, total_venta FROM ventas WHERE id_venta = %s;"
        cursor.execute(sql_check, (id_venta,))
        venta = cursor.fetchone()

        if not venta:
            return jsonify({"error": f"Venta con ID {id_venta} no encontrada."}), 404

        estado_anterior = venta['estado_venta']

        if estado_anterior == nuevo_estado:
            return jsonify({
                "mensaje": f"La venta ya se encuentra en estado '{nuevo_estado}'.",
                "estado_anterior": estado_anterior,
                "nuevo_estado": nuevo_estado
            }), 200

        # 2. Actualizar el estado de la venta
        # Triggers validarán la transición y sincronizarán stock si pasa a 'Anulado'
        sql_update = "UPDATE ventas SET estado_venta = %s WHERE id_venta = %s;"
        cursor.execute(sql_update, (nuevo_estado, id_venta))
        conn.commit()

        return jsonify({
            "mensaje": f"Estado de la venta {id_venta} actualizado exitosamente.",
            "estado_anterior": estado_anterior,
            "nuevo_estado": nuevo_estado
        }), 200

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>/productos', methods=['POST'])
def agregar_producto_a_venta(id_venta):
    """
    Endpoint para agregar productos a una venta existente en espera ('Pendiente').
    Payload esperado:
    {
        "id_producto": 1,
        "cantidad": 2,
        "precioUnitario": 120000.00
    }

    ========================================================================================
    DOCUMENTACIÓN DE TRIGGERS:
    - ¿Qué trigger se dispara en MySQL con esta acción?
      Se disparan los triggers `detalleventa_BEFORE_INSERT` y `detalleventa_AFTER_INSERT`.
    - ¿Qué tarea realiza por debajo?
      1) `detalleventa_BEFORE_INSERT`:
         - Valida que la venta esté en espera ('Pendiente'). Si no lo está, lanza SIGNAL 45000.
         - Valida que el producto esté activo (estado = 1).
         - Valida que la cantidad sea > 0.
         - Valida que haya stock suficiente en la tabla `productos`.
      2) `detalleventa_AFTER_INSERT`:
         - Descuenta el stock en `productos` (`cantidad_stock = cantidad_stock - NEW.cantidad`).
         - Acumula el total con IVA en la cabecera `ventas.total_venta`.
    - ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?
      Dispara `SIGNAL SQLSTATE '45000'` con:
      - 'Error: Solo se pueden agregar productos a una venta en estado Pendiente (en espera).'
      - 'El producto se encuentra inactivo'
      - 'Cantidad menor a cero, por favor ingrese un valor positivo.'
      - 'Error: Existencias insuficientes. Stock disponible insuficiente para realizar la venta.'
      Flask captura la excepción específica `mysql.connector.Error`, realiza rollback y
      devuelve código HTTP 400 Bad Request.
    ========================================================================================
    """
    datos = request.json or {}
    id_producto = datos.get('id_producto')
    cantidad = datos.get('cantidad')
    precio_unitario = datos.get('precioUnitario')

    if not id_producto or cantidad is None:
        return jsonify({"error": "Debe proporcionar 'id_producto' y 'cantidad'."}), 400

    try:
        cantidad = int(cantidad)
        if cantidad <= 0:
            return jsonify({"error": "La cantidad debe ser un entero positivo mayor a cero."}), 400
    except (ValueError, TypeError):
        return jsonify({"error": "La cantidad debe ser un número entero válido."}), 400

    conn = None
    cursor = None

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Validar existencia y estado de la venta
        sql_venta = "SELECT id_venta, estado_venta, total_venta FROM ventas WHERE id_venta = %s;"
        cursor.execute(sql_venta, (id_venta,))
        venta = cursor.fetchone()

        if not venta:
            return jsonify({"error": f"Venta con ID {id_venta} no encontrada."}), 404

        if venta['estado_venta'] != 'Pendiente':
            return jsonify({
                "error": f"No se pueden agregar productos a la venta {id_venta}. Solo se permite agregar productos a ventas en espera ('Pendiente'). Estado actual: '{venta['estado_venta']}'."
            }), 400

        # 2. Si no se especificó precioUnitario, obtenerlo de la tabla de productos
        if precio_unitario is None:
            sql_prod = "SELECT precioCompra FROM productos WHERE id_producto = %s;"
            cursor.execute(sql_prod, (id_producto,))
            prod = cursor.fetchone()
            if not prod:
                return jsonify({"error": f"Producto con ID {id_producto} no encontrado."}), 404
            precio_unitario = float(prod['precioCompra'])
        else:
            try:
                precio_unitario = float(precio_unitario)
                if precio_unitario <= 0:
                    return jsonify({"error": "El precio unitario debe ser mayor a cero."}), 400
            except (ValueError, TypeError):
                return jsonify({"error": "El precio unitario debe ser un valor numérico válido."}), 400

        # 3. Insertar el nuevo detalle (dispara triggers BEFORE_INSERT y AFTER_INSERT)
        sql_insert = """
            INSERT INTO detalleventa (id_venta, id_producto, cantidad, precioUnitario)
            VALUES (%s, %s, %s, %s);
        """
        cursor.execute(sql_insert, (id_venta, id_producto, cantidad, precio_unitario))
        id_detalle_generado = cursor.lastrowid

        # 4. Obtener el total_venta actualizado generado automáticamente por el trigger
        cursor.execute("SELECT total_venta, estado_venta FROM ventas WHERE id_venta = %s;", (id_venta,))
        venta_actualizada = cursor.fetchone()

        conn.commit()

        return jsonify({
            "mensaje": f"Producto agregado exitosamente a la venta {id_venta}.",
            "id_detalle_venta": id_detalle_generado,
            "id_venta": id_venta,
            "id_producto": id_producto,
            "cantidad": cantidad,
            "precioUnitario": precio_unitario,
            "nuevo_total_venta": float(venta_actualizada['total_venta']) if venta_actualizada else None
        }), 201

    except mysql.connector.Error as e:
        err = e
        if conn:
            conn.rollback()
        payload, status = sanitizar_error_db(err)
        return jsonify(payload), status
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
