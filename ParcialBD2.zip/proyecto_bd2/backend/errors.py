"""
Módulo de manejo, privacidad y sanitización de errores de base de datos.
Garantiza el 100% de confidencialidad de la infraestructura relacional,
impidiendo la exposición hacia el cliente/frontend de:
- Nombres de esquemas y bases de datos (`erp`, `mysql`)
- Nombres de tablas (`usuarios`, `terceros`, `ventas`, `detalleventa`, `recibos_caja`)
- Nombres de columnas o claves (`id_usuario`, `password`, `precioVenta`)
- Nombres de constraints relacionales (`fk_ventas_usuarios1`, `correo_UNIQUE`)
- Sentencias SQL o planes de ejecución
- Rutas físicas del servidor y trazas de error
"""
import mysql.connector
from mysql.connector import Error


def sanitizar_error_db(err):
    """
    Convierte una excepción de base de datos en un mensaje corto, limpio y privado.
    Retorna una tupla: (dict_respuesta, status_http).
    """
    codigo = getattr(err, 'errno', None)
    msg_raw = str(getattr(err, 'msg', err))

    # Log seguro en terminal/servidor para fines de depuración interna y auditoría
    print(f"[AUDITORIA INTERNA BD] Código: {codigo} | Detalle técnico: {msg_raw}")

    # 1. Reglas de Negocio lanzadas intencionalmente por Triggers (SIGNAL SQLSTATE '45000' -> errno 1644)
    if codigo == 1644:
        msg_limpio = msg_raw.replace('Error: ', '').strip()
        return {
            "error": msg_limpio,
            "error_db": msg_limpio,
            "codigo": 1644
        }, 400

    # 2. Violación de Claves Foráneas (1451: borrado restringido con hijos, 1452: referencia inexistente)
    # Oculta nombres de constraints como fk_ventas_usuarios1, esquemas y tablas
    if codigo in (1451, 1452):
        mensaje = "Operación no permitida: el registro relacionado no existe o cuenta con dependencias activas."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 400

    # 3. Registros duplicados en índices UNIQUE (1062)
    # Oculta el nombre del índice o de la tabla (ej. correo_UNIQUE)
    if codigo == 1062:
        mensaje = "El registro ya existe en el sistema (valor duplicado)."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 400

    # 4. Campos requeridos no nulos faltantes o sin valor por defecto (1048, 1364)
    if codigo in (1048, 1364):
        mensaje = "Faltan campos obligatorios para procesar la transacción."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 400

    # 5. Restricciones de validación de datos (CHECK constraints 3819)
    if codigo == 3819:
        mensaje = "Los datos ingresados no cumplen con las reglas de validación del sistema."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 400

    # 6. Desbordamiento o truncamiento de longitud en datos (1264, 1406)
    if codigo in (1264, 1406):
        mensaje = "Uno o más valores exceden la longitud o el rango permitido."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 400

    # 7. Concurrencia, bloqueos y deadlocks temporales (1205, 1213)
    if codigo in (1205, 1213):
        mensaje = "La operación no pudo completarse debido a concurrencia. Por favor reintente."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 409

    # 8. Problemas de conexión o timeout con MySQL (2002, 2003, 2006, 2013)
    if codigo in (2002, 2003, 2006, 2013):
        mensaje = "El servicio de datos no está disponible en este momento."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 503

    # 9. Columnas o tablas no disponibles / error sintáctico (1054, 1146, 1064)
    # Oculta nombres de columnas o consultas SQL internas
    if codigo in (1054, 1146, 1064):
        mensaje = "Consulta o entidad de base de datos no disponible."
        return {
            "error": mensaje,
            "error_db": mensaje,
            "codigo": codigo
        }, 500

    # 10. Cualquier otro error interno de base de datos
    # Mensaje genérico privado que nunca expone metadatos de SQL
    mensaje = "No fue posible procesar la operación en la base de datos."
    return {
        "error": mensaje,
        "error_db": mensaje,
        "codigo": codigo or 500
    }, 500


def sanitizar_error_inesperado(err):
    """
    Sanitiza errores no controlados para no filtrar rutas de archivo o código.
    """
    print(f"[AUDITORIA INTERNA SERVIDOR] Detalle: {err}")
    return {
        "error": "Error interno del servidor. Por favor intente más tarde."
    }, 500
