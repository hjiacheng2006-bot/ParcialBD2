import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def create_apa_report():
    doc = docx.Document()

    # 1. Configurar márgenes reglamentarios APA (2.54 cm = 1 pulgada)
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.page_width = Inches(8.5)
        section.page_height = Inches(11.0)

    # 2. Configuración de estilo Normal (Times New Roman 12pt, interlineado 1.5)
    style_normal = doc.styles['Normal']
    font = style_normal.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    font.color.rgb = RGBColor(17, 24, 39)
    style_normal.paragraph_format.line_spacing = 1.5
    style_normal.paragraph_format.space_after = Pt(6)
    style_normal.paragraph_format.space_before = Pt(0)

    def add_p(text, bold_prefix="", indent=True):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        if indent:
            p.paragraph_format.first_line_indent = Inches(0.5)
        if bold_prefix:
            run_b = p.add_run(bold_prefix)
            run_b.bold = True
            run_b.font.name = 'Times New Roman'
        run_t = p.add_run(text)
        run_t.font.name = 'Times New Roman'
        return p

    def add_h1(text):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(18)
        p.paragraph_format.space_after = Pt(8)
        p.paragraph_format.first_line_indent = Inches(0)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(text)
        run.bold = True
        run.font.name = 'Times New Roman'
        run.font.size = Pt(14)
        run.font.color.rgb = RGBColor(15, 23, 42)
        return p

    def add_h2(text):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.first_line_indent = Inches(0)
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = p.add_run(text)
        run.bold = True
        run.font.name = 'Times New Roman'
        run.font.size = Pt(12.5)
        run.font.color.rgb = RGBColor(30, 41, 59)
        return p

    def add_bullet(bold_label, text):
        p = doc.add_paragraph(style='List Bullet')
        p.paragraph_format.line_spacing = 1.3
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.first_line_indent = Inches(0)
        run_b = p.add_run(bold_label)
        run_b.bold = True
        run_b.font.name = 'Times New Roman'
        run_t = p.add_run(text)
        run_t.font.name = 'Times New Roman'
        return p

    def add_figure(number, title, code_block, note):
        p_num = doc.add_paragraph()
        p_num.paragraph_format.first_line_indent = Inches(0)
        p_num.paragraph_format.space_before = Pt(12)
        p_num.paragraph_format.space_after = Pt(2)
        run_num = p_num.add_run(f"Figura {number}")
        run_num.bold = True
        run_num.font.name = 'Times New Roman'
        run_num.font.size = Pt(11)

        p_title = doc.add_paragraph()
        p_title.paragraph_format.first_line_indent = Inches(0)
        p_title.paragraph_format.space_after = Pt(6)
        run_title = p_title.add_run(title)
        run_title.italic = True
        run_title.font.name = 'Times New Roman'
        run_title.font.size = Pt(11)

        # Caja para el contenido tipo terminal / Bruno
        tbl = doc.add_table(rows=1, cols=1)
        tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        cell = tbl.cell(0, 0)
        cell.width = Inches(6.5)
        set_cell_background(cell, "F8FAFC")
        set_cell_margins(cell, top=140, bottom=140, left=180, right=180)

        p_code = cell.paragraphs[0]
        p_code.paragraph_format.line_spacing = 1.15
        p_code.paragraph_format.space_after = Pt(0)
        p_code.paragraph_format.first_line_indent = Inches(0)
        run_c = p_code.add_run(code_block)
        run_c.font.name = 'Consolas'
        run_c.font.size = Pt(9.5)
        run_c.font.color.rgb = RGBColor(30, 41, 59)

        p_note = doc.add_paragraph()
        p_note.paragraph_format.first_line_indent = Inches(0)
        p_note.paragraph_format.space_before = Pt(4)
        p_note.paragraph_format.space_after = Pt(14)
        run_lbl = p_note.add_run("Nota. ")
        run_lbl.italic = True
        run_lbl.font.name = 'Times New Roman'
        run_lbl.font.size = Pt(10)
        run_note = p_note.add_run(note)
        run_note.font.name = 'Times New Roman'
        run_note.font.size = Pt(10)
        run_note.font.color.rgb = RGBColor(71, 85, 105)

    # ==================== PORTADA APA 7 ====================
    for _ in range(3):
        doc.add_paragraph()

    p_title_main = doc.add_paragraph()
    p_title_main.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title_main.paragraph_format.first_line_indent = Inches(0)
    p_title_main.paragraph_format.line_spacing = 1.4
    run_tm = p_title_main.add_run("SISTEMA ERP MODULAR: ARQUITECTURA TRANSACCIONAL, AUDITORÍA DE TRIGGERS Y MÉTRICAS ANALÍTICAS AVANZADAS")
    run_tm.bold = True
    run_tm.font.size = Pt(16)
    run_tm.font.name = 'Times New Roman'

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.first_line_indent = Inches(0)
    p_sub.paragraph_format.space_before = Pt(8)
    p_sub.paragraph_format.space_after = Pt(40)
    run_sub = p_sub.add_run("Informe Técnico de Desarrollo y Evidencias de Validación de API REST en Bruno\n(Fase 2 - Entrega Definitiva y Sustentación)")
    run_sub.font.size = Pt(12.5)
    run_sub.font.name = 'Times New Roman'
    run_sub.italic = True
    run_sub.font.color.rgb = RGBColor(75, 85, 99)

    for _ in range(4):
        doc.add_paragraph()

    p_meta = doc.add_paragraph()
    p_meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_meta.paragraph_format.first_line_indent = Inches(0)
    p_meta.paragraph_format.line_spacing = 1.6
    
    meta_runs = [
        ("Equipo de Desarrollo ERP\n", True),
        ("Asignatura: Bases de Datos II\n", False),
        ("Docente: Titular de Cátedra de Bases de Datos\n", False),
        ("Corporación de Estudios Tecnológicos del Norte del Valle (COTECNOVA)\n", False),
        ("Tecnología en Desarrollo de Software\n", False),
        ("Noviembre 25 de 2026", False)
    ]
    for m_text, m_bold in meta_runs:
        r = p_meta.add_run(m_text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(11.5)
        r.bold = m_bold

    doc.add_page_break()

    # ==================== SECCIÓN 1 ====================
    add_h1("1. Descripción y Arquitectura del Sistema ERP")

    add_p("El presente proyecto técnico consolida la plataforma empresarial ERP desarrollada mediante el framework web Flask (Python 3.14) y el motor relacional MySQL 8.0/5.7, orquestada de forma aislada a través de contenedores Docker. El sistema centraliza la facturación comercial maestro-detalle, el control de existencias de inventario, el directorio de clientes y proveedores (terceros), la analítica de negocio multidimensional y la administración de cartera y usuarios.")

    add_h2("1.1. Cláusula de Desarrollo Agéntico y Reglas de Código (Innegociables)")
    add_p("En cumplimiento estricto con las directrices obligatorias de la cátedra de Bases de Datos II para el desarrollo con copilotos de Inteligencia Artificial, la totalidad de los archivos del repositorio fue auditada bajo tres reglas técnicas innegociables:")

    add_bullet("1. Cero Magia (No ORMs): ", "Queda estrictamente prohibido el empleo de SQLAlchemy, Flask-SQLAlchemy o cualquier biblioteca ORM. Todo el acceso a datos se ejecuta mediante SQL crudo utilizando el conector nativo mysql-connector-python y cursores configurados exclusivamente en modo diccionario (dictionary=True), garantizando transacciones ACID directas y cero sobrecosto de memoria.")
    add_bullet("2. Auditoría Estricta de Errores de Base de Datos: ", "En todo bloque try-except del backend es obligatorio importar y capturar de forma específica la excepción mysql.connector.Error. Se prohíbe tajantemente el uso de capturas genéricas (except Exception as e:) para evaluar reglas de negocio o disparos de triggers (SIGNAL SQLSTATE), asegurando trazabilidad y sanitización centralizada.")
    add_bullet("3. Documentación Obligatoria de Triggers en Código: ", "Cada endpoint que interactúe con una tabla provista de triggers incorpora un comentario de bloque en Python respondiendo taxativamente a tres interrogantes: ¿Qué trigger se dispara en MySQL con esta acción? ¿Qué tarea realiza por debajo? ¿Qué SQLSTATE o mensaje de error podría devolver hacia Flask?")

    add_h2("1.2. Organización Modular por Blueprints")
    add_p("El código del backend se organizó modularmente bajo una arquitectura de Blueprints, separando de forma limpia las responsabilidades del dominio de negocio:")

    add_bullet("Blueprint de Ventas (ventas_bp): ", "Prefijo /api/ventas. Gestiona facturación maestro-detalle, anulación de transacciones con reversión de inventario por trigger, conmutación de estados y adición de productos a ventas pendientes.")
    add_bullet("Blueprint de Reportes (reportes_bp): ", "Prefijo /api/reportes. Computa indicadores agregados de negocio mediante consultas con INNER JOIN, sumatorias y agrupaciones mensuales.")
    add_bullet("Blueprint de Productos (productos_bp): ", "Prefijo /api/productos. Administra el catálogo de inventario, filtros dinámicos parametrizados (%s) y soft delete condicionado.")
    add_bullet("Blueprint de Terceros (terceros_bp): ", "Prefijo /api/terceros. Gestiona clientes y proveedores con validación de dependencias contables previas al borrado lógico.")
    add_bullet("Blueprint de Autenticación (auth_bp): ", "Prefijo /api/auth. Proporciona validación segura de credenciales de operadores contra la tabla usuarios y auditoría de cuentas activas.")
    add_bullet("Blueprint de Cartera (cartera_bp): ", "Prefijo /api/cartera. Administra cuentas por cobrar vinculadas a clientes y registro de abonos financieros que liquidan las ventas pendientes.")

    # ==================== SECCIÓN 2 ====================
    add_h1("2. Documentación Paso a Paso del Desarrollo Técnico")

    add_h2("2.1. Reversión de Ventas y Funcionamiento de Triggers en MySQL (Punto 1)")
    add_p("La anulación de transacciones (PUT /api/ventas/<id>/anular) prohíbe explícitamente realizar cálculos de reposición de inventario en Python. Toda la integridad es delegada al motor relacional a través de dos triggers sincronizados:")

    add_bullet("ventas_BEFORE_UPDATE: ", "Se activa antes de modificar cualquier registro en ventas. Evalúa si OLD.estado_venta = 'Anulado'; de ser así, dispara SIGNAL SQLSTATE '45000' bloqueando cualquier alteración posterior para asegurar inmutabilidad contable. Igualmente, si la venta ya posee estado 'Enviado', impide su cancelación.")
    add_bullet("ventas_AFTER_UPDATE: ", "Se activa inmediatamente tras confirmarse el cambio a 'Anulado'. Ejecuta un UPDATE masivo con INNER JOIN entre productos y detalleventa: UPDATE productos p INNER JOIN detalleventa dv ON p.id_producto = dv.id_producto SET p.cantidad_stock = p.cantidad_stock + dv.cantidad WHERE dv.id_venta = NEW.id_venta; restituyendo las existencias de forma atómica.")

    add_h2("2.2. Modificación de Estados y Adición de Artículos en Espera")
    add_p("Se diseñó el endpoint PUT /api/ventas/<id>/estado para alternar de manera controlada entre los estados comerciales ('Pendiente', 'Pagado', 'Enviado', 'Por Pagar' y 'Anulado'), activando los triggers de reversión de inventario de forma transparente si la venta se anula.")
    add_p("Asimismo, el endpoint POST /api/ventas/<id>/productos permite añadir líneas de artículos a una venta existente siempre y cuando se encuentre en estado 'Pendiente' (en espera). El trigger detalleventa_BEFORE_INSERT valida el estado de la cabecera, la condición activa del producto y la disponibilidad de stock, mientras que detalleventa_AFTER_INSERT rebaja las unidades de bodega y suma el nuevo subtotal con IVA al total de la factura.")

    add_h2("2.3. Consultas Analíticas Avanzadas (Blueprint reportes_bp)")
    add_p("El módulo de analítica expone tres endpoints agregados de alto rendimiento:")
    add_bullet("Top 5 Productos Más Vendidos: ", "Cruza detalleventa, productos y ventas descartando anulaciones, consolidando el volumen total facturado mediante SUM(dv.cantidad) y SUM(dv.total_venta).")
    add_bullet("Inventario Crítico: ", "Filtra productos donde cantidad_stock <= nivel_minimo, calculando el déficit de unidades exacto para alertar compras.")
    add_bullet("Ventas Mensuales: ", "Agrupa transacciones por mes durante el año en curso (YEAR(CURDATE())). Se aseguró compatibilidad con el modo ONLY_FULL_GROUP_BY de MySQL 8 envolviendo el nombre del mes en funciones agregadas deterministas (MAX(CASE...)).")

    add_h2("2.4. Búsqueda Dinámica y Paginación Segura")
    add_p("El catálogo GET /api/productos/ integra filtrado dinámico mediante parámetros URL (?nombre=teclado&page=1&limit=5). La sentencia SQL se construye concatenando cláusulas LIKE %s con parámetros aislados, neutralizando cualquier riesgo de inyección de código SQL.")

    add_h2("2.5. Privacidad y Sanitización de Errores de Base de Datos")
    add_p("Se implementó el módulo backend/errors.py para sanitizar las excepciones de base de datos. Se transformaron los códigos nativos (1451, 1452, 1062, 1048) en mensajes cortos y seguros para el usuario, protegiendo nombres de tablas, esquemas, columnas o llaves foráneas y registrando la auditoría técnica únicamente en los logs del servidor.")

    add_h2("2.6. Módulos Adicionales Desarrollados (Punto 4)")
    add_p("En cumplimiento con los requerimientos complementarios de la Fase 2, se integraron cuatro subsistemas avanzados que potencian la seguridad, la liquidez financiera, la integridad relacional y el soporte multimedia del ERP:")

    add_bullet("1. Autenticación Básica y Seguridad (@login_requerido): ", "Se construyó el endpoint POST /api/auth/login, el cual valida correo y contraseña contra la tabla usuarios mediante SQL crudo y parámetros %s. Al comprobar credenciales válidas y usuario activo (estado = 1), genera un token de sesión seguro (erp_token_<id>_<timestamp>). Paralelamente, se implementó el decorador personalizado @login_requerido en Python, el cual intercepta los encabezados 'Authorization: Bearer <token>' o 'X-Auth-Token' y bloquea con HTTP 401 cualquier intento no autenticado de registrar ventas (POST /api/ventas/) o anular transacciones (PUT /api/ventas/<id>/anular).")

    add_bullet("2. Transacciones Financieras (Cartera y Abonos): ", "Se incorporó el soporte para ventas a crédito asignándoles el estado comercial 'Por Pagar'. Para llevar el historial fidedigno de recaudos, se creó la tabla auxiliar recibos_caja (id_recibo, id_venta, fecha_recibo, monto, observacion). Cada abono registrado a través de POST /api/cartera/<id>/abono dispara en MySQL el trigger recibos_caja_AFTER_INSERT, el cual computa dinámicamente la sumatoria de todos los abonos existentes (SUM(monto)) y la compara con el total de la factura. Si la sumatoria cubre o supera la deuda, el trigger conmuta automáticamente el estado a 'Pagado'; en caso de saldo residual, mantiene la venta en 'Por Pagar'.")

    add_bullet("3. Integridad Relacional (Soft Delete en Cascada): ", "Para prevenir inconsistencias comerciales y de despachos, se implementaron los triggers ventas_BEFORE_INSERT y pedidos_BEFORE_INSERT. Cuando un operador intenta registrar una nueva venta o pedido asignado a un cliente o proveedor cuyo estado sea 0 (inactivo o borrado lógico), el trigger detiene inmediatamente la ejecución disparando SIGNAL SQLSTATE '45000' con el mensaje 'Operación denegada: El cliente/proveedor seleccionado se encuentra inactivo (Soft Delete)'. Flask captura esta excepción mediante mysql.connector.Error y devuelve un código HTTP 400 Bad Request completamente controlado.")

    add_bullet("4. Manejo de Archivos Estáticos (Subida de Imágenes): ", "Se habilitó el endpoint POST /api/productos/<id_producto>/imagen utilizando el objeto nativo request.files de Flask. El sistema procesa la imagen multipart, valida la extensión permitida (PNG, JPG, JPEG, WEBP, GIF), la almacena físicamente en el directorio del servidor /static/uploads/ bajo una convención segura con timestamp, y en la columna productos.imagen de MySQL almacena únicamente la ruta relativa en formato de texto (/uploads/nombre_archivo.ext). Esta arquitectura separa eficientemente el almacenamiento binario de alta densidad del motor relacional.")

    doc.add_page_break()

    # ==================== SECCIÓN 3 ====================
    add_h1("3. Evidencias de Pruebas y Validación en Bruno")
    add_p("Cada uno de los endpoints fue probado de manera exhaustiva en el cliente HTTP Bruno antes de su integración con la interfaz de usuario. A continuación se presentan las evidencias con sus respectivas respuestas JSON y códigos de estado:")

    add_figure(
        "1",
        "Respuesta JSON de Facturación Maestro-Detalle Exitosa",
        """POST http://localhost:5001/api/ventas/
Status: 201 Created

Headers: Content-Type: application/json
Payload:
{
  "id_tercero": 1,
  "id_usuario": 1,
  "detalles": [
    { "id_producto": 1, "cantidad": 2, "precioUnitario": 120000.00 },
    { "id_producto": 2, "cantidad": 1, "precioUnitario": 45000.00 }
  ]
}

Response Body:
{
  "id_venta": 12,
  "mensaje": "Venta registrada con éxito."
}""",
        "Los triggers detalleventa_BEFORE_INSERT y AFTER_INSERT verificaron la existencia de stock, rebajaron 2 y 1 unidades respectivamente y calcularon el total con IVA en la cabecera de la venta."
    )

    add_figure(
        "2",
        "Reversión Exitosa de Venta y Restauración de Stock por Trigger",
        """PUT http://localhost:5001/api/ventas/12/anular
Status: 200 OK

Response Body:
{
  "estado_anterior": "Pendiente",
  "mensaje": "Venta 12 anulada exitosamente.",
  "nuevo_estado": "Anulado"
}""",
        "El trigger ventas_AFTER_UPDATE restituyó automáticamente las cantidades al inventario de productos en MySQL sin requerir cálculo alguno en Python."
    )

    add_figure(
        "3",
        "Error Controlado por Trigger al Intentar Re-Anular una Venta Anulada",
        """PUT http://localhost:5001/api/ventas/12/anular
Status: 400 Bad Request

Response Body:
{
  "codigo": 1644,
  "error": "Una venta anulada no puede volver a cambiarse de estado por seguridad contable.",
  "error_db": "Una venta anulada no puede volver a cambiarse de estado por seguridad contable."
}""",
        "Disparo de excepción SIGNAL SQLSTATE '45000' lanzada por ventas_BEFORE_UPDATE, capturada estrictamente por mysql.connector.Error."
    )

    add_figure(
        "4",
        "Adición Exitosa de Producto a Venta en Espera (Pendiente)",
        """POST http://localhost:5001/api/ventas/11/productos
Status: 201 Created

Payload:
{
  "id_producto": 3,
  "cantidad": 1,
  "precioUnitario": 85000.00
}

Response Body:
{
  "cantidad": 1,
  "id_detalle_venta": 28,
  "id_producto": 3,
  "id_venta": 11,
  "mensaje": "Producto agregado exitosamente a la venta 11.",
  "nuevo_total_venta": 386750.00,
  "precioUnitario": 85000.00
}""",
        "Comprobación de recalculo automático de total_venta e incremento del detalle en estado Pendiente."
    )

    add_figure(
        "5",
        "Reporte Analítico de Ventas Mensuales Consolidadas del Año en Curso",
        """GET http://localhost:5001/api/reportes/ventas-mensuales
Status: 200 OK

Response Body:
[
  {
    "mes_nombre": "Octubre",
    "mes_numero": 10,
    "total_ingresos": 14250000.00,
    "total_transacciones": 15
  },
  {
    "mes_nombre": "Noviembre",
    "mes_numero": 11,
    "total_ingresos": 8920000.00,
    "total_transacciones": 9
  }
]""",
        "Consulta de reportería con GROUP BY MONTH(fecha_venta) cumpliendo estrictamente con la regla ONLY_FULL_GROUP_BY."
    )

    add_figure(
        "6",
        "Búsqueda Dinámica Parametrizada y Paginada en Catálogo de Productos",
        """GET http://localhost:5001/api/productos/?nombre=teclado&page=1&limit=5
Status: 200 OK

Response Body:
[
  {
    "cantidad_stock": 18,
    "estado": 1,
    "id_producto": 1,
    "nivel_minimo": 5,
    "nombre": "Teclado Mecánico RGB Pro",
    "precioCompra": 80000.00,
    "precioVenta": 120000.00,
    "tarifa_iva": 0.19
  }
]""",
        "Sentencia estructurada con cláusula LIKE %s y segmentación LIMIT 5 OFFSET 0 para prevención de inyección SQL."
    )

    add_figure(
        "7",
        "Autenticación Exitosa de Operador en Módulo de Seguridad",
        """POST http://localhost:5001/api/auth/login
Status: 200 OK

Payload:
{
  "correo": "admin@erp.com",
  "password": "admin123"
}

Response Body:
{
  "mensaje": "Autenticación exitosa",
  "usuario": {
    "correo": "admin@erp.com",
    "id_usuario": 1,
    "nombre": "Administrador del Sistema",
    "roles_id_rol": 1
  }
}""",
        "Verificación de credenciales en SQL crudo validando estado activo del usuario sin exponer contraseñas."
    )

    add_figure(
        "8",
        "Registro de Abono Financiero y Liquidación de Cartera",
        """POST http://localhost:5001/api/cartera/5/abono
Status: 200 OK

Payload:
{
  "monto": 100000.00
}

Response Body:
{
  "estado_anterior": "Por Pagar",
  "id_venta": 5,
  "mensaje": "Abono de $100,000.00 procesado exitosamente para la venta #5.",
  "monto_abonado": 100000.0,
  "nuevo_estado": "Pagado"
}""",
        "Al completarse el monto adeudado, la venta conmuta automáticamente su estado comercial a 'Pagado'."
    )

    add_figure(
        "9",
        "Disparo de Trigger ventas_BEFORE_INSERT por Cliente Inactivo (Soft Delete en Cascada)",
        """POST http://localhost:5001/api/ventas/
Status: 400 Bad Request

Headers:
Authorization: Bearer erp_token_1_demo

Payload:
{
  "id_tercero": 2,
  "id_usuario": 1,
  "detalles": [
    {
      "id_producto": 1,
      "cantidad": 1,
      "precioUnitario": 100000.00
    }
  ]
}

Response Body:
{
  "codigo_error": 1644,
  "error": "Operación denegada: El cliente seleccionado se encuentra inactivo (Soft Delete)."
}""",
        "Bloqueo preventivo en MySQL mediante SIGNAL SQLSTATE '45000' cuando el cliente posee estado = 0."
    )

    add_figure(
        "10",
        "Carga de Imagen de Producto y Persistencia de Ruta Relativa en Base de Datos",
        """POST http://localhost:5001/api/productos/1/imagen
Status: 200 OK

Content-Type: multipart/form-data; boundary=---WebKitFormBoundary...
Payload:
[archivo binario 'teclado_gamer.png' adjunto en campo 'imagen']

Response Body:
{
  "almacenamiento_fisico": "backend/static/uploads",
  "id_producto": 1,
  "imagen_url": "/uploads/prod_1_1764132800_teclado_gamer.png",
  "mensaje": "Fotografía para el producto 'Teclado Mecánico RGB Pro' actualizada con éxito."
}""",
        "Separación de almacenamiento: binario en static/uploads y ruta relativa de texto en MySQL."
    )

    add_figure(
        "11",
        "Control de Seguridad: Acceso Rechazado por Falta de Token de Autenticación",
        """POST http://localhost:5001/api/ventas/
Status: 401 Unauthorized

Payload:
{
  "id_tercero": 1,
  "id_usuario": 1,
  "detalles": [...]
}

Response Body:
{
  "error": "Acceso no autorizado: Se requiere inicio de sesión previo para ejecutar esta operación."
}""",
        "Interceptación realizada por el decorador @login_requerido protegiendo la ruta crítica de facturación."
    )

    doc.add_page_break()

    # ==================== SECCIÓN 4 ====================
    add_h1("4. Conclusiones Técnicas")

    add_p("La finalización de la Fase 2 del proyecto ERP demostró la viabilidad y robustez de una arquitectura transaccional pura basada en SQL crudo y microservicios en Flask. Los principales aprendizajes y hallazgos técnicos son:")

    add_p("1. Soberanía de los Triggers en la Integridad de Datos: Al trasladar la lógica crítica (descuento y reversión de inventario, acumulación tributaria y bloqueos de anulación) a los triggers de MySQL, el sistema se blinda contra inconsistencias. Ninguna aplicación o cliente puede saltarse las políticas contables, garantizando la inviolabilidad del inventario ante operaciones concurrentes.", indent=False)

    add_p("2. Alto Desempeño y Transparencia sin ORMs: La eliminación total de capas ORM como SQLAlchemy permitió diseñar consultas analíticas complejas con funciones de agregación y uniones multieje que se ejecutan a velocidad nativa en MySQL. Además, los cursores de diccionario posibilitaron respuestas JSON directas sin transformaciones intermedias costosas.", indent=False)

    add_p("3. Protección de Privacidad de Infraestructura: La sanitización centralizada de errores técnicos evitó la fuga de metadatos confidenciales (esquemas de bases de datos, nombres de constraints y columnas) hacia el frontend, consolidando una aplicación profesional orientada a producción y segura ante ataques de enumeración.", indent=False)

    add_p("4. Portabilidad y Compatibilidad Universal: La estandarización de colaciones a utf8mb4_general_ci resolvió las discrepancias entre versiones de MySQL (5.7 y 8.0) y MariaDB, permitiendo que tanto el entorno contenerizado en Docker como las instalaciones locales en MySQL Workbench operen de forma idéntica y sin errores de inicialización.", indent=False)

    # Guardar en Desktop y en docs/
    desktop_path = r"C:\Users\hjiac\OneDrive\Desktop\INFORME_TECNICO_APA_ERP_FASE2.docx"
    docs_path = r"C:\Users\hjiac\OneDrive\Desktop\proyecto_bd2\docs\INFORME_TECNICO_APA_ERP_FASE2.docx"

    doc.save(docs_path)
    print(f"Documento guardado en docs: {docs_path}")
    doc.save(desktop_path)
    print(f"Documento guardado en Desktop: {desktop_path}")

if __name__ == '__main__':
    create_apa_report()
