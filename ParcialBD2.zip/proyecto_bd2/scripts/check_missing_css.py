import re

with open('backend/static/index.html', encoding='utf-8') as f:
    text = f.read()

start_idx = text.find('<style id="inlined-tailwind">')
end_idx = text.find('</style>', start_idx)
css = text[start_idx:end_idx]

class_matches = re.findall(r'class="([^"]+)"', text)
all_classes = set()
for cm in class_matches:
    for c in cm.split():
        all_classes.add(c)

missing = []
for c in sorted(all_classes):
    escaped = c.replace(':', '\\:').replace('/', '\\/').replace('[', '\\[').replace(']', '\\]').replace('.', '\\.')
    if f'.{escaped}' not in css and f'.{c}' not in css:
        missing.append(c)

print(f"Total unique classes used: {len(all_classes)}")
print(f"Missing from inlined CSS: {len(missing)}")
print("First 40 missing classes:", missing[:40])
