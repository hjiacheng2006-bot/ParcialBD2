with open('frontend/index.html', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Update memory variables
old_vars = """    // Estados en memoria
    let productosData = [];
    let tercerosData = [];
    let ventasData = [];
    let carrito = [];"""

new_vars = """    // Estados en memoria
    let productosData = [];
    let tercerosData = [];
    let ventasData = [];
    let carteraData = [];
    let usuariosData = [];
    let usuarioActivo = { id_usuario: 1, nombre: "Juan Admin", roles_id_rol: 1 };
    let carrito = [];"""

code = code.replace(old_vars, new_vars)

# 2. Update cambiarPestana to handle cartera
old_tabs = """      if (tabName === 'dashboard') actualizarDashboard();
      if (tabName === 'reportes') cargarReportes();"""

new_tabs = """      if (tabName === 'dashboard') actualizarDashboard();
      if (tabName === 'reportes') cargarReportes();
      if (tabName === 'cartera') cargarCartera();"""

code = code.replace(old_tabs, new_tabs)

# 3. Update cargarTodo to load cartera and auth users
old_cargar_todo = """        await Promise.all([cargarProductos(), cargarTerceros(), cargarVentas()]);"""
new_cargar_todo = """        await Promise.all([cargarProductos(), cargarTerceros(), cargarVentas(), cargarCartera(), cargarUsuariosAuth()]);"""

code = code.replace(old_cargar_todo, new_cargar_todo)

# 4. Update filtrarProductos with multi-criteria dynamic SQL parameters
old_filter_fn = """    function filtrarProductos() {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(async () => {
        const q = document.getElementById('filtroProductos').value.trim();
        try {
          const url = q ? `${API_BASE}/api/productos/?nombre=${encodeURIComponent(q)}` : `${API_BASE}/api/productos/`;
          const res = await fetch(url);
          if (res.ok) {
            const data = await res.json();
            renderizarProductos(data);
          }
        } catch (err) {
          console.error("Error en búsqueda dinámica:", err);
        }
      }, 250);
    }"""

new_filter_fn = """    function filtrarProductos() {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(async () => {
        const q = document.getElementById('filtroProductos')?.value.trim() || '';
        const minP = document.getElementById('filtroPrecioMin')?.value.trim() || '';
        const maxP = document.getElementById('filtroPrecioMax')?.value.trim() || '';
        const minS = document.getElementById('filtroStockMin')?.value.trim() || '';

        const params = new URLSearchParams();
        if (q) params.append('nombre', q);
        if (minP) params.append('precio_min', minP);
        if (maxP) params.append('precio_max', maxP);
        if (minS) params.append('stock_min', minS);

        const queryString = params.toString();
        const url = queryString ? `${API_BASE}/api/productos/?${queryString}` : `${API_BASE}/api/productos/`;

        try {
          const res = await fetch(url);
          if (res.ok) {
            const data = await res.json();
            renderizarProductos(data);
          }
        } catch (err) {
          console.error("Error en búsqueda dinámica:", err);
        }
      }, 200);
    }

    function limpiarFiltrosProductos() {
      const elQ = document.getElementById('filtroProductos');
      const elMinP = document.getElementById('filtroPrecioMin');
      const elMaxP = document.getElementById('filtroPrecioMax');
      const elMinS = document.getElementById('filtroStockMin');
      if (elQ) elQ.value = '';
      if (elMinP) elMinP.value = '';
      if (elMaxP) elMaxP.value = '';
      if (elMinS) elMinS.value = '';
      cargarProductos();
    }"""

code = code.replace(old_filter_fn, new_filter_fn)

# 5. In facturarVenta: use ventaUsuarioSelect
old_facturar_inputs = """      const idTercero = document.getElementById('ventaTerceroSelect').value;
      const idUsuario = document.getElementById('ventaUsuarioInput').value;"""

new_facturar_inputs = """      const idTercero = document.getElementById('ventaTerceroSelect').value;
      const userSelect = document.getElementById('ventaUsuarioSelect');
      const idUsuario = userSelect ? userSelect.value : (usuarioActivo ? usuarioActivo.id_usuario : 1);"""

code = code.replace(old_facturar_inputs, new_facturar_inputs)

# 6. In actualizarDashboard: update Cartera stat card
old_dash_stats = """      document.getElementById('statTotalVentas').innerText = formatMoney(totalFacturado);
      document.getElementById('statCantVentas').innerText = `${ventasActivas.length} ventas activas`;
      document.getElementById('statTotalProductos').innerText = productosData.length;
      document.getElementById('statStockBajo').innerText = `${productosStockBajo} con stock bajo`;
      document.getElementById('statTotalTerceros').innerText = tercerosData.length;
      document.getElementById('statVentasAnuladas').innerText = totalAnuladas;"""

new_dash_stats = """      document.getElementById('statTotalVentas').innerText = formatMoney(totalFacturado);
      document.getElementById('statCantVentas').innerText = `${ventasActivas.length} ventas activas`;
      document.getElementById('statTotalProductos').innerText = productosData.length;
      document.getElementById('statStockBajo').innerText = `${productosStockBajo} con stock bajo`;
      document.getElementById('statTotalTerceros').innerText = tercerosData.length;
      document.getElementById('statVentasAnuladas').innerText = totalAnuladas;

      const totalCartera = carteraData.reduce((acc, c) => acc + parseFloat(c.total_venta || 0), 0);
      const elCartera = document.getElementById('statCarteraDash');
      if (elCartera) elCartera.innerText = formatMoney(totalCartera);
      const elCantCartera = document.getElementById('statCantCarteraDash');
      if (elCantCartera) elCantCartera.innerText = `${carteraData.length} por cobrar`;"""

code = code.replace(old_dash_stats, new_dash_stats)

# 7. Add Functions for Cartera & Auth at the end of the script (before DOMContentLoaded)
new_modules_js = """
    // 7. MÓDULO CARTERA Y COBROS (PUNTO ADICIONAL FASE 2)
    async function cargarCartera() {
      const tbody = document.getElementById('carteraTbody');
      try {
        const res = await fetch(`${API_BASE}/api/cartera/`);
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err.error_db || err.error || `HTTP ${res.status}`);
        }
        const data = await res.json();
        carteraData = data.cuentas_por_cobrar || [];

        // Actualizar estadísticas de Cartera
        const elTotal = document.getElementById('statTotalCartera');
        if (elTotal) elTotal.innerText = formatMoney(data.total_cartera_activa || 0);
        const elCant = document.getElementById('statCantCartera');
        if (elCant) elCant.innerText = data.cantidad_transacciones || 0;

        renderizarCartera(carteraData);
      } catch (err) {
        console.error("Error al cargar cartera:", err);
        if (tbody) {
          tbody.innerHTML = `<tr><td colspan="7" class="text-center py-6 text-rose-500 text-xs">Error al cargar cartera: ${err.message}</td></tr>`;
        }
      }
    }

    function renderizarCartera(lista) {
      const tbody = document.getElementById('carteraTbody');
      if (!tbody) return;

      if (!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-8 text-emerald-600 font-semibold"><i class="fa-solid fa-circle-check mr-1.5 text-base"></i>No hay cuentas por cobrar pendientes. ¡Toda la cartera está al día!</td></tr>';
        return;
      }

      tbody.innerHTML = lista.map(c => `
        <tr class="hover:bg-slate-50 transition">
          <td class="py-3 px-4 font-mono font-bold text-xs text-indigo-600">#${c.id_venta}</td>
          <td class="py-3 px-4 text-slate-600 text-xs">${c.fecha_venta ? new Date(c.fecha_venta).toLocaleDateString() : '-'}</td>
          <td class="py-3 px-4 font-semibold text-slate-900">${c.nombre_cliente}</td>
          <td class="py-3 px-4 text-xs text-slate-500">
            <div><i class="fa-solid fa-phone text-slate-400 mr-1 text-[10px]"></i>${c.contacto_cliente || 'N/A'}</div>
            <div class="text-[11px] text-slate-400">${c.correo_cliente || ''}</div>
          </td>
          <td class="py-3 px-4 text-center">
            <span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${c.estado_venta === 'Por Pagar' ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-yellow-100 text-yellow-800 border border-yellow-300'}">
              ${c.estado_venta}
            </span>
          </td>
          <td class="py-3 px-4 text-right font-extrabold text-amber-700 text-sm">
            ${formatMoney(c.total_venta)}
          </td>
          <td class="py-3 px-4 text-center">
            <button onclick="abrirModalAbono(${c.id_venta}, ${c.total_venta}, '${c.nombre_cliente.replace(/'/g, "\\'")}', '${c.estado_venta}')" 
                    class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-sm transition flex items-center gap-1.5 mx-auto">
              <i class="fa-solid fa-hand-holding-dollar"></i> Abonar / Pagar
            </button>
          </td>
        </tr>
      `).join('');
    }

    let abonoActual = null;

    function abrirModalAbono(idVenta, total, cliente, estado) {
      abonoActual = { idVenta, total, cliente, estado };
      document.getElementById('abonoIdVenta').value = idVenta;
      document.getElementById('modalAbonoSubtitulo').innerText = `Factura #${idVenta}`;
      document.getElementById('abonoClienteNombre').innerText = cliente;
      document.getElementById('abonoTotalVenta').innerText = formatMoney(total);
      document.getElementById('abonoEstadoActual').innerText = estado;
      document.getElementById('abonoMontoInput').value = total;
      document.getElementById('modalAbonoCartera').classList.remove('hidden');
    }

    function cerrarModalAbono() {
      document.getElementById('modalAbonoCartera').classList.add('hidden');
      abonoActual = null;
    }

    function abonarSaldoTotal() {
      if (abonoActual) {
        document.getElementById('abonoMontoInput').value = abonoActual.total;
      }
    }

    async function procesarAbonoCartera(e) {
      e.preventDefault();
      if (!abonoActual) return;

      const monto = parseFloat(document.getElementById('abonoMontoInput').value);
      if (!monto || monto <= 0) {
        showToast("Ingrese un monto válido para el abono.", "warning");
        return;
      }

      const btn = document.getElementById('btnGuardarAbono');
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Procesando...';

      try {
        const res = await fetch(`${API_BASE}/api/cartera/${abonoActual.idVenta}/abono`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ monto: monto })
        });

        const data = await res.json();
        if (!res.ok) {
          const errMsg = data.error || data.error_db || "Error al procesar el abono.";
          showToast(errMsg, "error");
          return;
        }

        showToast(data.mensaje || `Abono de ${formatMoney(monto)} aplicado exitosamente.`, "success");
        cerrarModalAbono();
        await Promise.all([cargarCartera(), cargarVentas()]);
        actualizarDashboard();
      } catch (err) {
        showToast("Error de conexión al registrar abono en cartera.", "error");
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Aplicar Abono';
      }
    }

    // 8. MÓDULO AUTENTICACIÓN Y GESTIÓN DE USUARIOS (PUNTO ADICIONAL FASE 2)
    async function cargarUsuariosAuth() {
      try {
        const res = await fetch(`${API_BASE}/api/auth/usuarios`);
        if (!res.ok) return;
        usuariosData = await res.json();

        // Poblar selector en Facturación
        const select = document.getElementById('ventaUsuarioSelect');
        if (select && usuariosData.length > 0) {
          select.innerHTML = usuariosData.map(u => `
            <option value="${u.id_usuario}">${u.nombre} (${u.correo})</option>
          `).join('');
        }

        // Si hay usuarios, fijar el primero activo si no hay
        if (usuariosData.length > 0 && !usuarioActivo) {
          seleccionarUsuarioAuth(usuariosData[0].id_usuario);
        } else if (usuarioActivo) {
          actualizarPillUsuarioNav();
        }
      } catch (e) {
        console.warn("No se pudieron cargar usuarios de auth:", e);
      }
    }

    function abrirModalAuth() {
      const container = document.getElementById('authUsuariosList');
      if (container && usuariosData.length > 0) {
        container.innerHTML = usuariosData.map(u => `
          <div onclick="seleccionarUsuarioAuth(${u.id_usuario})" class="p-3 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/50 cursor-pointer transition flex items-center justify-between ${usuarioActivo && usuarioActivo.id_usuario === u.id_usuario ? 'bg-indigo-50 border-indigo-500' : 'bg-white'}">
            <div class="flex items-center gap-2.5">
              <div class="h-8 w-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs">
                ${u.nombre.charAt(0)}
              </div>
              <div>
                <span class="font-bold text-slate-800 text-xs block">${u.nombre}</span>
                <span class="text-[11px] text-slate-400 block">${u.correo}</span>
              </div>
            </div>
            <span class="text-xs font-semibold px-2 py-0.5 rounded ${usuarioActivo && usuarioActivo.id_usuario === u.id_usuario ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}">
              ${usuarioActivo && usuarioActivo.id_usuario === u.id_usuario ? 'Activo' : 'Elegir'}
            </span>
          </div>
        `).join('');
      }
      const curName = document.getElementById('modalAuthCurrentName');
      if (curName && usuarioActivo) curName.innerText = `${usuarioActivo.nombre} (ID: ${usuarioActivo.id_usuario})`;
      document.getElementById('modalAuth').classList.remove('hidden');
    }

    function cerrarModalAuth() {
      document.getElementById('modalAuth').classList.add('hidden');
    }

    function seleccionarUsuarioAuth(idUsuario) {
      const u = usuariosData.find(item => item.id_usuario === idUsuario);
      if (u) {
        usuarioActivo = u;
        actualizarPillUsuarioNav();
        const select = document.getElementById('ventaUsuarioSelect');
        if (select) select.value = u.id_usuario;
        showToast(`Sesión activa: ${u.nombre}`, "info");
      }
      cerrarModalAuth();
    }

    function actualizarPillUsuarioNav() {
      if (!usuarioActivo) return;
      const elNombre = document.getElementById('navUsuarioNombre');
      const elRol = document.getElementById('navUsuarioRol');
      if (elNombre) elNombre.innerText = usuarioActivo.nombre;
      if (elRol) elRol.innerText = `ID #${usuarioActivo.id_usuario} • Rol ${usuarioActivo.roles_id_rol || 1}`;
    }
"""

target_dom = "    // Inicializar al cargar el DOM"
code = code.replace(target_dom, new_modules_js + "\n    // Inicializar al cargar el DOM")

with open('frontend/index.html', 'w', encoding='utf-8') as f:
    f.write(code)

print("JS features added successfully to frontend/index.html")
