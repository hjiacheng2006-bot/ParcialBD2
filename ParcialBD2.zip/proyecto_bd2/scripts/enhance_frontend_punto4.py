import re
import os

def enhance_frontend():
    file_path = "frontend/index.html"
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    # 1. ACTUALIZAR renderizarProductos: Incluir columna de FOTO y botón de subir foto
    old_render_prod = """    function renderizarProductos(lista) {
      const tbody = document.getElementById('productosTbody');
      if (!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-slate-400">No hay productos activos disponibles.</td></tr>';
        return;
      }

      tbody.innerHTML = lista.map(p => {
        const esBajo = p.cantidad_stock <= p.nivel_minimo;
        const stockBadge = esBajo 
          ? `<span class="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300"><i class="fa-solid fa-triangle-exclamation mr-1"></i>${p.cantidad_stock}</span>`
          : `<span class="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">${p.cantidad_stock}</span>`;

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="py-3 px-4 font-mono text-xs text-slate-500 font-bold">#${p.id_producto}</td>
            <td class="py-3 px-4 font-semibold text-slate-900">${p.nombre}</td>
            <td class="py-3 px-4 text-center">${stockBadge}</td>
            <td class="py-3 px-4 text-center text-slate-500">${p.nivel_minimo}</td>
            <td class="py-3 px-4 text-right font-medium text-slate-600">${formatMoney(p.precioCompra)}</td>
            <td class="py-3 px-4 text-right font-bold text-slate-900">${formatMoney(p.precioVenta)}</td>
            <td class="py-3 px-4 text-center text-slate-500">${((p.tarifa_iva || 0.19) * 100).toFixed(0)}%</td>
            <td class="py-3 px-4 text-center">
              <div class="flex items-center justify-center gap-1.5">
                <button onclick="editarProducto(${p.id_producto})" title="Editar Producto" class="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-md">
                  <i class="fa-solid fa-pen-to-square"></i>
                </button>
                <button onclick="inactivarProducto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}')" title="Inactivar Producto (Trigger)" class="p-1.5 text-rose-600 hover:bg-rose-50 rounded-md">
                  <i class="fa-solid fa-trash-can"></i>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }"""

    new_render_prod = """    function renderizarProductos(lista) {
      const tbody = document.getElementById('productosTbody');
      if (!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="text-center py-6 text-slate-400">No hay productos activos disponibles.</td></tr>';
        return;
      }

      tbody.innerHTML = lista.map(p => {
        const esBajo = p.cantidad_stock <= p.nivel_minimo;
        const stockBadge = esBajo 
          ? `<span class="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300"><i class="fa-solid fa-triangle-exclamation mr-1"></i>${p.cantidad_stock}</span>`
          : `<span class="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">${p.cantidad_stock}</span>`;

        const fotoHtml = p.imagen
          ? `<img src="${API_BASE}${p.imagen}" alt="${p.nombre}" class="w-10 h-10 object-cover rounded-lg mx-auto shadow-sm border border-slate-200 cursor-pointer hover:scale-110 transition" onclick="abrirModalFoto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}', '${p.imagen}')" title="Clic para ver o cambiar fotografía">`
          : `<button onclick="abrirModalFoto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}', '')" class="w-9 h-9 rounded-lg bg-slate-100 hover:bg-indigo-50 border border-dashed border-slate-300 hover:border-indigo-400 flex items-center justify-center mx-auto text-slate-400 hover:text-indigo-600 transition" title="Subir fotografía (Punto 4.4)">
               <i class="fa-solid fa-camera text-xs"></i>
             </button>`;

        return `
          <tr class="hover:bg-slate-50 transition">
            <td class="py-3 px-4 font-mono text-xs text-slate-500 font-bold">#${p.id_producto}</td>
            <td class="py-2.5 px-4 text-center">${fotoHtml}</td>
            <td class="py-3 px-4 font-semibold text-slate-900">${p.nombre}</td>
            <td class="py-3 px-4 text-center">${stockBadge}</td>
            <td class="py-3 px-4 text-center text-slate-500">${p.nivel_minimo}</td>
            <td class="py-3 px-4 text-right font-medium text-slate-600">${formatMoney(p.precioCompra)}</td>
            <td class="py-3 px-4 text-right font-bold text-slate-900">${formatMoney(p.precioVenta)}</td>
            <td class="py-3 px-4 text-center text-slate-500">${((p.tarifa_iva || 0.19) * 100).toFixed(0)}%</td>
            <td class="py-3 px-4 text-center">
              <div class="flex items-center justify-center gap-1.5">
                <button onclick="abrirModalFoto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}', '${p.imagen || ''}')" title="Subir / Ver Fotografía (Punto 4.4)" class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-md">
                  <i class="fa-solid fa-camera"></i>
                </button>
                <button onclick="editarProducto(${p.id_producto})" title="Editar Producto" class="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-md">
                  <i class="fa-solid fa-pen-to-square"></i>
                </button>
                <button onclick="inactivarProducto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}')" title="Inactivar Producto (Trigger)" class="p-1.5 text-rose-600 hover:bg-rose-50 rounded-md">
                  <i class="fa-solid fa-trash-can"></i>
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }"""

    if old_render_prod in content:
        content = content.replace(old_render_prod, new_render_prod)
        print("Updated renderizarProductos!")
    else:
        print("Warning: old_render_prod not found directly, checking regex...")

    # 2. ACTUALIZAR renderizarCartera: Saldo deudor real y botón de ver recibos
    old_render_cart = """    function renderizarCartera(lista) {
      const tbody = document.getElementById('carteraTbody');
      if (!tbody) return;

      if (!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-8 text-emerald-600 font-semibold"><i class="fa-solid fa-circle-check mr-1.5 text-base"></i>No hay cuentas por cobrar pendientes. ¡Toda la cartera está al día!</td></tr>';
        return;
      }

      tbody.innerHTML = lista.map(c => `
        <tr class="hover:bg-slate-50 transition">
          <td class="py-3 px-4 font-mono font-bold text-xs text-indigo-600">#${c.id_venta}</td>
          <td class="py-3 px-4 text-slate-600 text-xs">${c.fecha_venta ? new Date(c.fecha_venta).toLocaleDateString() : '-'}</td>
          <td class="py-3 px-4 font-semibold text-slate-900">${c.nombre_cliente}</td>
          <td class="py-3 px-4 text-xs text-slate-500">
            <div><i class="fa-solid fa-phone text-slate-400 mr-1 text-[10px]"></i>${c.contacto_cliente || 'N/A'}</div>
            <div class="text-[11px] text-slate-400">${c.correo_cliente || ''}</div>
          </td>
          <td class="py-3 px-4 text-center">
            <span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${c.estado_venta === 'Por Pagar' ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-yellow-100 text-yellow-800 border border-yellow-300'}">
              ${c.estado_venta}
            </span>
          </td>
          <td class="py-3 px-4 text-right font-extrabold text-amber-700 text-sm">
            ${formatMoney(c.total_venta)}
          </td>
          <td class="py-3 px-4 text-center">
            <button onclick="abrirModalAbono(${c.id_venta}, ${c.total_venta}, '${c.nombre_cliente.replace(/'/g, "\\\\'")}', '${c.estado_venta}')" 
                    class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-sm transition flex items-center gap-1.5 mx-auto">
              <i class="fa-solid fa-hand-holding-dollar"></i> Abonar / Pagar
            </button>
          </td>
        </tr>
      `).join('');
    }"""

    new_render_cart = """    function renderizarCartera(lista) {
      const tbody = document.getElementById('carteraTbody');
      if (!tbody) return;

      if (!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-8 text-emerald-600 font-semibold"><i class="fa-solid fa-circle-check mr-1.5 text-base"></i>No hay cuentas por cobrar pendientes. ¡Toda la cartera está al día!</td></tr>';
        return;
      }

      tbody.innerHTML = lista.map(c => {
        const saldo = (c.saldo_pendiente !== undefined && c.saldo_pendiente !== null) ? Number(c.saldo_pendiente) : Number(c.total_venta);
        const abonado = (c.total_abonado !== undefined && c.total_abonado !== null) ? Number(c.total_abonado) : 0;
        const total = Number(c.total_venta || 0);

        return `
        <tr class="hover:bg-slate-50 transition">
          <td class="py-3 px-4 font-mono font-bold text-xs text-indigo-600">#${c.id_venta}</td>
          <td class="py-3 px-4 text-slate-600 text-xs">${c.fecha_venta ? new Date(c.fecha_venta).toLocaleDateString() : '-'}</td>
          <td class="py-3 px-4 font-semibold text-slate-900">${c.nombre_cliente}</td>
          <td class="py-3 px-4 text-xs text-slate-500">
            <div><i class="fa-solid fa-phone text-slate-400 mr-1 text-[10px]"></i>${c.contacto_cliente || 'N/A'}</div>
            <div class="text-[11px] text-slate-400">${c.correo_cliente || ''}</div>
          </td>
          <td class="py-3 px-4 text-center">
            <span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${c.estado_venta === 'Por Pagar' ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-yellow-100 text-yellow-800 border border-yellow-300'}">
              ${c.estado_venta}
            </span>
          </td>
          <td class="py-3 px-4 text-right">
            <div class="font-extrabold text-amber-700 text-sm">${formatMoney(saldo)}</div>
            <div class="text-[10px] text-slate-400">Total: ${formatMoney(total)} | Abonos: ${formatMoney(abonado)}</div>
          </td>
          <td class="py-3 px-4 text-center">
            <div class="flex items-center justify-center gap-1.5">
              <button onclick="abrirModalAbono(${c.id_venta}, ${saldo}, '${c.nombre_cliente.replace(/'/g, "\\\\'")}', '${c.estado_venta}', ${total})" 
                      class="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold shadow-sm transition flex items-center gap-1">
                <i class="fa-solid fa-hand-holding-dollar"></i> Abonar
              </button>
              <button onclick="verRecibosCartera(${c.id_venta}, '${c.nombre_cliente.replace(/'/g, "\\\\'")}', ${total})" 
                      class="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold border border-indigo-200 transition flex items-center gap-1" title="Ver comprobantes y recibos de caja (Punto 4.2)">
                <i class="fa-solid fa-receipt"></i> Recibos
              </button>
            </div>
          </td>
        </tr>
      `}).join('');
    }"""

    if old_render_cart in content:
        content = content.replace(old_render_cart, new_render_cart)
        print("Updated renderizarCartera!")
    else:
        print("Warning: old_render_cart not found directly.")

    # 3. ACTUALIZAR abrirModalAbono para recibir el saldo sugerido
    old_modal_abono = """    function abrirModalAbono(idVenta, total, cliente, estado) {
      abonoActual = { idVenta, total, cliente, estado };
      document.getElementById('abonoIdVenta').value = idVenta;
      document.getElementById('modalAbonoSubtitulo').innerText = `Factura #${idVenta}`;
      document.getElementById('abonoClienteNombre').innerText = cliente;
      document.getElementById('abonoTotalVenta').innerText = formatMoney(total);
      document.getElementById('abonoEstadoActual').innerText = estado;
      document.getElementById('abonoMontoInput').value = total;
      document.getElementById('modalAbonoCartera').classList.remove('hidden');
    }"""

    new_modal_abono = """    function abrirModalAbono(idVenta, saldo, cliente, estado, totalFactura = null) {
      const valorTotal = totalFactura !== null ? totalFactura : saldo;
      abonoActual = { idVenta, total: saldo, totalFactura: valorTotal, cliente, estado };
      document.getElementById('abonoIdVenta').value = idVenta;
      document.getElementById('modalAbonoSubtitulo').innerText = `Factura #${idVenta}`;
      document.getElementById('abonoClienteNombre').innerText = cliente;
      document.getElementById('abonoTotalVenta').innerText = formatMoney(saldo);
      document.getElementById('abonoEstadoActual').innerText = estado;
      document.getElementById('abonoMontoInput').value = saldo;
      document.getElementById('modalAbonoCartera').classList.remove('hidden');
    }"""

    if old_modal_abono in content:
        content = content.replace(old_modal_abono, new_modal_abono)
        print("Updated abrirModalAbono!")

    # 4. AGREGAR FUNCIONES verRecibosCartera y cerrarModalRecibosCartera
    recibos_functions = """
    // PUNTO 4.2: CONSULTAR RECIBOS DE CAJA DE UNA VENTA
    async function verRecibosCartera(idVenta, cliente, totalVenta) {
      const modal = document.getElementById('modalRecibosCartera');
      const subtitulo = document.getElementById('modalRecibosSubtitulo');
      const tbody = document.getElementById('recibosCarteraTbody');
      
      subtitulo.innerText = `Factura #${idVenta} - Cliente: ${cliente} (Total Facturado: ${formatMoney(totalVenta)})`;
      tbody.innerHTML = '<tr><td colspan="4" class="text-center py-6 text-slate-400">Consultando recibos de caja...</td></tr>';
      modal.classList.remove('hidden');

      try {
        const res = await fetch(`${API_BASE}/api/cartera/${idVenta}/recibos`);
        if (!res.ok) throw new Error("No se pudo obtener el historial de recibos");
        const recibos = await res.json();

        if (!recibos || recibos.length === 0) {
          tbody.innerHTML = '<tr><td colspan="4" class="text-center py-6 text-slate-400">No se han registrado recibos de abono para esta venta aún.</td></tr>';
          return;
        }

        let totalAbonado = 0;
        tbody.innerHTML = recibos.map(r => {
          totalAbonado += Number(r.monto || 0);
          return `
            <tr class="hover:bg-slate-50 transition">
              <td class="py-2.5 px-3 font-mono text-xs font-bold text-indigo-700">RC-${r.id_recibo}</td>
              <td class="py-2.5 px-3 text-xs text-slate-600">${r.fecha_recibo ? new Date(r.fecha_recibo).toLocaleString() : '-'}</td>
              <td class="py-2.5 px-3 text-xs text-slate-500">${r.observacion || 'Abono parcial'}</td>
              <td class="py-2.5 px-3 text-right font-bold text-emerald-700 text-xs">${formatMoney(r.monto)}</td>
            </tr>
          `;
        }).join('') + `
          <tr class="bg-emerald-50/70 font-bold border-t-2 border-emerald-300">
            <td colspan="3" class="py-2.5 px-3 text-right text-xs text-emerald-950 font-bold">Sumatoria Total de Abonos:</td>
            <td class="py-2.5 px-3 text-right text-emerald-900 text-xs font-extrabold">${formatMoney(totalAbonado)}</td>
          </tr>
        `;
      } catch (err) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center py-4 text-rose-500 text-xs">${err.message}</td></tr>`;
      }
    }

    function cerrarModalRecibosCartera() {
      document.getElementById('modalRecibosCartera').classList.add('hidden');
    }
"""
    if "verRecibosCartera" not in content:
        content = content.replace("function cerrarModalAbono() {", recibos_functions + "\n    function cerrarModalAbono() {")
        print("Added verRecibosCartera functions!")

    # 5. AGREGAR EL MODAL modalRecibosCartera en el HTML
    modal_recibos_html = """
  <!-- MODAL HISTORIAL DE RECIBOS DE CAJA (PUNTO 4.2) -->
  <div id="modalRecibosCartera" class="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
      <div class="flex justify-between items-center border-b pb-3">
        <div class="flex items-center gap-2">
          <div class="h-8 w-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
            <i class="fa-solid fa-file-invoice-dollar"></i>
          </div>
          <div>
            <h3 class="text-lg font-bold text-slate-900">Historial de Recibos de Caja</h3>
            <p id="modalRecibosSubtitulo" class="text-xs text-slate-500">Módulo de Transacciones Financieras y Abonos</p>
          </div>
        </div>
        <button onclick="cerrarModalRecibosCartera()" class="text-slate-400 hover:text-slate-600"><i class="fa-solid fa-xmark text-lg"></i></button>
      </div>

      <div class="overflow-y-auto flex-1 border rounded-xl overflow-hidden">
        <table class="w-full text-left text-xs">
          <thead class="bg-slate-100 text-slate-600 uppercase font-semibold border-b">
            <tr>
              <th class="py-2.5 px-3">Recibo</th>
              <th class="py-2.5 px-3">Fecha y Hora</th>
              <th class="py-2.5 px-3">Observación</th>
              <th class="py-2.5 px-3 text-right">Monto</th>
            </tr>
          </thead>
          <tbody id="recibosCarteraTbody" class="divide-y divide-slate-100">
            <tr><td colspan="4" class="text-center py-6 text-slate-400">Cargando...</td></tr>
          </tbody>
        </table>
      </div>

      <div class="border-t pt-3 flex justify-between items-center text-xs">
        <span class="text-slate-500"><i class="fa-solid fa-bolt text-amber-500 mr-1"></i>Sincronizado vía Trigger recibos_caja_AFTER_INSERT</span>
        <button onclick="cerrarModalRecibosCartera()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg">Cerrar</button>
      </div>
    </div>
  </div>
"""
    if "modalRecibosCartera" not in content:
        content = content.replace('<div id="modalSubirFoto"', modal_recibos_html + '\n  <div id="modalSubirFoto"')
        print("Added modalRecibosCartera HTML!")

    # Guardar en frontend/index.html y sincronizar con backend/static/index.html
    with open("frontend/index.html", "w", encoding="utf-8") as f:
        f.write(content)
    with open("backend/static/index.html", "w", encoding="utf-8") as f:
        f.write(content)

    print("Both frontend/index.html and backend/static/index.html updated successfully!")

if __name__ == '__main__':
    enhance_frontend()
