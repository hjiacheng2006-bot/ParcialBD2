import os

with open('backend/static/tailwind.min.css', 'r', encoding='utf-8') as f:
    css_content = f.read()

for target in ['backend/static/index.html', 'frontend/index.html']:
    with open(target, 'r', encoding='utf-8') as f:
        html = f.read()

    target_str = '<script src="https://cdn.tailwindcss.com"></script>'
    replacement = f'<style id="inlined-tailwind">\n{css_content}\n</style>\n  <script src="https://cdn.tailwindcss.com"></script>'
    
    if target_str in html:
        html = html.replace(target_str, replacement, 1)
        with open(target, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"Successfully embedded Tailwind CSS into {target}")
    else:
        print(f"Target string not found in {target}")
