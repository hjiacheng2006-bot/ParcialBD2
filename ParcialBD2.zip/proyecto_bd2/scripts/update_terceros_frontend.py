with open('frontend/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Ubicar function renderizarTerceros
start_marker = "    function renderizarTerceros(lista) {"
end_marker = "    function filtrarTerceros() {"
idx_start = text.find(start_marker)
idx_end = text.find(end_marker)
assert idx_start != -1 and idx_end != -1

replacement_render = """    function renderizarTerceros(lista) {
      const tbody = document.getElementById('tercerosTbody');
      if (!lista || lista.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-6 text-slate-400">No hay terceros registrados.</td></tr>';
        return;
      }

      tbody.innerHTML = lista.map(t => {
        const esActivo = (t.estado === 1 || t.estado === '1');
        const nombreEsc = (t.nombre || '').replace(/'/g, "\\\\'");

        const badgeEstado = esActivo
          ? `<span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-sm"><i class="fa-solid fa-circle-check text-[10px]"></i> Activo</span>`
          : `<span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-600 border border-slate-300 shadow-sm"><i class="fa-solid fa-circle-xmark text-[10px] text-slate-400"></i> Inactivo</span>`;

        const btnAccion = esActivo
          ? `<button onclick="inactivarTercero(${t.id_tercero}, '${nombreEsc}')" title="Inactivar Tercero (Soft Delete)" class="px-3 py-1 text-xs font-semibold text-rose-600 hover:text-white hover:bg-rose-600 border border-rose-300 rounded-lg transition inline-flex items-center gap-1.5 shadow-sm">
               <i class="fa-solid fa-user-xmark"></i> Inactivar
             </button>`
          : `<button onclick="reactivarTercero(${t.id_tercero}, '${nombreEsc}')" title="Volver a Activar Tercero" class="px-3 py-1 text-xs font-semibold text-emerald-700 hover:text-white hover:bg-emerald-600 border border-emerald-400 rounded-lg transition inline-flex items-center gap-1.5 shadow-sm">
               <i class="fa-solid fa-rotate-left"></i> Volver a Activar
             </button>`;

        const rowBg = esActivo ? 'hover:bg-slate-50 transition' : 'bg-slate-50/70 hover:bg-slate-100/70 transition opacity-80';

        return `
          <tr class="${rowBg}">
            <td class="py-3 px-4 font-mono text-xs font-bold text-slate-500">#${t.id_tercero}</td>
            <td class="py-3 px-4 font-semibold ${esActivo ? 'text-slate-900' : 'text-slate-500'}">
              ${t.nombre}
              ${!esActivo ? '<span class="ml-2 text-[10px] font-normal text-slate-400 italic bg-slate-200 px-1.5 py-0.5 rounded">(Inactivo)</span>' : ''}
            </td>
            <td class="py-3 px-4 text-slate-600">${t.correo || '-'}</td>
            <td class="py-3 px-4 text-slate-600 font-mono text-xs">${t.contacto}</td>
            <td class="py-3 px-4 text-center">${badgeEstado}</td>
            <td class="py-3 px-4 text-center">${btnAccion}</td>
          </tr>
        `;
      }).join('');
    }

"""

text = text[:idx_start] + replacement_render + text[idx_end:]

# Ubicar inactivarTercero para insertar reactivarTercero
idx_inact = text.find("async function inactivarTercero(id, nombre) {")
assert idx_inact != -1
idx_inact_end = text.find("    // 3. VENTAS Y ANULACIÓN", idx_inact)
assert idx_inact_end != -1

inactivar_and_reactivar = """    async function inactivarTercero(id, nombre) {
      if (!confirm(`¿Está seguro de inactivar al tercero "${nombre}"?\\n(Si tiene ventas asociadas, el sistema impedirá el borrado mediante trigger).`)) return;

      try {
        const res = await fetch(`${API_BASE}/api/terceros/${id}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            ...(tokenSesion ? { 'Authorization': `Bearer ${tokenSesion}` } : {})
          }
        });
        const data = await res.json();

        if (!res.ok) {
          const errMsg = data.error || data.error_db || "No se pudo inactivar el tercero.";
          showToast(errMsg, "error");
          return;
        }

        showToast("Tercero inactivado exitosamente.", "success");
        await cargarTerceros();
        actualizarDashboard();
      } catch (err) {
        showToast("Error de conexión al inactivar tercero.", "error");
      }
    }

    async function reactivarTercero(id, nombre) {
      if (!confirm(`¿Está seguro de volver a activar al tercero "${nombre}"?\\n(Volverá a estar habilitado para facturación y pedidos sin bloqueo de triggers).`)) return;

      try {
        const res = await fetch(`${API_BASE}/api/terceros/${id}/activar`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(tokenSesion ? { 'Authorization': `Bearer ${tokenSesion}` } : {})
          }
        });
        const data = await res.json();

        if (!res.ok) {
          const errMsg = data.error || data.error_db || "No se pudo reactivar el tercero.";
          showToast(errMsg, "error");
          return;
        }

        showToast(`Tercero "${nombre}" reactivado exitosamente.`, "success");
        await cargarTerceros();
        actualizarDashboard();
      } catch (err) {
        showToast("Error de conexión al reactivar tercero.", "error");
      }
    }

"""

text = text[:idx_inact] + inactivar_and_reactivar + text[idx_inact_end:]

# Actualizar poblarSelectTerceros para usar clientes activos
idx_poblar = text.find("function poblarSelectTerceros() {")
assert idx_poblar != -1
idx_poblar_end = text.find("function poblarSelectProductos() {", idx_poblar)
assert idx_poblar_end != -1

replacement_poblar = """function poblarSelectTerceros() {
      const select = document.getElementById('ventaTerceroSelect');
      if (!select) return;
      const activos = (tercerosData || []).filter(t => t.estado === 1 || t.estado === '1');
      select.innerHTML = '<option value="">Seleccione un cliente activo...</option>' + 
        activos.map(t => `<option value="${t.id_tercero}">${t.nombre} (${t.contacto})</option>`).join('');
    }

    """

text = text[:idx_poblar] + replacement_poblar + text[idx_poblar_end:]

with open('frontend/index.html', 'w', encoding='utf-8') as f:
    f.write(text)
with open('backend/static/index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print('Updated frontend/index.html and backend/static/index.html successfully!')
