import os

def update_auth_in_frontend():
    file_path = "frontend/index.html"
    with open(file_path, "r", encoding="utf-8") as f:
        html = f.read()

    # 1. AGREGAR BOTÓN DE AUTENTICACIÓN EN EL NAVBAR
    old_nav_items = """          <button onclick="cambiarPestana('reportes')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition text-slate-300 hover:text-white hover:bg-slate-800" data-tab="reportes">
            <i class="fa-solid fa-chart-line mr-1.5"></i> Reportes
          </button>
          <button onclick="cambiarPestana('nueva-venta')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm" data-tab="nueva-venta">
            <i class="fa-solid fa-cart-plus mr-1.5"></i> Facturar
          </button>"""

    new_nav_items = """          <button onclick="cambiarPestana('reportes')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition text-slate-300 hover:text-white hover:bg-slate-800" data-tab="reportes">
            <i class="fa-solid fa-chart-line mr-1.5"></i> Reportes
          </button>
          <button onclick="cambiarPestana('auth')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition text-slate-300 hover:text-white hover:bg-slate-800" data-tab="auth">
            <i class="fa-solid fa-shield-halved mr-1.5 text-indigo-400"></i> Autenticación
          </button>
          <button onclick="cambiarPestana('nueva-venta')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm" data-tab="nueva-venta">
            <i class="fa-solid fa-cart-plus mr-1.5"></i> Facturar
          </button>"""

    if old_nav_items in html:
        html = html.replace(old_nav_items, new_nav_items)
        print("Navbar auth button added!")
    else:
        print("Warning: old_nav_items not found directly.")

    # 2. AGREGAR EL BADGE DE USUARIO EN NAVBAR SIEMPRE VISIBLE
    old_user_badge = """        <!-- USUARIO ACTIVO (AUTENTICACIÓN) -->
        <div class="hidden md:flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs cursor-pointer hover:bg-slate-700 transition" onclick="abrirModalAuth()" title="Gestionar Sesión / Autenticación">
          <i class="fa-solid fa-circle-user text-indigo-400 text-sm"></i>
          <div>
            <span id="navUsuarioNombre" class="font-semibold text-slate-200 block leading-tight">Juan Admin</span>
            <span id="navUsuarioRol" class="text-[10px] text-indigo-300 block">Administrador (ID: 1)</span>
          </div>
          <i class="fa-solid fa-chevron-down text-[10px] text-slate-400 ml-1"></i>
        </div>"""

    new_user_badge = """        <!-- USUARIO ACTIVO (AUTENTICACIÓN) -->
        <div class="flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs cursor-pointer hover:bg-slate-700 transition shrink-0" onclick="cambiarPestana('auth')" title="Clic para ir al Módulo de Autenticación y Seguridad">
          <i class="fa-solid fa-circle-user text-indigo-400 text-sm"></i>
          <div>
            <span id="navUsuarioNombre" class="font-semibold text-slate-200 block leading-tight">Juan Admin</span>
            <span id="navUsuarioRol" class="text-[10px] text-indigo-300 block">Administrador (ID: 1)</span>
          </div>
          <i class="fa-solid fa-key text-[10px] text-indigo-400 ml-1"></i>
        </div>"""

    if old_user_badge in html:
        html = html.replace(old_user_badge, new_user_badge)
        print("User badge updated!")

    # 3. AGREGAR LA SECCIÓN tab-auth EN EL HTML
    tab_auth_html = """
    <!-- 8. PESTAÑA AUTENTICACIÓN Y SEGURIDAD (PUNTO 4.1) -->
    <section id="tab-auth" class="tab-content hidden space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Módulo de Autenticación Básica y Seguridad (Punto 4.1)</h1>
          <p class="text-sm text-slate-500">Validación de credenciales contra MySQL (tabla <span class="font-mono text-indigo-600 font-bold">usuarios</span>), generación de tokens y protección con decorador <span class="font-mono text-indigo-600 font-bold">@login_requerido</span>.</p>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs bg-indigo-50 text-indigo-700 border border-indigo-200 px-3 py-1.5 rounded-lg font-mono font-bold flex items-center gap-1.5">
            <i class="fa-solid fa-shield-halved"></i> Blueprint auth_bp (/api/auth/)
          </span>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Columna Izquierda: Formulario de Login -->
        <div class="lg:col-span-5 space-y-6">
          <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div class="flex items-center gap-2.5 border-b pb-3">
              <div class="h-9 w-9 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-lg">
                <i class="fa-solid fa-key"></i>
              </div>
              <div>
                <h2 class="text-base font-bold text-slate-900">Iniciar Sesión de Operador</h2>
                <p class="text-xs text-slate-500 font-mono">POST /api/auth/login</p>
              </div>
            </div>

            <form onsubmit="ejecutarLoginCredencialesTab(event)" class="space-y-4">
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Correo Electrónico *</label>
                <div class="relative">
                  <i class="fa-solid fa-envelope absolute left-3 top-3 text-slate-400 text-xs"></i>
                  <input type="email" id="tabLoginEmail" value="admin@erp.com" required 
                         class="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg outline-none focus:border-indigo-500">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Contraseña de Acceso *</label>
                <div class="relative">
                  <i class="fa-solid fa-lock absolute left-3 top-3 text-slate-400 text-xs"></i>
                  <input type="password" id="tabLoginPass" value="admin123" required 
                         class="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg outline-none focus:border-indigo-500">
                </div>
                <p class="text-[11px] text-slate-400 mt-1">Credenciales por defecto: <code class="text-indigo-600 font-semibold">admin@erp.com / admin123</code></p>
              </div>

              <button type="submit" id="btnTabLoginSubmit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold shadow-sm flex items-center justify-center gap-2 transition">
                <i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión y Generar Token
              </button>
            </form>
          </div>

          <!-- Tarjeta de Estado de Sesión y Token Actual -->
          <div class="bg-slate-900 text-white p-6 rounded-2xl shadow-lg space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <span class="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                <i class="fa-solid fa-shield-halved"></i> Estado de Sesión en Navegador
              </span>
              <span id="tabTokenBadge" class="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Token Activo
              </span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="flex justify-between">
                <span class="text-slate-400">Usuario Conectado:</span>
                <span id="tabUsuarioConectado" class="font-bold text-white">Administrador del Sistema</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">ID Usuario:</span>
                <span id="tabUsuarioId" class="font-mono text-indigo-300">#1</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">Rol de Sistema:</span>
                <span id="tabUsuarioRol" class="font-bold text-indigo-300">Rol #1 (Admin)</span>
              </div>
            </div>

            <div>
              <span class="text-[11px] font-semibold text-slate-400 block mb-1">Token de Sesión (Bearer):</span>
              <div class="p-2.5 bg-slate-800 rounded-lg font-mono text-[11px] text-emerald-400 break-all select-all border border-slate-700" id="tabTokenDisplay">
                erp_token_1_activo
              </div>
              <p class="text-[10px] text-slate-500 mt-1">Este token se inyecta en <code class="text-slate-300">Authorization: Bearer &lt;token&gt;</code> para proteger ventas y anulaciones.</p>
            </div>

            <div class="flex gap-2 pt-2">
              <button onclick="probarRutaProtegida(true)" class="flex-1 py-1.5 bg-indigo-700 hover:bg-indigo-600 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition">
                <i class="fa-solid fa-check-double"></i> Probar Con Token
              </button>
              <button onclick="probarRutaProtegida(false)" class="flex-1 py-1.5 bg-rose-900/60 hover:bg-rose-900 text-rose-200 border border-rose-700/50 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition" title="Simula enviar petición sin token para verificar error 401">
                <i class="fa-solid fa-triangle-exclamation"></i> Probar Sin Token (401)
              </button>
            </div>

            <button onclick="cerrarSesionAuth()" class="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition">
              <i class="fa-solid fa-arrow-right-from-bracket text-rose-400"></i> Cerrar Sesión (Invalidar Token)
            </button>
          </div>
        </div>

        <!-- Columna Derecha: Directorio de Usuarios en Base de Datos -->
        <div class="lg:col-span-7 space-y-6">
          <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div class="flex items-center justify-between border-b pb-3">
              <div class="flex items-center gap-2.5">
                <div class="h-9 w-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-lg">
                  <i class="fa-solid fa-users-gear"></i>
                </div>
                <div>
                  <h2 class="text-base font-bold text-slate-900">Usuarios Registrados en MySQL</h2>
                  <p class="text-xs text-slate-500 font-mono">GET /api/auth/usuarios</p>
                </div>
              </div>
              <button onclick="cargarUsuariosAuth()" class="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1">
                <i class="fa-solid fa-arrows-rotate"></i> Actualizar
              </button>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left text-xs">
                <thead class="bg-slate-100 text-slate-600 uppercase font-semibold border-b">
                  <tr>
                    <th class="py-2.5 px-3">ID</th>
                    <th class="py-2.5 px-3">Nombre</th>
                    <th class="py-2.5 px-3">Correo</th>
                    <th class="py-2.5 px-3 text-center">Rol</th>
                    <th class="py-2.5 px-3 text-center">Estado</th>
                    <th class="py-2.5 px-3 text-center">Acción</th>
                  </tr>
                </thead>
                <tbody id="tabUsuariosTbody" class="divide-y divide-slate-100">
                  <tr><td colspan="6" class="text-center py-6 text-slate-400">Cargando usuarios...</td></tr>
                </tbody>
              </table>
            </div>

            <div class="p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-xl text-xs text-indigo-900 leading-relaxed">
              <i class="fa-solid fa-circle-check text-indigo-600 mr-1.5"></i>
              <strong>Cláusula de Seguridad:</strong> La contraseña nunca se retorna en las consultas JSON (<span class="font-mono">SELECT id_usuario, nombre, correo, estado, roles_id_rol FROM usuarios</span>). Las rutas críticas de ventas están blindadas por el decorador <span class="font-mono font-bold">@login_requerido</span>.
            </div>
          </div>
        </div>
      </div>
    </section>
"""

    if "id=\"tab-auth\"" not in html:
        html = html.replace('<!-- 6. PESTAÑA NUEVA VENTA (FACTURACIÓN) -->', tab_auth_html + '\n    <!-- 6. PESTAÑA NUEVA VENTA (FACTURACIÓN) -->')
        print("Tab auth section added to HTML!")

    # 4. AGREGAR JAVASCRIPT DE SOPORTE PARA tab-auth
    js_auth = """
    // FUNCIONES DEL TAB DE AUTENTICACIÓN (PUNTO 4.1)
    function renderizarTabAuth() {
      const token = localStorage.getItem('erp_token') || 'erp_token_1_admin';
      const tokenDisplay = document.getElementById('tabTokenDisplay');
      if (tokenDisplay) tokenDisplay.innerText = token;

      const userConectado = document.getElementById('tabUsuarioConectado');
      if (userConectado && usuarioActivo) userConectado.innerText = usuarioActivo.nombre;

      const userId = document.getElementById('tabUsuarioId');
      if (userId && usuarioActivo) userId.innerText = `#${usuarioActivo.id_usuario}`;

      const userRol = document.getElementById('tabUsuarioRol');
      if (userRol && usuarioActivo) userRol.innerText = `Rol #${usuarioActivo.roles_id_rol || 1}`;

      renderizarTablaUsuariosTab();
    }

    function renderizarTablaUsuariosTab() {
      const tbody = document.getElementById('tabUsuariosTbody');
      if (!tbody) return;

      if (!usuariosData || usuariosData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-6 text-slate-400">No hay usuarios cargados aún.</td></tr>';
        return;
      }

      tbody.innerHTML = usuariosData.map(u => {
        const esActivo = usuarioActivo && usuarioActivo.id_usuario === u.id_usuario;
        return `
          <tr class="hover:bg-slate-50 transition ${esActivo ? 'bg-indigo-50/50' : ''}">
            <td class="py-2.5 px-3 font-mono font-bold text-slate-700">#${u.id_usuario}</td>
            <td class="py-2.5 px-3 font-semibold text-slate-900">${u.nombre}</td>
            <td class="py-2.5 px-3 text-slate-600">${u.correo}</td>
            <td class="py-2.5 px-3 text-center">
              <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 border">
                Rol ${u.roles_id_rol}
              </span>
            </td>
            <td class="py-2.5 px-3 text-center">
              <span class="px-2 py-0.5 rounded text-[11px] font-bold ${u.estado === 1 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
                ${u.estado === 1 ? 'Activo' : 'Inactivo'}
              </span>
            </td>
            <td class="py-2.5 px-3 text-center">
              ${esActivo 
                ? '<span class="px-2.5 py-1 bg-indigo-600 text-white rounded-md text-[11px] font-bold">Sesión Actual</span>'
                : `<button onclick="seleccionarUsuarioAuth(${u.id_usuario}); renderizarTabAuth();" class="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-md text-[11px] font-semibold transition border border-slate-200">
                     Conectar
                   </button>`
              }
            </td>
          </tr>
        `;
      }).join('');
    }

    async function ejecutarLoginCredencialesTab(e) {
      e.preventDefault();
      const correo = document.getElementById('tabLoginEmail').value;
      const password = document.getElementById('tabLoginPass').value;
      const btn = document.getElementById('btnTabLoginSubmit');

      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Validando credenciales...';

      try {
        const res = await fetch(`${API_BASE}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ correo, password })
        });

        const data = await res.json();
        if (!res.ok) {
          showToast(data.error || "Credenciales incorrectas.", "error");
          return;
        }

        if (data.token) {
          localStorage.setItem('erp_token', data.token);
        }
        usuarioActivo = data.usuario;
        actualizarPillUsuarioNav();
        renderizarTabAuth();
        showToast(`¡Autenticado con éxito como ${data.usuario.nombre}! Token de sesión generado.`, "success");
      } catch (err) {
        showToast("Error de conexión al autenticar.", "error");
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión y Generar Token';
      }
    }

    function cerrarSesionAuth() {
      localStorage.removeItem('erp_token');
      const tokenDisplay = document.getElementById('tabTokenDisplay');
      if (tokenDisplay) tokenDisplay.innerText = '(Sin token - Sesión cerrada)';
      const badge = document.getElementById('tabTokenBadge');
      if (badge) {
        badge.className = 'px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30';
        badge.innerText = 'Sin Token';
      }
      showToast("Sesión cerrada. El token ha sido removido.", "info");
    }

    async function probarRutaProtegida(conToken) {
      const headers = { 'Content-Type': 'application/json' };
      if (conToken) {
        const token = localStorage.getItem('erp_token') || 'erp_token_1_demo';
        headers['Authorization'] = `Bearer ${token}`;
      }

      showToast(conToken ? "Enviando petición CON token..." : "Enviando petición SIN token para probar @login_requerido...", "info");

      try {
        const res = await fetch(`${API_BASE}/api/ventas/`, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify({ id_tercero: 1, id_usuario: 1, detalles: [] })
        });
        const data = await res.json();
        if (res.status === 401) {
          showToast(`¡Decorador @login_requerido operando!: ${data.error} (HTTP 401)`, "warning");
        } else {
          showToast(`Respuesta servidor: HTTP ${res.status}`, "info");
        }
      } catch (e) {
        showToast(`Error al probar ruta: ${e.message}`, "error");
      }
    }
"""

    if "renderizarTabAuth" not in html:
        html = html.replace('if (tabName === \'cartera\') cargarCartera();', 'if (tabName === \'cartera\') cargarCartera();\n      if (tabName === \'auth\') renderizarTabAuth();')
        html = html.replace('// 8. MÓDULO AUTENTICACIÓN Y GESTIÓN DE USUARIOS', js_auth + '\n    // 8. MÓDULO AUTENTICACIÓN Y GESTIÓN DE USUARIOS')
        print("JS functions for auth tab added!")

    with open("frontend/index.html", "w", encoding="utf-8") as f:
        f.write(html)
    with open("backend/static/index.html", "w", encoding="utf-8") as f:
        f.write(html)
    print("Files synced!")

if __name__ == '__main__':
    update_auth_in_frontend()
