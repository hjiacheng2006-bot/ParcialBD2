with open('frontend/index.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Reemplazar inactivarTercero y reactivarTercero para usar obtenerHeadersAuth
old_inact = """        const res = await fetch(`${API_BASE}/api/terceros/${id}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
            ...(tokenSesion ? { 'Authorization': `Bearer ${tokenSesion}` } : {})
          }
        });"""

new_inact = """        const token = localStorage.getItem('erp_token');
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const res = await fetch(`${API_BASE}/api/terceros/${id}`, {
          method: 'DELETE',
          headers
        });"""

assert old_inact in text, "old_inact not found"
text = text.replace(old_inact, new_inact)

old_react = """        const res = await fetch(`${API_BASE}/api/terceros/${id}/activar`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(tokenSesion ? { 'Authorization': `Bearer ${tokenSesion}` } : {})
          }
        });"""

new_react = """        const token = localStorage.getItem('erp_token');
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const res = await fetch(`${API_BASE}/api/terceros/${id}/activar`, {
          method: 'PUT',
          headers
        });"""

assert old_react in text, "old_react not found"
text = text.replace(old_react, new_react)

# Mejorar el mensaje de error en reactivarTercero para mostrar el error exacto recibido
old_toast_err = 'showToast("Error de conexión al reactivar tercero.", "error");'
new_toast_err = 'console.error("Error al reactivar:", err); showToast(err.message || "Error al procesar la reactivación.", "error");'
text = text.replace(old_toast_err, new_toast_err)

old_toast_inact = 'showToast("Error de conexión al inactivar tercero.", "error");'
new_toast_inact = 'console.error("Error al inactivar:", err); showToast(err.message || "Error al procesar la inactivación.", "error");'
text = text.replace(old_toast_inact, new_toast_inact)

with open('frontend/index.html', 'w', encoding='utf-8') as f:
    f.write(text)
with open('backend/static/index.html', 'w', encoding='utf-8') as f:
    f.write(text)

print('Successfully fixed token reference and error handling in frontend/index.html and backend/static/index.html!')
