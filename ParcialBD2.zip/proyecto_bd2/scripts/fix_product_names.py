import sys
from backend.config import get_db_connection

def fix_names():
    conn = get_db_connection()
    cur = conn.cursor()
    updates = [
        (1, "Diadema Gamer HyperX Cloud"),
        (2, "Mouse Inalámbrico Logitech"),
        (3, "Teclado Mecánico RGB Redragon"),
        (4, "Monitor 24 Pulgadas FHD"),
        (5, "Silla Ergonómica Pro")
    ]
    for id_p, name in updates:
        cur.execute("UPDATE productos SET nombre = %s WHERE id_producto = %s", (name, id_p))
    conn.commit()
    print("Database product names cleaned!")
    cur.execute("SELECT id_producto, nombre FROM productos")
    for row in cur.fetchall():
        print(row)
    conn.close()

if __name__ == '__main__':
    fix_names()
