import re

with open('frontend/index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update Navbar title and add Cartera Tab + Auth pill
old_nav_badge = 'Fase 1: Transaccional'
new_nav_badge = 'Fase 2: Consolidación Definitiva'
content = content.replace(old_nav_badge, new_nav_badge)

old_nav_tabs = """          <button onclick="cambiarPestana('reportes')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition text-slate-300 hover:text-white hover:bg-slate-800" data-tab="reportes">
            <i class="fa-solid fa-chart-line mr-1.5"></i> Reportes
          </button>
          <button onclick="cambiarPestana('nueva-venta')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm" data-tab="nueva-venta">
            <i class="fa-solid fa-cart-plus mr-1.5"></i> Facturar
          </button>"""

new_nav_tabs = """          <button onclick="cambiarPestana('cartera')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition text-slate-300 hover:text-white hover:bg-slate-800" data-tab="cartera">
            <i class="fa-solid fa-wallet mr-1.5"></i> Cartera
          </button>
          <button onclick="cambiarPestana('reportes')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition text-slate-300 hover:text-white hover:bg-slate-800" data-tab="reportes">
            <i class="fa-solid fa-chart-line mr-1.5"></i> Reportes
          </button>
          <button onclick="cambiarPestana('nueva-venta')" class="tab-btn px-3 py-2 rounded-md text-sm font-medium transition bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm" data-tab="nueva-venta">
            <i class="fa-solid fa-cart-plus mr-1.5"></i> Facturar
          </button>"""

content = content.replace(old_nav_tabs, new_nav_tabs)

# Add User Session Pill in Navbar
old_conn_status = """        <!-- STATUS CONEXIÓN -->
        <div class="hidden lg:flex items-center gap-2 text-xs">
          <span id="connStatusDot" class="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span id="connStatusText" class="text-slate-300 font-medium">API Conectada</span>
        </div>"""

new_conn_status = """        <!-- USUARIO ACTIVO (AUTENTICACIÓN) -->
        <div class="hidden md:flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs cursor-pointer hover:bg-slate-700 transition" onclick="abrirModalAuth()" title="Gestionar Sesión / Autenticación">
          <i class="fa-solid fa-circle-user text-indigo-400 text-sm"></i>
          <div>
            <span id="navUsuarioNombre" class="font-semibold text-slate-200 block leading-tight">Juan Admin</span>
            <span id="navUsuarioRol" class="text-[10px] text-indigo-300 block">Administrador (ID: 1)</span>
          </div>
          <i class="fa-solid fa-chevron-down text-[10px] text-slate-400 ml-1"></i>
        </div>

        <!-- STATUS CONEXIÓN -->
        <div class="hidden lg:flex items-center gap-2 text-xs">
          <span id="connStatusDot" class="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span id="connStatusText" class="text-slate-300 font-medium">API Conectada</span>
        </div>"""

content = content.replace(old_conn_status, new_conn_status)

# 2. Add Cartera Card in Dashboard
old_dash_grid = '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">'
new_dash_grid = '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">'
content = content.replace(old_dash_grid, new_dash_grid)

old_dash_anuladas = """        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Ventas Anuladas</p>
            <h3 id="statVentasAnuladas" class="text-2xl font-extrabold text-rose-600 mt-1">0</h3>
            <p class="text-xs text-slate-500 font-medium mt-1">Reversión de stock</p>
          </div>
          <div class="h-12 w-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center text-xl">
            <i class="fa-solid fa-ban"></i>
          </div>
        </div>
      </div>"""

new_dash_anuladas = """        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Ventas Anuladas</p>
            <h3 id="statVentasAnuladas" class="text-2xl font-extrabold text-rose-600 mt-1">0</h3>
            <p class="text-xs text-slate-500 font-medium mt-1">Reversión de stock</p>
          </div>
          <div class="h-12 w-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center text-xl">
            <i class="fa-solid fa-ban"></i>
          </div>
        </div>

        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Cartera Activa</p>
            <h3 id="statCarteraDash" class="text-2xl font-extrabold text-amber-600 mt-1">$0.00</h3>
            <p id="statCantCarteraDash" class="text-xs text-amber-700 font-medium mt-1">0 por cobrar</p>
          </div>
          <div class="h-12 w-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-xl">
            <i class="fa-solid fa-wallet"></i>
          </div>
        </div>
      </div>"""

content = content.replace(old_dash_anuladas, new_dash_anuladas)

# 3. Dynamic search & filter in Productos Tab
old_prod_filter = """      <!-- Buscador -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
        <i class="fa-solid fa-magnifying-glass text-slate-400"></i>
        <input type="text" id="filtroProductos" oninput="filtrarProductos()" placeholder="Buscar producto por nombre o ID..." class="w-full text-sm bg-transparent outline-none">
      </div>"""

new_prod_filter = """      <!-- Buscador y Filtros Dinámicos (PUNTO 3: Cláusula %s anti-inyección SQL) -->
      <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div class="flex items-center gap-3 border-b pb-3">
          <i class="fa-solid fa-magnifying-glass text-slate-400"></i>
          <input type="text" id="filtroProductos" oninput="filtrarProductos()" placeholder="Buscar producto por nombre..." class="w-full text-sm bg-transparent outline-none">
          <span class="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 hidden sm:inline">WHERE nombre LIKE %s</span>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 items-center text-xs">
          <div>
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Precio Mínimo ($):</label>
            <input type="number" id="filtroPrecioMin" oninput="filtrarProductos()" placeholder="0" min="0" class="w-full p-2 border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs">
          </div>
          <div>
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Precio Máximo ($):</label>
            <input type="number" id="filtroPrecioMax" oninput="filtrarProductos()" placeholder="Sin límite" min="0" class="w-full p-2 border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs">
          </div>
          <div>
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Stock Mínimo:</label>
            <input type="number" id="filtroStockMin" oninput="filtrarProductos()" placeholder="Cualquiera" min="0" class="w-full p-2 border border-slate-200 rounded-lg outline-none focus:border-indigo-500 text-xs">
          </div>
          <div class="flex items-end gap-2 pt-2 sm:pt-4">
            <button onclick="limpiarFiltrosProductos()" class="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-xs transition flex items-center justify-center gap-1.5">
              <i class="fa-solid fa-eraser"></i> Limpiar Filtros
            </button>
          </div>
        </div>
      </div>"""

content = content.replace(old_prod_filter, new_prod_filter)

# 4. In Nueva Venta: Vendedor / Usuario dropdown instead of raw input
old_cajero_input = """              <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Usuario Cajero / Vendedor *</label>
                <input type="number" id="ventaUsuarioInput" value="1" min="1" class="w-full p-2.5 border border-slate-300 rounded-lg text-sm bg-slate-50 focus:bg-white focus:border-indigo-500 outline-none">
              </div>"""

new_cajero_input = """              <div>
                <label class="block text-xs font-semibold text-slate-600 mb-1">Usuario / Vendedor Autenticado *</label>
                <select id="ventaUsuarioSelect" class="w-full p-2.5 border border-slate-300 rounded-lg text-sm bg-slate-50 focus:bg-white focus:border-indigo-500 outline-none">
                  <option value="1">Cargando usuarios...</option>
                </select>
              </div>"""

content = content.replace(old_cajero_input, new_cajero_input)

# 5. Add Tab Cartera Section before </main>
tab_cartera_html = """    <!-- 6. PESTAÑA CARTERA Y COBROS (PUNTO ADICIONAL FASE 2) -->
    <section id="tab-cartera" class="tab-content hidden space-y-6">
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 class="text-2xl font-bold text-slate-900">Cartera y Cuentas por Cobrar</h1>
          <p class="text-sm text-slate-500">Gestión de créditos comerciales, facturas con saldo pendiente y registro de abonos.</p>
        </div>
        <button onclick="cargarCartera()" class="self-start sm:self-auto px-4 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg text-sm font-medium shadow-sm flex items-center gap-2">
          <i class="fa-solid fa-arrows-rotate"></i> Actualizar Cartera
        </button>
      </div>

      <!-- TARJETAS DE RESUMEN DE CARTERA -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Cartera Activa</p>
            <h3 id="statTotalCartera" class="text-2xl font-extrabold text-amber-600 mt-1">$0.00</h3>
            <p class="text-xs text-slate-500 font-medium mt-1">Saldo pendiente por recaudar</p>
          </div>
          <div class="h-12 w-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-xl">
            <i class="fa-solid fa-hand-holding-dollar"></i>
          </div>
        </div>

        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Obligaciones Pendientes</p>
            <h3 id="statCantCartera" class="text-2xl font-extrabold text-slate-900 mt-1">0</h3>
            <p class="text-xs text-amber-600 font-medium mt-1">Facturas con saldo</p>
          </div>
          <div class="h-12 w-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl">
            <i class="fa-solid fa-file-invoice-dollar"></i>
          </div>
        </div>

        <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Módulo Blueprint</p>
            <h3 class="text-lg font-bold text-slate-800 mt-1">cartera_bp</h3>
            <p class="text-xs text-emerald-600 font-mono mt-1">/api/cartera/</p>
          </div>
          <div class="h-12 w-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl">
            <i class="fa-solid fa-shield-halved"></i>
          </div>
        </div>
      </div>

      <!-- TABLA DE CUENTAS POR COBRAR -->
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-4 border-b bg-slate-50 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <i class="fa-solid fa-wallet text-amber-500"></i>
            <span class="text-sm font-bold text-slate-800">Listado de Ventas en Crédito / Pendientes</span>
          </div>
          <span class="text-xs bg-white border border-slate-200 font-mono text-slate-600 px-2 py-0.5 rounded">INNER JOIN ventas + terceros</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead class="text-xs uppercase bg-slate-100 text-slate-500 border-b font-semibold">
              <tr>
                <th class="py-3 px-4">Factura</th>
                <th class="py-3 px-4">Fecha Venta</th>
                <th class="py-3 px-4">Cliente Deudor</th>
                <th class="py-3 px-4">Contacto / Correo</th>
                <th class="py-3 px-4 text-center">Estado</th>
                <th class="py-3 px-4 text-right">Saldo Deudor</th>
                <th class="py-3 px-4 text-center">Gestión Cobro</th>
              </tr>
            </thead>
            <tbody id="carteraTbody" class="divide-y divide-slate-100">
              <tr><td colspan="7" class="text-center py-6 text-slate-400">Cargando cartera...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
"""

content = content.replace('  </main>', tab_cartera_html + '\n  </main>')

# 6. Add Modal Abono Cartera & Modal Auth
modals_html = """  <!-- MODAL REGISTRAR ABONO / LIQUIDAR CARTERA -->
  <div id="modalAbonoCartera" class="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
      <div class="flex justify-between items-center border-b pb-3">
        <div>
          <h3 class="text-lg font-bold text-slate-900">Registrar Abono a Venta</h3>
          <p id="modalAbonoSubtitulo" class="text-xs text-slate-500">Factura #</p>
        </div>
        <button onclick="cerrarModalAbono()" class="text-slate-400 hover:text-slate-600"><i class="fa-solid fa-xmark text-lg"></i></button>
      </div>
      <form id="formAbono" onsubmit="procesarAbonoCartera(event)" class="space-y-4">
        <input type="hidden" id="abonoIdVenta">
        <div class="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
          <div class="flex justify-between"><span class="text-slate-500">Cliente:</span><span id="abonoClienteNombre" class="font-bold text-slate-800">-</span></div>
          <div class="flex justify-between"><span class="text-slate-500">Saldo Total:</span><span id="abonoTotalVenta" class="font-extrabold text-indigo-600">$0.00</span></div>
          <div class="flex justify-between"><span class="text-slate-500">Estado Actual:</span><span id="abonoEstadoActual" class="font-bold text-amber-600">-</span></div>
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-700 mb-1">Monto del Abono ($) *</label>
          <div class="relative">
            <span class="absolute left-3 top-2.5 text-slate-400 text-sm">$</span>
            <input type="number" id="abonoMontoInput" step="0.01" min="1" required class="w-full pl-7 p-2.5 border rounded-lg text-sm font-bold text-slate-800 outline-none focus:border-indigo-500">
          </div>
          <button type="button" onclick="abonarSaldoTotal()" class="text-xs text-indigo-600 hover:text-indigo-800 font-semibold mt-1">Abonar saldo total (Liquidar)</button>
        </div>
        <div class="flex justify-end gap-2 pt-2 border-t">
          <button type="button" onclick="cerrarModalAbono()" class="px-4 py-2 border rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancelar</button>
          <button type="submit" id="btnGuardarAbono" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-semibold flex items-center gap-1.5 shadow-sm">
            <i class="fa-solid fa-check"></i> Aplicar Abono
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- MODAL AUTENTICACIÓN / CAMBIO DE USUARIO -->
  <div id="modalAuth" class="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
      <div class="flex justify-between items-center border-b pb-3">
        <div class="flex items-center gap-2">
          <div class="h-8 w-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
            <i class="fa-solid fa-user-shield"></i>
          </div>
          <div>
            <h3 class="text-lg font-bold text-slate-900">Gestión de Usuarios y Acceso</h3>
            <p class="text-xs text-slate-500">Módulo auth_bp (/api/auth/)</p>
          </div>
        </div>
        <button onclick="cerrarModalAuth()" class="text-slate-400 hover:text-slate-600"><i class="fa-solid fa-xmark text-lg"></i></button>
      </div>

      <div class="space-y-3">
        <label class="block text-xs font-semibold text-slate-700">Seleccionar Usuario Activo:</label>
        <div id="authUsuariosList" class="space-y-2 max-h-56 overflow-y-auto">
          <!-- Lista dinámica de usuarios de la base de datos -->
        </div>
      </div>

      <div class="border-t pt-3 flex justify-between items-center text-xs text-slate-500">
        <span>Usuario actual: <strong id="modalAuthCurrentName" class="text-slate-800">Juan Admin</strong></span>
        <button onclick="cerrarModalAuth()" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg">Cerrar</button>
      </div>
    </div>
  </div>
"""

content = content.replace('  <!-- SCRIPT LOGIC JAVASCRIPT -->', modals_html + '\n  <!-- SCRIPT LOGIC JAVASCRIPT -->')

with open('frontend/index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("Frontend structure updated successfully!")
