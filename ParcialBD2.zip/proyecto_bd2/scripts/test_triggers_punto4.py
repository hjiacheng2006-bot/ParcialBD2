import mysql.connector

conn = mysql.connector.connect(host='localhost', port=3307, user='root', password='', database='erp')
cur = conn.cursor(dictionary=True)

# Limpiar posibles restos de pruebas anteriores
cur.execute("DELETE FROM recibos_caja WHERE observacion LIKE '%Abono de prueba%';")
cur.execute("DELETE FROM ventas WHERE id_tercero IN (SELECT id_tercero FROM terceros WHERE nombre LIKE '%Cliente Inactivo Test%');")
cur.execute("DELETE FROM terceros WHERE nombre LIKE '%Cliente Inactivo Test%';")
conn.commit()

print("=== 1. TEST TRIGGER PUNTO 4.3 (ventas_BEFORE_INSERT) ===")
# Crear un cliente de prueba e inactivarlo (estado = 0)
cur.execute("INSERT INTO terceros (nombre, correo, contacto, estado) VALUES ('Cliente Inactivo Test', 'inactivo@test.com', '123456', 0);")
id_inactivo = cur.lastrowid
conn.commit()
print(f"Cliente inactivo creado con ID #{id_inactivo}")

# Intentar insertar una venta con este cliente inactivo
try:
    cur.execute(f"INSERT INTO ventas (fecha_venta, total_venta, estado_venta, id_usuario, id_tercero) VALUES (CURDATE(), 50000, 'Pendiente', 1, {id_inactivo});")
    conn.commit()
    print("ERROR: Trigger NO bloqueó la inserción!")
except mysql.connector.Error as e:
    print(f"Trigger ventas_BEFORE_INSERT funcionó correctamente! Capturado error {e.errno}: {e.msg}")

# Probar reactivar al cliente (estado = 1)
cur.execute(f"UPDATE terceros SET estado = 1 WHERE id_tercero = {id_inactivo};")
conn.commit()
print(f"Cliente #{id_inactivo} reactivado a estado = 1")

# Ahora la venta debe permitirse
cur.execute(f"INSERT INTO ventas (fecha_venta, total_venta, estado_venta, id_usuario, id_tercero) VALUES (CURDATE(), 50000, 'Pendiente', 1, {id_inactivo});")
id_venta = cur.lastrowid
conn.commit()
print(f"Venta #{id_venta} creada con éxito tras reactivación!")

print("\n=== 2. TEST TRIGGER PUNTO 4.2 (recibos_caja_AFTER_INSERT) ===")
# Establecer venta como 'Por Pagar' con total de 50000
cur.execute(f"UPDATE ventas SET total_venta = 50000, estado_venta = 'Por Pagar' WHERE id_venta = {id_venta};")
conn.commit()

# Abono parcial de 20000
cur.execute(f"INSERT INTO recibos_caja (id_venta, monto, observacion) VALUES ({id_venta}, 20000, 'Abono de prueba parcial');")
conn.commit()
cur.execute(f"SELECT estado_venta FROM ventas WHERE id_venta = {id_venta};")
estado = cur.fetchone()['estado_venta']
print(f"Tras abono parcial de $20.000 / $50.000, estado_venta = '{estado}'")
assert estado == 'Por Pagar', f"Esperado Por Pagar, obtenido {estado}"

# Abono restante de 30000 (total abonado = 50000 >= 50000)
cur.execute(f"INSERT INTO recibos_caja (id_venta, monto, observacion) VALUES ({id_venta}, 30000, 'Abono de prueba liquidacion total');")
conn.commit()
cur.execute(f"SELECT estado_venta FROM ventas WHERE id_venta = {id_venta};")
estado_final = cur.fetchone()['estado_venta']
print(f"Tras abono restante de $30.000 (Total 50k), estado_venta = '{estado_final}'")
assert estado_final == 'Pagado', f"Esperado Pagado, obtenido {estado_final}"
print("¡Trigger recibos_caja_AFTER_INSERT funcionó 100% perfecto!")

# Limpiar datos de prueba
cur.execute(f"DELETE FROM recibos_caja WHERE id_venta = {id_venta};")
cur.execute(f"DELETE FROM ventas WHERE id_venta = {id_venta};")
cur.execute(f"DELETE FROM terceros WHERE id_tercero = {id_inactivo};")
conn.commit()
print("\nLimpieza de pruebas completada exitosamente.")
