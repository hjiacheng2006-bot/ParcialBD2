sql_punto4 = """
-- ==============================================================
-- PUNTO 4: MÓDULOS ADICIONALES (FASE 2)
-- ==============================================================

-- 4.4 Manejo de Archivos Estáticos: Columna imagen en productos
ALTER TABLE `productos` ADD COLUMN IF NOT EXISTS `imagen` VARCHAR(255) NULL;

-- 4.2 Transacciones Financieras: Tabla auxiliar recibos_caja
CREATE TABLE IF NOT EXISTS `recibos_caja` (
  `id_recibo` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `fecha_recibo` datetime DEFAULT CURRENT_TIMESTAMP,
  `monto` decimal(12,2) NOT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_recibo`),
  KEY `fk_recibos_ventas_idx` (`id_venta`),
  CONSTRAINT `fk_recibos_ventas` FOREIGN KEY (`id_venta`) REFERENCES `ventas` (`id_venta`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 4.2 Trigger recibos_caja_AFTER_INSERT: Evalúa si sumatoria cubre el total y actualiza a 'Pagado'
DELIMITER ;;
DROP TRIGGER IF EXISTS `recibos_caja_AFTER_INSERT`;;
CREATE TRIGGER `recibos_caja_AFTER_INSERT` AFTER INSERT ON `recibos_caja` FOR EACH ROW
BEGIN
    DECLARE v_total_factura DECIMAL(12, 2);
    DECLARE v_total_abonado DECIMAL(12, 2);

    SELECT total_venta INTO v_total_factura
    FROM ventas
    WHERE id_venta = NEW.id_venta;

    SELECT IFNULL(SUM(monto), 0) INTO v_total_abonado
    FROM recibos_caja
    WHERE id_venta = NEW.id_venta;

    IF v_total_abonado >= v_total_factura THEN
        UPDATE ventas
        SET estado_venta = 'Pagado'
        WHERE id_venta = NEW.id_venta;
    ELSE
        UPDATE ventas
        SET estado_venta = 'Por Pagar'
        WHERE id_venta = NEW.id_venta;
    END IF;
END ;;
DELIMITER ;

-- 4.3 Integridad Relacional: Soft Delete en Cascada (ventas_BEFORE_INSERT)
DELIMITER ;;
DROP TRIGGER IF EXISTS `ventas_BEFORE_INSERT`;;
CREATE TRIGGER `ventas_BEFORE_INSERT` BEFORE INSERT ON `ventas` FOR EACH ROW
BEGIN
    DECLARE v_estado_cliente INT;

    SELECT estado INTO v_estado_cliente
    FROM terceros
    WHERE id_tercero = NEW.id_tercero;

    IF v_estado_cliente = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Operación denegada: El cliente seleccionado se encuentra inactivo (Soft Delete).';
    END IF;
END ;;
DELIMITER ;

-- 4.3 Integridad Relacional: Soft Delete en Cascada (pedidos_BEFORE_INSERT)
DELIMITER ;;
DROP TRIGGER IF EXISTS `pedidos_BEFORE_INSERT`;;
CREATE TRIGGER `pedidos_BEFORE_INSERT` BEFORE INSERT ON `pedidos` FOR EACH ROW
BEGIN
    DECLARE v_estado_tercero INT;

    SELECT estado INTO v_estado_tercero
    FROM terceros
    WHERE id_tercero = NEW.id_tercero;

    IF v_estado_tercero = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Operación denegada: El proveedor/tercero seleccionado se encuentra inactivo (Soft Delete).';
    END IF;
END ;;
DELIMITER ;
"""

for filepath in ['db/init.sql', 'db/schemaSTD.sql']:
    with open(filepath, 'a', encoding='utf-8') as f:
        f.write(sql_punto4)
    print(f"Punto 4 SQL appended to {filepath}")
