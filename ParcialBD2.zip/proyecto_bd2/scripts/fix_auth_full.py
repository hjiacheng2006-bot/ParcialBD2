import re

def fix_auth():
    file_path = "frontend/index.html"
    with open(file_path, "r", encoding="utf-8") as f:
        html = f.read()

    # 1. NAVBAR USER PILL: ensure id="navUsuarioIcon" exists
    old_user_badge = """        <!-- USUARIO ACTIVO (AUTENTICACIÓN) -->
        <div class="flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs cursor-pointer hover:bg-slate-700 transition shrink-0" onclick="cambiarPestana('auth')" title="Clic para ir al Módulo de Autenticación y Seguridad">
          <i class="fa-solid fa-circle-user text-indigo-400 text-sm"></i>
          <div>
            <span id="navUsuarioNombre" class="font-semibold text-slate-200 block leading-tight">Juan Admin</span>
            <span id="navUsuarioRol" class="text-[10px] text-indigo-300 block">Administrador (ID: 1)</span>
          </div>
          <i class="fa-solid fa-key text-[10px] text-indigo-400 ml-1"></i>
        </div>"""

    new_user_badge = """        <!-- USUARIO ACTIVO (AUTENTICACIÓN) -->
        <div class="flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs cursor-pointer hover:bg-slate-700 transition shrink-0 shadow-sm" onclick="cambiarPestana('auth')" title="Clic para ir al Módulo de Autenticación y Seguridad">
          <i id="navUsuarioIcon" class="fa-solid fa-circle-user text-emerald-400 text-sm"></i>
          <div>
            <span id="navUsuarioNombre" class="font-bold text-slate-100 block leading-tight">Administrador</span>
            <span id="navUsuarioRol" class="text-[10px] text-indigo-300 block">ID #1 • Activo</span>
          </div>
          <i class="fa-solid fa-key text-[10px] text-indigo-400 ml-1"></i>
        </div>"""

    if old_user_badge in html:
        html = html.replace(old_user_badge, new_user_badge)
        print("Updated navbar user badge!")

    # 2. TAB-AUTH HTML: inputs con iconos inline y botones de prueba con buen contraste
    old_auth_left = """            <form onsubmit="ejecutarLoginCredencialesTab(event)" class="space-y-4">
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Correo Electrónico *</label>
                <div class="relative">
                  <i class="fa-solid fa-envelope absolute left-3 top-3 text-slate-400 text-xs"></i>
                  <input type="email" id="tabLoginEmail" value="admin@erp.com" required 
                         class="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg outline-none focus:border-indigo-500">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Contraseña de Acceso *</label>
                <div class="relative">
                  <i class="fa-solid fa-lock absolute left-3 top-3 text-slate-400 text-xs"></i>
                  <input type="password" id="tabLoginPass" value="admin123" required 
                         class="w-full pl-8 pr-3 py-2 text-sm border border-slate-300 rounded-lg outline-none focus:border-indigo-500">
                </div>
                <p class="text-[11px] text-slate-400 mt-1">Credenciales por defecto: <code class="text-indigo-600 font-semibold">admin@erp.com / admin123</code></p>
              </div>

              <button type="submit" id="btnTabLoginSubmit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold shadow-sm flex items-center justify-center gap-2 transition">
                <i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión y Generar Token
              </button>
            </form>"""

    new_auth_left = """            <form onsubmit="ejecutarLoginCredencialesTab(event)" class="space-y-4">
              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Correo Electrónico *</label>
                <div class="relative flex items-center">
                  <i class="fa-solid fa-envelope absolute left-3 text-slate-400 text-xs pointer-events-none"></i>
                  <input type="email" id="tabLoginEmail" value="admin@erp.com" required 
                         class="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-lg outline-none focus:border-indigo-500 bg-white">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-slate-700 mb-1">Contraseña de Acceso *</label>
                <div class="relative flex items-center">
                  <i class="fa-solid fa-lock absolute left-3 text-slate-400 text-xs pointer-events-none"></i>
                  <input type="password" id="tabLoginPass" value="admin123" required 
                         class="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-lg outline-none focus:border-indigo-500 bg-white">
                </div>
                <p class="text-[11px] text-slate-400 mt-1">Credenciales en BD: <code class="text-indigo-600 font-bold">admin@erp.com / admin123</code> o <code class="text-indigo-600 font-bold">cajero@erp.com / 123456</code></p>
              </div>

              <button type="submit" id="btnTabLoginSubmit" class="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-bold shadow-md flex items-center justify-center gap-2 transition">
                <i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión y Generar Token
              </button>
            </form>"""

    if old_auth_left in html:
        html = html.replace(old_auth_left, new_auth_left)
        print("Updated auth left form!")

    # Actualizar botones de prueba de ruta protegida con mejor contraste
    old_test_btns = """            <div class="flex gap-2 pt-2">
              <button onclick="probarRutaProtegida(true)" class="flex-1 py-1.5 bg-indigo-700 hover:bg-indigo-600 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition">
                <i class="fa-solid fa-check-double"></i> Probar Con Token
              </button>
              <button onclick="probarRutaProtegida(false)" class="flex-1 py-1.5 bg-rose-900/60 hover:bg-rose-900 text-rose-200 border border-rose-700/50 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition" title="Simula enviar petición sin token para verificar error 401">
                <i class="fa-solid fa-triangle-exclamation"></i> Probar Sin Token (401)
              </button>
            </div>

            <button onclick="cerrarSesionAuth()" class="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 flex items-center justify-center gap-1.5 transition">
              <i class="fa-solid fa-arrow-right-from-bracket text-rose-400"></i> Cerrar Sesión (Invalidar Token)
            </button>"""

    new_test_btns = """            <div class="flex gap-2 pt-2">
              <button onclick="probarRutaProtegida(true)" class="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition">
                <i class="fa-solid fa-check-double"></i> Probar Con Token
              </button>
              <button onclick="probarRutaProtegida(false)" class="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition" title="Simula enviar petición sin token para verificar error 401 del decorador @login_requerido">
                <i class="fa-solid fa-ban"></i> Probar Sin Token (401)
              </button>
            </div>

            <button onclick="cerrarSesionAuth()" class="w-full py-2 bg-slate-800 hover:bg-rose-900/50 text-rose-300 rounded-lg text-xs font-bold border border-rose-800/40 flex items-center justify-center gap-2 transition">
              <i class="fa-solid fa-arrow-right-from-bracket text-rose-400"></i> Cerrar Sesión (Cerrar / Invalidar Token)
            </button>"""

    if old_test_btns in html:
        html = html.replace(old_test_btns, new_test_btns)
        print("Updated auth test buttons!")

    # 3. JAVASCRIPT: DEFINICIÓN DE usuarioActivo y PERSISTENCIA EN LOCALSTORAGE
    old_js_user_decl = "    let usuarioActivo = { id_usuario: 1, nombre: \"Juan Admin\", roles_id_rol: 1 };"
    new_js_user_decl = """    function obtenerUsuarioSesion() {
      try {
        const u = localStorage.getItem('erp_usuario');
        return u ? JSON.parse(u) : { id_usuario: 1, nombre: "Administrador del Sistema", roles_id_rol: 1 };
      } catch (e) {
        return { id_usuario: 1, nombre: "Administrador del Sistema", roles_id_rol: 1 };
      }
    }
    let usuarioActivo = obtenerUsuarioSesion();"""

    if old_js_user_decl in html:
        html = html.replace(old_js_user_decl, new_js_user_decl)
        print("Updated usuarioActivo declaration!")

    # 4. REEMPLAZAR TODA LA SECCIÓN DE FUNCIONES DE AUTENTICACIÓN
    old_auth_functions = """    // FUNCIONES DEL TAB DE AUTENTICACIÓN (PUNTO 4.1)
    async function renderizarTabAuth() {
      const token = localStorage.getItem('erp_token') || 'erp_token_1_admin';
      const tokenDisplay = document.getElementById('tabTokenDisplay');
      if (tokenDisplay) tokenDisplay.innerText = token;

      const userConectado = document.getElementById('tabUsuarioConectado');
      if (userConectado && usuarioActivo) userConectado.innerText = usuarioActivo.nombre;

      const userId = document.getElementById('tabUsuarioId');
      if (userId && usuarioActivo) userId.innerText = `#${usuarioActivo.id_usuario}`;

      const userRol = document.getElementById('tabUsuarioRol');
      if (userRol && usuarioActivo) userRol.innerText = `Rol #${usuarioActivo.roles_id_rol || 1}`;

      if (!usuariosData || usuariosData.length === 0) {
        await cargarUsuariosAuth();
      }
      renderizarTablaUsuariosTab();
    }

    function renderizarTablaUsuariosTab() {
      const tbody = document.getElementById('tabUsuariosTbody');
      if (!tbody) return;

      if (!usuariosData || usuariosData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-6 text-slate-400">No hay usuarios cargados aún.</td></tr>';
        return;
      }

      tbody.innerHTML = usuariosData.map(u => {
        const esActivo = usuarioActivo && usuarioActivo.id_usuario === u.id_usuario;
        return `
          <tr class="hover:bg-slate-50 transition ${esActivo ? 'bg-indigo-50/50' : ''}">
            <td class="py-2.5 px-3 font-mono font-bold text-slate-700">#${u.id_usuario}</td>
            <td class="py-2.5 px-3 font-semibold text-slate-900">${u.nombre}</td>
            <td class="py-2.5 px-3 text-slate-600">${u.correo}</td>
            <td class="py-2.5 px-3 text-center">
              <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 border">
                Rol ${u.roles_id_rol}
              </span>
            </td>
            <td class="py-2.5 px-3 text-center">
              <span class="px-2 py-0.5 rounded text-[11px] font-bold ${u.estado === 1 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
                ${u.estado === 1 ? 'Activo' : 'Inactivo'}
              </span>
            </td>
            <td class="py-2.5 px-3 text-center">
              ${esActivo 
                ? '<span class="px-2.5 py-1 bg-indigo-600 text-white rounded-md text-[11px] font-bold">Sesión Actual</span>'
                : `<button onclick="seleccionarUsuarioAuth(${u.id_usuario}); renderizarTabAuth();" class="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-md text-[11px] font-semibold transition border border-slate-200">
                     Conectar
                   </button>`
              }
            </td>
          </tr>
        `;
      }).join('');
    }

    async function ejecutarLoginCredencialesTab(e) {
      e.preventDefault();
      const correo = document.getElementById('tabLoginEmail').value;
      const password = document.getElementById('tabLoginPass').value;
      const btn = document.getElementById('btnTabLoginSubmit');

      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Validando credenciales...';

      try {
        const res = await fetch(`${API_BASE}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ correo, password })
        });

        const data = await res.json();
        if (!res.ok) {
          showToast(data.error || "Credenciales incorrectas.", "error");
          return;
        }

        if (data.token) {
          localStorage.setItem('erp_token', data.token);
        }
        usuarioActivo = data.usuario;
        actualizarPillUsuarioNav();
        renderizarTabAuth();
        showToast(`¡Autenticado con éxito como ${data.usuario.nombre}! Token de sesión generado.`, "success");
      } catch (err) {
        showToast("Error de conexión al autenticar.", "error");
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión y Generar Token';
      }
    }

    function cerrarSesionAuth() {
      localStorage.removeItem('erp_token');
      const tokenDisplay = document.getElementById('tabTokenDisplay');
      if (tokenDisplay) tokenDisplay.innerText = '(Sin token - Sesión cerrada)';
      const badge = document.getElementById('tabTokenBadge');
      if (badge) {
        badge.className = 'px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30';
        badge.innerText = 'Sin Token';
      }
      showToast("Sesión cerrada. El token ha sido removido.", "info");
    }

    async function probarRutaProtegida(conToken) {
      const headers = { 'Content-Type': 'application/json' };
      if (conToken) {
        const token = localStorage.getItem('erp_token') || 'erp_token_1_demo';
        headers['Authorization'] = `Bearer ${token}`;
      }

      showToast(conToken ? "Enviando petición CON token..." : "Enviando petición SIN token para probar @login_requerido...", "info");

      try {
        const res = await fetch(`${API_BASE}/api/ventas/`, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify({ id_tercero: 1, id_usuario: 1, detalles: [] })
        });
        const data = await res.json();
        if (res.status === 401) {
          showToast(`¡Decorador @login_requerido operando!: ${data.error} (HTTP 401)`, "warning");
        } else {
          showToast(`Respuesta servidor: HTTP ${res.status}`, "info");
        }
      } catch (e) {
        showToast(`Error al probar ruta: ${e.message}`, "error");
      }
    }"""

    new_auth_functions = """    // FUNCIONES DEL TAB DE AUTENTICACIÓN (PUNTO 4.1)
    async function renderizarTabAuth() {
      const token = localStorage.getItem('erp_token');
      const tokenDisplay = document.getElementById('tabTokenDisplay');
      const badge = document.getElementById('tabTokenBadge');
      const userConectado = document.getElementById('tabUsuarioConectado');
      const userId = document.getElementById('tabUsuarioId');
      const userRol = document.getElementById('tabUsuarioRol');

      if (token && usuarioActivo) {
        if (tokenDisplay) tokenDisplay.innerText = token;
        if (badge) {
          badge.className = 'px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
          badge.innerText = 'Token Activo';
        }
        if (userConectado) userConectado.innerText = usuarioActivo.nombre;
        if (userId) userId.innerText = `#${usuarioActivo.id_usuario}`;
        if (userRol) userRol.innerText = `Rol #${usuarioActivo.roles_id_rol || 1}`;
      } else {
        if (tokenDisplay) tokenDisplay.innerText = '(Sin token - Sesión cerrada)';
        if (badge) {
          badge.className = 'px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30';
          badge.innerText = 'Sin Sesión';
        }
        if (userConectado) userConectado.innerText = 'Ninguno (Inicie sesión abajo)';
        if (userId) userId.innerText = '-';
        if (userRol) userRol.innerText = '-';
      }

      if (!usuariosData || usuariosData.length === 0) {
        await cargarUsuariosAuth();
      }
      renderizarTablaUsuariosTab();
    }

    function renderizarTablaUsuariosTab() {
      const tbody = document.getElementById('tabUsuariosTbody');
      if (!tbody) return;

      if (!usuariosData || usuariosData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-6 text-slate-400">No hay usuarios cargados aún.</td></tr>';
        return;
      }

      const token = localStorage.getItem('erp_token');

      tbody.innerHTML = usuariosData.map(u => {
        const esActivo = token && usuarioActivo && usuarioActivo.id_usuario === u.id_usuario;
        return `
          <tr class="hover:bg-slate-50 transition ${esActivo ? 'bg-indigo-50/50' : ''}">
            <td class="py-2.5 px-3 font-mono font-bold text-slate-700">#${u.id_usuario}</td>
            <td class="py-2.5 px-3 font-semibold text-slate-900">${u.nombre}</td>
            <td class="py-2.5 px-3 text-slate-600">${u.correo}</td>
            <td class="py-2.5 px-3 text-center">
              <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 border">
                Rol ${u.roles_id_rol}
              </span>
            </td>
            <td class="py-2.5 px-3 text-center">
              <span class="px-2 py-0.5 rounded text-[11px] font-bold ${u.estado === 1 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
                ${u.estado === 1 ? 'Activo' : 'Inactivo'}
              </span>
            </td>
            <td class="py-2.5 px-3 text-center">
              ${esActivo 
                ? '<span class="px-2.5 py-1 bg-indigo-600 text-white rounded-md text-[11px] font-bold">Sesión Actual</span>'
                : `<button onclick="conectarUsuarioDirecto(${u.id_usuario})" class="px-2.5 py-1 bg-slate-100 hover:bg-indigo-600 hover:text-white rounded-md text-[11px] font-semibold transition border border-slate-200">
                     Iniciar como este usuario
                   </button>`
              }
            </td>
          </tr>
        `;
      }).join('');
    }

    async function ejecutarLoginCredencialesTab(e) {
      e.preventDefault();
      const correo = document.getElementById('tabLoginEmail').value.trim();
      const password = document.getElementById('tabLoginPass').value.trim();
      const btn = document.getElementById('btnTabLoginSubmit');

      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Validando credenciales...';

      try {
        const res = await fetch(`${API_BASE}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ correo, password })
        });

        const data = await res.json();
        if (!res.ok) {
          showToast(data.error || "Credenciales incorrectas.", "error");
          return;
        }

        if (data.token) {
          localStorage.setItem('erp_token', data.token);
        }
        if (data.usuario) {
          localStorage.setItem('erp_usuario', JSON.stringify(data.usuario));
          usuarioActivo = data.usuario;
        }

        actualizarPillUsuarioNav();
        renderizarTabAuth();

        const select = document.getElementById('ventaUsuarioSelect');
        if (select && usuarioActivo) select.value = usuarioActivo.id_usuario;

        showToast(`¡Sesión iniciada con éxito! Bienvenido, ${data.usuario.nombre}. Token generado.`, "success");
      } catch (err) {
        showToast("Error de conexión al autenticar.", "error");
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión y Generar Token';
      }
    }

    function conectarUsuarioDirecto(idUsuario) {
      const u = usuariosData.find(item => item.id_usuario === idUsuario);
      if (u) {
        const tokenSimulado = `erp_token_${u.id_usuario}_${Date.now()}`;
        localStorage.setItem('erp_token', tokenSimulado);
        localStorage.setItem('erp_usuario', JSON.stringify(u));
        usuarioActivo = u;
        actualizarPillUsuarioNav();
        renderizarTabAuth();

        const select = document.getElementById('ventaUsuarioSelect');
        if (select) select.value = u.id_usuario;

        showToast(`Sesión cambiada a: ${u.nombre}. Nuevo token asignado.`, "success");
      }
    }

    function cerrarSesionAuth() {
      localStorage.removeItem('erp_token');
      localStorage.removeItem('erp_usuario');
      usuarioActivo = null;

      actualizarPillUsuarioNav();
      renderizarTabAuth();

      showToast("Sesión cerrada. El token ha sido removido y la sesión invalidada.", "info");
    }

    async function probarRutaProtegida(conToken) {
      const headers = { 'Content-Type': 'application/json' };
      const token = localStorage.getItem('erp_token');

      if (conToken) {
        if (!token) {
          showToast("No hay sesión activa. Primero inicie sesión con el formulario de la izquierda.", "warning");
          return;
        }
        headers['Authorization'] = `Bearer ${token}`;
        showToast("Enviando petición a POST /api/ventas/ CON Bearer token...", "info");
      } else {
        showToast("Enviando petición a POST /api/ventas/ SIN token para probar @login_requerido...", "info");
      }

      try {
        const res = await fetch(`${API_BASE}/api/ventas/`, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify({ id_tercero: 1, id_usuario: 1, detalles: [] })
        });
        const data = await res.json();
        if (res.status === 401) {
          showToast(`¡Decorador @login_requerido bloqueó la petición!: "${data.error}" (HTTP 401)`, "error");
        } else if (res.status === 400 && data.error && data.error.includes("detalles")) {
          showToast(`¡Petición AUTORIZADA por @login_requerido! (Token válido, validación de venta pasó a reglas de detalle: HTTP ${res.status})`, "success");
        } else {
          showToast(`Respuesta del servidor: HTTP ${res.status}`, "info");
        }
      } catch (e) {
        showToast(`Error al probar ruta: ${e.message}`, "error");
      }
    }"""

    if old_auth_functions in html:
        html = html.replace(old_auth_functions, new_auth_functions)
        print("Updated auth functions!")
    else:
        print("Warning: old_auth_functions not matched directly.")

    # 5. ACTUALIZAR actualizarPillUsuarioNav PARA SOPORTAR null
    old_pill_nav = """    function actualizarPillUsuarioNav() {
      if (!usuarioActivo) return;
      const elNombre = document.getElementById('navUsuarioNombre');
      const elRol = document.getElementById('navUsuarioRol');
      if (elNombre) elNombre.innerText = usuarioActivo.nombre;
      if (elRol) elRol.innerText = `ID #${usuarioActivo.id_usuario} • Rol ${usuarioActivo.roles_id_rol || 1}`;
    }"""

    new_pill_nav = """    function actualizarPillUsuarioNav() {
      const elNombre = document.getElementById('navUsuarioNombre');
      const elRol = document.getElementById('navUsuarioRol');
      const icon = document.getElementById('navUsuarioIcon');
      const token = localStorage.getItem('erp_token');

      if (usuarioActivo && token) {
        if (elNombre) elNombre.innerText = usuarioActivo.nombre;
        if (elRol) elRol.innerText = `ID #${usuarioActivo.id_usuario} • Rol ${usuarioActivo.roles_id_rol || 1}`;
        if (icon) icon.className = "fa-solid fa-circle-user text-emerald-400 text-sm";
      } else {
        if (elNombre) elNombre.innerText = "Sin Sesión";
        if (elRol) elRol.innerText = "Clic para Iniciar Sesión";
        if (icon) icon.className = "fa-solid fa-lock text-rose-400 text-sm";
      }
    }"""

    if old_pill_nav in html:
        html = html.replace(old_pill_nav, new_pill_nav)
        print("Updated actualizarPillUsuarioNav!")

    # 6. EN anularVenta Y guardarVentaNueva: validar que exista token real
    html = html.replace("const token = localStorage.getItem('erp_token') || 'erp_token_1_admin';", "const token = localStorage.getItem('erp_token');")

    # Guardar ambos archivos
    with open("frontend/index.html", "w", encoding="utf-8") as f:
        f.write(html)
    with open("backend/static/index.html", "w", encoding="utf-8") as f:
        f.write(html)
    print("All files updated successfully!")

if __name__ == '__main__':
    fix_auth()
