import mysql.connector

from mysql.connector import Error

try:
    conn = mysql.connector.connect(host='localhost', port=3307, user='root', password='')
    cur = conn.cursor()
    cur.execute("CREATE USER IF NOT EXISTS 'estudiante'@'%' IDENTIFIED BY 'cotecnova2026';")
    cur.execute("CREATE USER IF NOT EXISTS 'estudiante'@'localhost' IDENTIFIED BY 'cotecnova2026';")
    cur.execute("GRANT ALL PRIVILEGES ON erp.* TO 'estudiante'@'%';")
    cur.execute("GRANT ALL PRIVILEGES ON erp.* TO 'estudiante'@'localhost';")
    cur.execute("FLUSH PRIVILEGES;")
    print("User estudiante configured on 3307 successfully!")
except mysql.connector.Error as e:
    err = e
    print("Error de base de datos:", err)
