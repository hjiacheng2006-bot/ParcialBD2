with open('frontend/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update table header in Productos to include Foto column
old_prod_th = """              <tr>
                <th class="py-3 px-4">ID</th>
                <th class="py-3 px-4">Nombre</th>"""

new_prod_th = """              <tr>
                <th class="py-3 px-4">ID</th>
                <th class="py-3 px-4 text-center">Foto</th>
                <th class="py-3 px-4">Nombre</th>"""

html = html.replace(old_prod_th, new_prod_th)

# 2. Add Modal Subir Foto before </main> or after modalAuth
modal_foto_html = """  <!-- MODAL SUBIR FOTOGRAFÍA DE PRODUCTO (PUNTO 4.4) -->
  <div id="modalSubirFoto" class="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
      <div class="flex justify-between items-center border-b pb-3">
        <div class="flex items-center gap-2">
          <div class="h-8 w-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
            <i class="fa-solid fa-camera"></i>
          </div>
          <div>
            <h3 class="text-lg font-bold text-slate-900">Fotografía del Producto</h3>
            <p id="modalFotoSubtitulo" class="text-xs text-slate-500">Manejo de archivos estáticos (/uploads/)</p>
          </div>
        </div>
        <button onclick="cerrarModalFoto()" class="text-slate-400 hover:text-slate-600"><i class="fa-solid fa-xmark text-lg"></i></button>
      </div>

      <form id="formSubirFoto" onsubmit="procesarSubidaFoto(event)" class="space-y-4">
        <input type="hidden" id="fotoProdId">
        
        <div id="fotoPreviewContainer" class="hidden text-center p-3 border rounded-xl bg-slate-50">
          <img id="fotoPreviewImg" src="" alt="Vista previa" class="max-h-48 mx-auto rounded-lg shadow-sm border object-cover">
        </div>

        <div>
          <label class="block text-xs font-semibold text-slate-700 mb-1">Seleccionar Imagen (PNG, JPG, WEBP) *</label>
          <input type="file" id="fotoFileInput" accept="image/*" required onchange="previsualizarFoto(event)" class="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 border p-1.5 rounded-lg">
          <p class="text-[11px] text-slate-400 mt-1">El archivo se guardará en el servidor y MySQL guardará la ruta relativa.</p>
        </div>

        <div class="flex justify-end gap-2 pt-2 border-t">
          <button type="button" onclick="cerrarModalFoto()" class="px-4 py-2 border rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancelar</button>
          <button type="submit" id="btnSubirFotoSubmit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold flex items-center gap-1.5 shadow-sm">
            <i class="fa-solid fa-upload"></i> Subir Fotografía
          </button>
        </div>
      </form>
    </div>
  </div>
"""

# Insert modal_foto_html right before <!-- SCRIPT LOGIC JAVASCRIPT -->
html = html.replace('  <!-- SCRIPT LOGIC JAVASCRIPT -->', modal_foto_html + '\n  <!-- SCRIPT LOGIC JAVASCRIPT -->')

# 3. Enhance modalAuth with real login form
old_modal_auth_body = """      <div class="space-y-3">
        <label class="block text-xs font-semibold text-slate-700">Seleccionar Usuario Activo:</label>
        <div id="authUsuariosList" class="space-y-2 max-h-56 overflow-y-auto">
          <!-- Lista dinámica de usuarios de la base de datos -->
        </div>
      </div>"""

new_modal_auth_body = """      <!-- Formulario Login con Credenciales (PUNTO 4.1) -->
      <form id="formLoginAuth" onsubmit="ejecutarLoginCredenciales(event)" class="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div class="flex justify-between items-center">
          <span class="text-xs font-bold text-slate-700">Autenticación (POST /api/auth/login)</span>
          <span class="text-[10px] bg-indigo-100 text-indigo-700 font-mono px-1.5 py-0.5 rounded">@login_requerido</span>
        </div>
        <div>
          <input type="email" id="loginEmail" placeholder="correo@ejemplo.com" value="admin@erp.com" required class="w-full p-2 text-xs border rounded-lg outline-none focus:border-indigo-500">
        </div>
        <div>
          <input type="password" id="loginPass" placeholder="Contraseña" value="admin123" required class="w-full p-2 text-xs border rounded-lg outline-none focus:border-indigo-500">
        </div>
        <button type="submit" id="btnLoginSubmit" class="w-full py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs shadow-sm flex items-center justify-center gap-1.5 transition">
          <i class="fa-solid fa-key"></i> Iniciar Sesión y Generar Token
        </button>
      </form>

      <div class="space-y-2 pt-1">
        <label class="block text-xs font-semibold text-slate-700">O cambiar de usuario activo:</label>
        <div id="authUsuariosList" class="space-y-1.5 max-h-40 overflow-y-auto">
          <!-- Lista dinámica de usuarios de la base de datos -->
        </div>
      </div>"""

html = html.replace(old_modal_auth_body, new_modal_auth_body)

# 4. Update renderizarProductos to show thumbnail and photo upload button
old_render_prod = """      tbody.innerHTML = lista.map(p => {
        const esBajo = p.cantidad_stock <= p.nivel_minimo;
        const stockBadge = esBajo 
          ? `<span class=\"px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300\"><i class=\"fa-solid fa-triangle-exclamation mr-1\"></i>${p.cantidad_stock}</span>`
          : `<span class=\"px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800\">${p.cantidad_stock}</span>`;

        return `
          <tr class=\"hover:bg-slate-50 transition\">
            <td class=\"py-3 px-4 font-mono font-bold text-xs text-slate-500\">#${p.id_producto}</td>
            <td class=\"py-3 px-4 font-semibold text-slate-900\">${p.nombre}</td>
            <td class=\"py-3 px-4 text-center\">${stockBadge}</td>
            <td class=\"py-3 px-4 text-center text-slate-500 font-medium\">${p.nivel_minimo}</td>
            <td class=\"py-3 px-4 text-right text-slate-600 font-mono\">${formatMoney(p.precioCompra)}</td>
            <td class=\"py-3 px-4 text-right font-extrabold text-slate-900 font-mono\">${formatMoney(p.precioVenta)}</td>
            <td class=\"py-3 px-4 text-center text-xs text-slate-500 font-mono\">${(parseFloat(p.tarifa_iva || 0.19) * 100).toFixed(0)}%</td>
            <td class=\"py-3 px-4 text-center\">
              <div class=\"flex items-center justify-center gap-1\">
                <button onclick=\"editarProducto(${p.id_producto})\" class=\"p-1.5 text-indigo-600 hover:bg-indigo-50 rounded\" title=\"Editar\"><i class=\"fa-solid fa-pen-to-square\"></i></button>
                <button onclick=\"eliminarProducto(${p.id_producto}, '${p.nombre}')\" class=\"p-1.5 text-rose-600 hover:bg-rose-50 rounded\" title=\"Inactivar (Soft Delete)\"><i class=\"fa-solid fa-trash\"></i></button>
              </div>
            </td>
          </tr>
        `;
      }).join('');"""

new_render_prod = """      tbody.innerHTML = lista.map(p => {
        const esBajo = p.cantidad_stock <= p.nivel_minimo;
        const stockBadge = esBajo 
          ? `<span class=\"px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300\"><i class=\"fa-solid fa-triangle-exclamation mr-1\"></i>${p.cantidad_stock}</span>`
          : `<span class=\"px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800\">${p.cantidad_stock}</span>`;

        const fotoHtml = p.imagen 
          ? `<img src=\"${API_BASE}${p.imagen}\" alt=\"${p.nombre}\" class=\"h-9 w-9 object-cover rounded-lg border border-slate-200 shadow-sm mx-auto cursor-pointer hover:scale-110 transition\" onclick=\"abrirModalFoto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}', '${p.imagen}')\">`
          : `<div onclick=\"abrirModalFoto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}')\" class=\"h-9 w-9 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 mx-auto cursor-pointer hover:bg-indigo-50 hover:text-indigo-600 transition\" title=\"Subir foto\"><i class=\"fa-solid fa-camera text-xs\"></i></div>`;

        return `
          <tr class=\"hover:bg-slate-50 transition\">
            <td class=\"py-3 px-4 font-mono font-bold text-xs text-slate-500\">#${p.id_producto}</td>
            <td class=\"py-3 px-4 text-center\">${fotoHtml}</td>
            <td class=\"py-3 px-4 font-semibold text-slate-900\">${p.nombre}</td>
            <td class=\"py-3 px-4 text-center\">${stockBadge}</td>
            <td class=\"py-3 px-4 text-center text-slate-500 font-medium\">${p.nivel_minimo}</td>
            <td class=\"py-3 px-4 text-right text-slate-600 font-mono\">${formatMoney(p.precioCompra)}</td>
            <td class=\"py-3 px-4 text-right font-extrabold text-slate-900 font-mono\">${formatMoney(p.precioVenta)}</td>
            <td class=\"py-3 px-4 text-center text-xs text-slate-500 font-mono\">${(parseFloat(p.tarifa_iva || 0.19) * 100).toFixed(0)}%</td>
            <td class=\"py-3 px-4 text-center\">
              <div class=\"flex items-center justify-center gap-1\">
                <button onclick=\"abrirModalFoto(${p.id_producto}, '${p.nombre.replace(/'/g, "\\\\'")}', '${p.imagen || ''}')\" class=\"p-1.5 text-blue-600 hover:bg-blue-50 rounded\" title=\"Subir/Cambiar Fotografía (Punto 4.4)\"><i class=\"fa-solid fa-camera\"></i></button>
                <button onclick=\"editarProducto(${p.id_producto})\" class=\"p-1.5 text-indigo-600 hover:bg-indigo-50 rounded\" title=\"Editar\"><i class=\"fa-solid fa-pen-to-square\"></i></button>
                <button onclick=\"eliminarProducto(${p.id_producto}, '${p.nombre}')\" class=\"p-1.5 text-rose-600 hover:bg-rose-50 rounded\" title=\"Inactivar (Soft Delete)\"><i class=\"fa-solid fa-trash\"></i></button>
              </div>
            </td>
          </tr>
        `;
      }).join('');"""

html = html.replace(old_render_prod, new_render_prod)

# 5. In facturarVenta and anularVenta: include Authorization header
old_facturar_fetch = """        const res = await fetch(`${API_BASE}/api/ventas/`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });"""

new_facturar_fetch = """        const token = localStorage.getItem('erp_token') || 'erp_token_1_admin';
        const res = await fetch(`${API_BASE}/api/ventas/`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });"""

html = html.replace(old_facturar_fetch, new_facturar_fetch)

old_anular_fetch = """        const res = await fetch(`${API_BASE}/api/ventas/${idVenta}/anular`, {
          method: 'PUT'
        });"""

new_anular_fetch = """        const token = localStorage.getItem('erp_token') || 'erp_token_1_admin';
        const res = await fetch(`${API_BASE}/api/ventas/${idVenta}/anular`, {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });"""

html = html.replace(old_anular_fetch, new_anular_fetch)

# 6. Add JS functions for image upload & real login execution
js_additions = """
    // FUNCIONES PUNTO 4: FOTOGRAFÍAS Y AUTENTICACIÓN
    function abrirModalFoto(idProducto, nombre, imagenUrl) {
      document.getElementById('fotoProdId').value = idProducto;
      document.getElementById('modalFotoSubtitulo').innerText = `Producto: ${nombre} (#${idProducto})`;
      document.getElementById('fotoFileInput').value = '';
      const previewCont = document.getElementById('fotoPreviewContainer');
      const previewImg = document.getElementById('fotoPreviewImg');
      if (imagenUrl) {
        previewImg.src = `${API_BASE}${imagenUrl}`;
        previewCont.classList.remove('hidden');
      } else {
        previewCont.classList.add('hidden');
      }
      document.getElementById('modalSubirFoto').classList.remove('hidden');
    }

    function cerrarModalFoto() {
      document.getElementById('modalSubirFoto').classList.add('hidden');
    }

    function previsualizarFoto(e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(evt) {
          document.getElementById('fotoPreviewImg').src = evt.target.result;
          document.getElementById('fotoPreviewContainer').classList.remove('hidden');
        };
        reader.readAsDataURL(file);
      }
    }

    async function procesarSubidaFoto(e) {
      e.preventDefault();
      const idProducto = document.getElementById('fotoProdId').value;
      const fileInput = document.getElementById('fotoFileInput');
      if (!fileInput.files || fileInput.files.length === 0) {
        showToast("Seleccione un archivo de imagen.", "warning");
        return;
      }

      const formData = new FormData();
      formData.append('imagen', fileInput.files[0]);

      const btn = document.getElementById('btnSubirFotoSubmit');
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Subiendo archivo...';

      try {
        const res = await fetch(`${API_BASE}/api/productos/${idProducto}/imagen`, {
          method: 'POST',
          body: formData
        });

        const data = await res.json();
        if (!res.ok) {
          showToast(data.error || "No se pudo subir la fotografía.", "error");
          return;
        }

        showToast(data.mensaje || "Fotografía guardada exitosamente en el servidor.", "success");
        cerrarModalFoto();
        await cargarProductos();
      } catch (err) {
        showToast("Error de red al subir la imagen.", "error");
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-upload"></i> Subir Fotografía';
      }
    }

    async function ejecutarLoginCredenciales(e) {
      e.preventDefault();
      const correo = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPass').value.trim();

      const btn = document.getElementById('btnLoginSubmit');
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Validando credenciales...';

      try {
        const res = await fetch(`${API_BASE}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ correo, password })
        });

        const data = await res.json();
        if (!res.ok) {
          showToast(data.error || "Credenciales incorrectas.", "error");
          return;
        }

        // Guardar token y usuario
        if (data.token) {
          localStorage.setItem('erp_token', data.token);
        }
        usuarioActivo = data.usuario;
        actualizarPillUsuarioNav();
        showToast(`¡Autenticado con éxito como ${data.usuario.nombre}! Token de sesión generado.`, "success");
        cerrarModalAuth();
      } catch (err) {
        showToast("Error de conexión al autenticar.", "error");
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-key"></i> Iniciar Sesión y Generar Token';
      }
    }
"""

html = html.replace("    // Inicializar al cargar el DOM", js_additions + "\n    // Inicializar al cargar el DOM")

with open('frontend/index.html', 'w', encoding='utf-8') as f:
    f.write(html)

with open('backend/static/index.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Punto 4 frontend integration complete!")
