import mysql.connector

def setup_db():
    conn = mysql.connector.connect(host='localhost', port=3307, user='root', password='', database='erp')
    cursor = conn.cursor()

    print("1. Agregando columna 'imagen' a la tabla 'productos' si no existe...")
    cursor.execute("SHOW COLUMNS FROM productos LIKE 'imagen';")
    if not cursor.fetchone():
        cursor.execute("ALTER TABLE productos ADD COLUMN imagen VARCHAR(255) NULL;")
        print("   -> Columna 'imagen' agregada con éxito.")
    else:
        print("   -> Columna 'imagen' ya existe.")

    print("2. Creando tabla 'recibos_caja' para control de abonos...")
    sql_recibos = """
    CREATE TABLE IF NOT EXISTS recibos_caja (
        id_recibo INT AUTO_INCREMENT PRIMARY KEY,
        id_venta INT NOT NULL,
        fecha_recibo DATETIME DEFAULT CURRENT_TIMESTAMP,
        monto DECIMAL(12, 2) NOT NULL,
        observacion VARCHAR(255) NULL,
        CONSTRAINT fk_recibos_ventas FOREIGN KEY (id_venta) REFERENCES ventas(id_venta) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    """
    cursor.execute(sql_recibos)
    print("   -> Tabla 'recibos_caja' lista.")

    print("3. Creando trigger 'recibos_caja_AFTER_INSERT'...")
    cursor.execute("DROP TRIGGER IF EXISTS recibos_caja_AFTER_INSERT;")
    trigger_recibos = """
    CREATE TRIGGER recibos_caja_AFTER_INSERT
    AFTER INSERT ON recibos_caja
    FOR EACH ROW
    BEGIN
        DECLARE v_total_factura DECIMAL(12, 2);
        DECLARE v_total_abonado DECIMAL(12, 2);

        -- Obtener el total de la venta
        SELECT total_venta INTO v_total_factura
        FROM ventas
        WHERE id_venta = NEW.id_venta;

        -- Sumar todos los abonos registrados para esta venta
        SELECT IFNULL(SUM(monto), 0) INTO v_total_abonado
        FROM recibos_caja
        WHERE id_venta = NEW.id_venta;

        -- Si la sumatoria de recibos cubre o supera el total de la factura, cambiar a 'Pagado'
        -- De lo contrario permanece en 'Por Pagar'
        IF v_total_abonado >= v_total_factura THEN
            UPDATE ventas
            SET estado_venta = 'Pagado'
            WHERE id_venta = NEW.id_venta;
        ELSE
            UPDATE ventas
            SET estado_venta = 'Por Pagar'
            WHERE id_venta = NEW.id_venta;
        END IF;
    END;
    """
    cursor.execute(trigger_recibos)
    print("   -> Trigger 'recibos_caja_AFTER_INSERT' creado con éxito.")

    print("4. Creando trigger de integridad relacional 'ventas_BEFORE_INSERT' (Soft Delete Cascada)...")
    cursor.execute("DROP TRIGGER IF EXISTS ventas_BEFORE_INSERT;")
    trigger_ventas_bi = """
    CREATE TRIGGER ventas_BEFORE_INSERT
    BEFORE INSERT ON ventas
    FOR EACH ROW
    BEGIN
        DECLARE v_estado_cliente INT;

        SELECT estado INTO v_estado_cliente
        FROM terceros
        WHERE id_tercero = NEW.id_tercero;

        IF v_estado_cliente = 0 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operación denegada: El cliente seleccionado se encuentra inactivo (Soft Delete).';
        END IF;
    END;
    """
    cursor.execute(trigger_ventas_bi)
    print("   -> Trigger 'ventas_BEFORE_INSERT' creado con éxito.")

    print("5. Creando trigger de integridad relacional 'pedidos_BEFORE_INSERT' (Soft Delete Cascada)...")
    cursor.execute("DROP TRIGGER IF EXISTS pedidos_BEFORE_INSERT;")
    trigger_pedidos_bi = """
    CREATE TRIGGER pedidos_BEFORE_INSERT
    BEFORE INSERT ON pedidos
    FOR EACH ROW
    BEGIN
        DECLARE v_estado_tercero INT;

        SELECT estado INTO v_estado_tercero
        FROM terceros
        WHERE id_tercero = NEW.id_tercero;

        IF v_estado_tercero = 0 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Operación denegada: El proveedor/tercero seleccionado se encuentra inactivo (Soft Delete).';
        END IF;
    END;
    """
    cursor.execute(trigger_pedidos_bi)
    print("   -> Trigger 'pedidos_BEFORE_INSERT' creado con éxito.")

    conn.commit()
    cursor.close()
    conn.close()
    print("Base de datos en puerto 3307 actualizada con éxito!")

if __name__ == '__main__':
    setup_db()
