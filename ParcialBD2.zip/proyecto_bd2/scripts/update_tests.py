with open('tests/test_api.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update setUp to set self.headers
old_setup = """    def setUp(self):
        self.client = app.test_client()"""

new_setup = """    def setUp(self):
        self.client = app.test_client()
        self.headers = {"Authorization": "Bearer erp_token_1_test"}"""

text = text.replace(old_setup, new_setup)

# 2. Add test for login_requerido
auth_test = """    def test_login_requerido_sin_token(self):
        # Punto 4.1: Endpoints protegidos sin token retornan 401
        res = self.client.post('/api/ventas/', json={"id_usuario": 1})
        self.assertEqual(res.status_code, 401)
        res_anular = self.client.put('/api/ventas/1/anular')
        self.assertEqual(res_anular.status_code, 401)

"""

text = text.replace("    def test_crear_venta_validation(self):", auth_test + "    def test_crear_venta_validation(self):")

# 3. Add headers to protected calls in test_api.py
text = text.replace("self.client.post('/api/ventas/', json={\"id_usuario\": 1})", "self.client.post('/api/ventas/', json={\"id_usuario\": 1}, headers=self.headers)")
text = text.replace("self.client.post('/api/ventas/', json={\"id_usuario\": 1, \"id_tercero\": 2, \"detalles\": []})", "self.client.post('/api/ventas/', json={\"id_usuario\": 1, \"id_tercero\": 2, \"detalles\": []}, headers=self.headers)")
text = text.replace("self.client.put('/api/ventas/999/anular')", "self.client.put('/api/ventas/999/anular', headers=self.headers)")
text = text.replace("self.client.put('/api/ventas/1/anular')", "self.client.put('/api/ventas/1/anular', headers=self.headers)")

# In test_error_privacidad_foreign_key
text = text.replace("res = self.client.post('/api/ventas/', json={\n                \"id_usuario\": 999,", "res = self.client.post('/api/ventas/', headers=self.headers, json={\n                \"id_usuario\": 999,")

with open('tests/test_api.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("Updated tests/test_api.py successfully")
